# react-storefront-starter-app

Starter Next.js app for React Storefront 7+

# Development

```
npm i
npm run dev
```

# Production

You can get a better sense of the speed of React Storefront by running a production build:

```
npm run build && npm run prod
```
