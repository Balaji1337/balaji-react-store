console.info('Service worker disabled for development, will be generated at build time.');
