module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./pages/api/index.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./node_modules/@babel/runtime/helpers/arrayLikeToArray.js":
/*!*****************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/arrayLikeToArray.js ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _arrayLikeToArray(arr, len) {
  if (len == null || len > arr.length) len = arr.length;

  for (var i = 0, arr2 = new Array(len); i < len; i++) {
    arr2[i] = arr[i];
  }

  return arr2;
}

module.exports = _arrayLikeToArray, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/arrayWithoutHoles.js":
/*!******************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/arrayWithoutHoles.js ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var arrayLikeToArray = __webpack_require__(/*! ./arrayLikeToArray.js */ "./node_modules/@babel/runtime/helpers/arrayLikeToArray.js");

function _arrayWithoutHoles(arr) {
  if (Array.isArray(arr)) return arrayLikeToArray(arr);
}

module.exports = _arrayWithoutHoles, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/asyncToGenerator.js":
/*!*****************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/asyncToGenerator.js ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
  try {
    var info = gen[key](arg);
    var value = info.value;
  } catch (error) {
    reject(error);
    return;
  }

  if (info.done) {
    resolve(value);
  } else {
    Promise.resolve(value).then(_next, _throw);
  }
}

function _asyncToGenerator(fn) {
  return function () {
    var self = this,
        args = arguments;
    return new Promise(function (resolve, reject) {
      var gen = fn.apply(self, args);

      function _next(value) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
      }

      function _throw(err) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
      }

      _next(undefined);
    });
  };
}

module.exports = _asyncToGenerator, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/defineProperty.js":
/*!***************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/defineProperty.js ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _defineProperty(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}

module.exports = _defineProperty, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js":
/*!**********************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/interopRequireDefault.js ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    "default": obj
  };
}

module.exports = _interopRequireDefault, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/interopRequireWildcard.js":
/*!***********************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/interopRequireWildcard.js ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var _typeof = __webpack_require__(/*! ./typeof.js */ "./node_modules/@babel/runtime/helpers/typeof.js")["default"];

function _getRequireWildcardCache(nodeInterop) {
  if (typeof WeakMap !== "function") return null;
  var cacheBabelInterop = new WeakMap();
  var cacheNodeInterop = new WeakMap();
  return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) {
    return nodeInterop ? cacheNodeInterop : cacheBabelInterop;
  })(nodeInterop);
}

function _interopRequireWildcard(obj, nodeInterop) {
  if (!nodeInterop && obj && obj.__esModule) {
    return obj;
  }

  if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") {
    return {
      "default": obj
    };
  }

  var cache = _getRequireWildcardCache(nodeInterop);

  if (cache && cache.has(obj)) {
    return cache.get(obj);
  }

  var newObj = {};
  var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;

  for (var key in obj) {
    if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {
      var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;

      if (desc && (desc.get || desc.set)) {
        Object.defineProperty(newObj, key, desc);
      } else {
        newObj[key] = obj[key];
      }
    }
  }

  newObj["default"] = obj;

  if (cache) {
    cache.set(obj, newObj);
  }

  return newObj;
}

module.exports = _interopRequireWildcard, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/iterableToArray.js":
/*!****************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/iterableToArray.js ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _iterableToArray(iter) {
  if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}

module.exports = _iterableToArray, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/nonIterableSpread.js":
/*!******************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/nonIterableSpread.js ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _nonIterableSpread() {
  throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}

module.exports = _nonIterableSpread, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/regeneratorRuntime.js":
/*!*******************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/regeneratorRuntime.js ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var _typeof = __webpack_require__(/*! ./typeof.js */ "./node_modules/@babel/runtime/helpers/typeof.js")["default"];

function _regeneratorRuntime() {
  "use strict";
  /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */

  module.exports = _regeneratorRuntime = function _regeneratorRuntime() {
    return exports;
  }, module.exports.__esModule = true, module.exports["default"] = module.exports;
  var exports = {},
      Op = Object.prototype,
      hasOwn = Op.hasOwnProperty,
      $Symbol = "function" == typeof Symbol ? Symbol : {},
      iteratorSymbol = $Symbol.iterator || "@@iterator",
      asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator",
      toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag";

  function define(obj, key, value) {
    return Object.defineProperty(obj, key, {
      value: value,
      enumerable: !0,
      configurable: !0,
      writable: !0
    }), obj[key];
  }

  try {
    define({}, "");
  } catch (err) {
    define = function define(obj, key, value) {
      return obj[key] = value;
    };
  }

  function wrap(innerFn, outerFn, self, tryLocsList) {
    var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator,
        generator = Object.create(protoGenerator.prototype),
        context = new Context(tryLocsList || []);
    return generator._invoke = function (innerFn, self, context) {
      var state = "suspendedStart";
      return function (method, arg) {
        if ("executing" === state) throw new Error("Generator is already running");

        if ("completed" === state) {
          if ("throw" === method) throw arg;
          return doneResult();
        }

        for (context.method = method, context.arg = arg;;) {
          var delegate = context.delegate;

          if (delegate) {
            var delegateResult = maybeInvokeDelegate(delegate, context);

            if (delegateResult) {
              if (delegateResult === ContinueSentinel) continue;
              return delegateResult;
            }
          }

          if ("next" === context.method) context.sent = context._sent = context.arg;else if ("throw" === context.method) {
            if ("suspendedStart" === state) throw state = "completed", context.arg;
            context.dispatchException(context.arg);
          } else "return" === context.method && context.abrupt("return", context.arg);
          state = "executing";
          var record = tryCatch(innerFn, self, context);

          if ("normal" === record.type) {
            if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue;
            return {
              value: record.arg,
              done: context.done
            };
          }

          "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg);
        }
      };
    }(innerFn, self, context), generator;
  }

  function tryCatch(fn, obj, arg) {
    try {
      return {
        type: "normal",
        arg: fn.call(obj, arg)
      };
    } catch (err) {
      return {
        type: "throw",
        arg: err
      };
    }
  }

  exports.wrap = wrap;
  var ContinueSentinel = {};

  function Generator() {}

  function GeneratorFunction() {}

  function GeneratorFunctionPrototype() {}

  var IteratorPrototype = {};
  define(IteratorPrototype, iteratorSymbol, function () {
    return this;
  });
  var getProto = Object.getPrototypeOf,
      NativeIteratorPrototype = getProto && getProto(getProto(values([])));
  NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype);
  var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype);

  function defineIteratorMethods(prototype) {
    ["next", "throw", "return"].forEach(function (method) {
      define(prototype, method, function (arg) {
        return this._invoke(method, arg);
      });
    });
  }

  function AsyncIterator(generator, PromiseImpl) {
    function invoke(method, arg, resolve, reject) {
      var record = tryCatch(generator[method], generator, arg);

      if ("throw" !== record.type) {
        var result = record.arg,
            value = result.value;
        return value && "object" == _typeof(value) && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function (value) {
          invoke("next", value, resolve, reject);
        }, function (err) {
          invoke("throw", err, resolve, reject);
        }) : PromiseImpl.resolve(value).then(function (unwrapped) {
          result.value = unwrapped, resolve(result);
        }, function (error) {
          return invoke("throw", error, resolve, reject);
        });
      }

      reject(record.arg);
    }

    var previousPromise;

    this._invoke = function (method, arg) {
      function callInvokeWithMethodAndArg() {
        return new PromiseImpl(function (resolve, reject) {
          invoke(method, arg, resolve, reject);
        });
      }

      return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg();
    };
  }

  function maybeInvokeDelegate(delegate, context) {
    var method = delegate.iterator[context.method];

    if (undefined === method) {
      if (context.delegate = null, "throw" === context.method) {
        if (delegate.iterator["return"] && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method)) return ContinueSentinel;
        context.method = "throw", context.arg = new TypeError("The iterator does not provide a 'throw' method");
      }

      return ContinueSentinel;
    }

    var record = tryCatch(method, delegate.iterator, context.arg);
    if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel;
    var info = record.arg;
    return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel);
  }

  function pushTryEntry(locs) {
    var entry = {
      tryLoc: locs[0]
    };
    1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry);
  }

  function resetTryEntry(entry) {
    var record = entry.completion || {};
    record.type = "normal", delete record.arg, entry.completion = record;
  }

  function Context(tryLocsList) {
    this.tryEntries = [{
      tryLoc: "root"
    }], tryLocsList.forEach(pushTryEntry, this), this.reset(!0);
  }

  function values(iterable) {
    if (iterable) {
      var iteratorMethod = iterable[iteratorSymbol];
      if (iteratorMethod) return iteratorMethod.call(iterable);
      if ("function" == typeof iterable.next) return iterable;

      if (!isNaN(iterable.length)) {
        var i = -1,
            next = function next() {
          for (; ++i < iterable.length;) {
            if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next;
          }

          return next.value = undefined, next.done = !0, next;
        };

        return next.next = next;
      }
    }

    return {
      next: doneResult
    };
  }

  function doneResult() {
    return {
      value: undefined,
      done: !0
    };
  }

  return GeneratorFunction.prototype = GeneratorFunctionPrototype, define(Gp, "constructor", GeneratorFunctionPrototype), define(GeneratorFunctionPrototype, "constructor", GeneratorFunction), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports.isGeneratorFunction = function (genFun) {
    var ctor = "function" == typeof genFun && genFun.constructor;
    return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name));
  }, exports.mark = function (genFun) {
    return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun;
  }, exports.awrap = function (arg) {
    return {
      __await: arg
    };
  }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function () {
    return this;
  }), exports.AsyncIterator = AsyncIterator, exports.async = function (innerFn, outerFn, self, tryLocsList, PromiseImpl) {
    void 0 === PromiseImpl && (PromiseImpl = Promise);
    var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl);
    return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function (result) {
      return result.done ? result.value : iter.next();
    });
  }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function () {
    return this;
  }), define(Gp, "toString", function () {
    return "[object Generator]";
  }), exports.keys = function (object) {
    var keys = [];

    for (var key in object) {
      keys.push(key);
    }

    return keys.reverse(), function next() {
      for (; keys.length;) {
        var key = keys.pop();
        if (key in object) return next.value = key, next.done = !1, next;
      }

      return next.done = !0, next;
    };
  }, exports.values = values, Context.prototype = {
    constructor: Context,
    reset: function reset(skipTempReset) {
      if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for (var name in this) {
        "t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined);
      }
    },
    stop: function stop() {
      this.done = !0;
      var rootRecord = this.tryEntries[0].completion;
      if ("throw" === rootRecord.type) throw rootRecord.arg;
      return this.rval;
    },
    dispatchException: function dispatchException(exception) {
      if (this.done) throw exception;
      var context = this;

      function handle(loc, caught) {
        return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught;
      }

      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i],
            record = entry.completion;
        if ("root" === entry.tryLoc) return handle("end");

        if (entry.tryLoc <= this.prev) {
          var hasCatch = hasOwn.call(entry, "catchLoc"),
              hasFinally = hasOwn.call(entry, "finallyLoc");

          if (hasCatch && hasFinally) {
            if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0);
            if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc);
          } else if (hasCatch) {
            if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0);
          } else {
            if (!hasFinally) throw new Error("try statement without catch or finally");
            if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc);
          }
        }
      }
    },
    abrupt: function abrupt(type, arg) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];

        if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) {
          var finallyEntry = entry;
          break;
        }
      }

      finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null);
      var record = finallyEntry ? finallyEntry.completion : {};
      return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record);
    },
    complete: function complete(record, afterLoc) {
      if ("throw" === record.type) throw record.arg;
      return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel;
    },
    finish: function finish(finallyLoc) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel;
      }
    },
    "catch": function _catch(tryLoc) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];

        if (entry.tryLoc === tryLoc) {
          var record = entry.completion;

          if ("throw" === record.type) {
            var thrown = record.arg;
            resetTryEntry(entry);
          }

          return thrown;
        }
      }

      throw new Error("illegal catch attempt");
    },
    delegateYield: function delegateYield(iterable, resultName, nextLoc) {
      return this.delegate = {
        iterator: values(iterable),
        resultName: resultName,
        nextLoc: nextLoc
      }, "next" === this.method && (this.arg = undefined), ContinueSentinel;
    }
  }, exports;
}

module.exports = _regeneratorRuntime, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/toConsumableArray.js":
/*!******************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/toConsumableArray.js ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var arrayWithoutHoles = __webpack_require__(/*! ./arrayWithoutHoles.js */ "./node_modules/@babel/runtime/helpers/arrayWithoutHoles.js");

var iterableToArray = __webpack_require__(/*! ./iterableToArray.js */ "./node_modules/@babel/runtime/helpers/iterableToArray.js");

var unsupportedIterableToArray = __webpack_require__(/*! ./unsupportedIterableToArray.js */ "./node_modules/@babel/runtime/helpers/unsupportedIterableToArray.js");

var nonIterableSpread = __webpack_require__(/*! ./nonIterableSpread.js */ "./node_modules/@babel/runtime/helpers/nonIterableSpread.js");

function _toConsumableArray(arr) {
  return arrayWithoutHoles(arr) || iterableToArray(arr) || unsupportedIterableToArray(arr) || nonIterableSpread();
}

module.exports = _toConsumableArray, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/typeof.js":
/*!*******************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/typeof.js ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _typeof(obj) {
  "@babel/helpers - typeof";

  return (module.exports = _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) {
    return typeof obj;
  } : function (obj) {
    return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
  }, module.exports.__esModule = true, module.exports["default"] = module.exports), _typeof(obj);
}

module.exports = _typeof, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/unsupportedIterableToArray.js":
/*!***************************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/unsupportedIterableToArray.js ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var arrayLikeToArray = __webpack_require__(/*! ./arrayLikeToArray.js */ "./node_modules/@babel/runtime/helpers/arrayLikeToArray.js");

function _unsupportedIterableToArray(o, minLen) {
  if (!o) return;
  if (typeof o === "string") return arrayLikeToArray(o, minLen);
  var n = Object.prototype.toString.call(o).slice(8, -1);
  if (n === "Object" && o.constructor) n = o.constructor.name;
  if (n === "Map" || n === "Set") return Array.from(o);
  if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return arrayLikeToArray(o, minLen);
}

module.exports = _unsupportedIterableToArray, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "./node_modules/@babel/runtime/regenerator/index.js":
/*!**********************************************************!*\
  !*** ./node_modules/@babel/runtime/regenerator/index.js ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// TODO(Babel 8): Remove this file.

var runtime = __webpack_require__(/*! ../helpers/regeneratorRuntime */ "./node_modules/@babel/runtime/helpers/regeneratorRuntime.js")();
module.exports = runtime;

// Copied from https://github.com/facebook/regenerator/blob/main/packages/runtime/runtime.js#L736=
try {
  regeneratorRuntime = runtime;
} catch (accidentalStrictMode) {
  if (typeof globalThis === "object") {
    globalThis.regeneratorRuntime = runtime;
  } else {
    Function("r", "regeneratorRuntime = r")(runtime);
  }
}


/***/ }),

/***/ "./node_modules/react-storefront/mock-connector/account.js":
/*!*****************************************************************!*\
  !*** ./node_modules/react-storefront/mock-connector/account.js ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = account;

var _regenerator = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js"));

var _asyncToGenerator2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/asyncToGenerator.js"));

var _fulfillAPIRequest = _interopRequireDefault(__webpack_require__(/*! ..//props/fulfillAPIRequest */ "./node_modules/react-storefront/props/fulfillAPIRequest.js"));

var _createAppData = _interopRequireDefault(__webpack_require__(/*! ./utils/createAppData */ "./node_modules/react-storefront/mock-connector/utils/createAppData.js"));

function account(_x, _x2) {
  return _account.apply(this, arguments);
}

function _account() {
  _account = (0, _asyncToGenerator2["default"])( /*#__PURE__*/_regenerator["default"].mark(function _callee(req, res) {
    return _regenerator["default"].wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return (0, _fulfillAPIRequest["default"])(req, {
              appData: _createAppData["default"],
              pageData: function pageData() {
                return Promise.resolve({
                  title: 'My Account',
                  account: {},
                  breadcrumbs: [{
                    text: 'Home',
                    href: '/'
                  }]
                });
              }
            });

          case 2:
            return _context.abrupt("return", _context.sent);

          case 3:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));
  return _account.apply(this, arguments);
}
//# sourceMappingURL=account.js.map

/***/ }),

/***/ "./node_modules/react-storefront/mock-connector/addToCart.js":
/*!*******************************************************************!*\
  !*** ./node_modules/react-storefront/mock-connector/addToCart.js ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = addToCart;

var _regenerator = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js"));

var _asyncToGenerator2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/asyncToGenerator.js"));

var _cartStore = __webpack_require__(/*! ./utils/cartStore */ "./node_modules/react-storefront/mock-connector/utils/cartStore.js");

function addToCart(_x, _x2, _x3) {
  return _addToCart.apply(this, arguments);
}

function _addToCart() {
  _addToCart = (0, _asyncToGenerator2["default"])( /*#__PURE__*/_regenerator["default"].mark(function _callee(_ref, req, res) {
    var color, size, product, quantity;
    return _regenerator["default"].wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            color = _ref.color, size = _ref.size, product = _ref.product, quantity = _ref.quantity;
            return _context.abrupt("return", {
              cart: {
                items: (0, _cartStore.addItem)(product.id, quantity, req, res)
              }
            });

          case 2:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));
  return _addToCart.apply(this, arguments);
}
//# sourceMappingURL=addToCart.js.map

/***/ }),

/***/ "./node_modules/react-storefront/mock-connector/cart.js":
/*!**************************************************************!*\
  !*** ./node_modules/react-storefront/mock-connector/cart.js ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = cart;

var _regenerator = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js"));

var _asyncToGenerator2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/asyncToGenerator.js"));

var _fulfillAPIRequest = _interopRequireDefault(__webpack_require__(/*! ../props/fulfillAPIRequest */ "./node_modules/react-storefront/props/fulfillAPIRequest.js"));

var _createAppData = _interopRequireDefault(__webpack_require__(/*! ./utils/createAppData */ "./node_modules/react-storefront/mock-connector/utils/createAppData.js"));

var _cartStore = __webpack_require__(/*! ./utils/cartStore */ "./node_modules/react-storefront/mock-connector/utils/cartStore.js");

function cart(_x, _x2) {
  return _cart.apply(this, arguments);
}

function _cart() {
  _cart = (0, _asyncToGenerator2["default"])( /*#__PURE__*/_regenerator["default"].mark(function _callee(req, res) {
    return _regenerator["default"].wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            return _context.abrupt("return", (0, _fulfillAPIRequest["default"])(req, {
              appData: _createAppData["default"],
              pageData: function pageData() {
                return Promise.resolve({
                  title: 'My Cart',
                  breadcrumbs: [{
                    text: 'Home',
                    href: '/'
                  }],
                  cart: {
                    items: (0, _cartStore.getProducts)(req, res)
                  }
                });
              }
            }));

          case 1:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));
  return _cart.apply(this, arguments);
}
//# sourceMappingURL=cart.js.map

/***/ }),

/***/ "./node_modules/react-storefront/mock-connector/home.js":
/*!**************************************************************!*\
  !*** ./node_modules/react-storefront/mock-connector/home.js ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = home;

var _regenerator = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js"));

var _asyncToGenerator2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/asyncToGenerator.js"));

var _fulfillAPIRequest = _interopRequireDefault(__webpack_require__(/*! ../props/fulfillAPIRequest */ "./node_modules/react-storefront/props/fulfillAPIRequest.js"));

var _createAppData = _interopRequireDefault(__webpack_require__(/*! ./utils/createAppData */ "./node_modules/react-storefront/mock-connector/utils/createAppData.js"));

function home(_x, _x2) {
  return _home.apply(this, arguments);
}

function _home() {
  _home = (0, _asyncToGenerator2["default"])( /*#__PURE__*/_regenerator["default"].mark(function _callee(req, res) {
    return _regenerator["default"].wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return (0, _fulfillAPIRequest["default"])(req, {
              appData: _createAppData["default"],
              pageData: function pageData() {
                return Promise.resolve({
                  title: 'React Storefront',
                  slots: {
                    heading: 'Welcome to your new React Storefront app.',
                    description: "\n                <p>\n                Here you'll find mock home, category, subcategory, product, and cart pages that you can\n                use as a starting point to build your PWA.\n              </p>\n              <p>Happy coding!</p>\n            "
                  }
                });
              }
            });

          case 2:
            return _context.abrupt("return", _context.sent);

          case 3:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));
  return _home.apply(this, arguments);
}
//# sourceMappingURL=home.js.map

/***/ }),

/***/ "./node_modules/react-storefront/mock-connector/index.js":
/*!***************************************************************!*\
  !*** ./node_modules/react-storefront/mock-connector/index.js ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js");

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "cart", {
  enumerable: true,
  get: function get() {
    return _cart["default"];
  }
});
Object.defineProperty(exports, "account", {
  enumerable: true,
  get: function get() {
    return _account["default"];
  }
});
Object.defineProperty(exports, "addToCart", {
  enumerable: true,
  get: function get() {
    return _addToCart["default"];
  }
});
Object.defineProperty(exports, "updateCartItem", {
  enumerable: true,
  get: function get() {
    return _updateCartItem["default"];
  }
});
Object.defineProperty(exports, "removeCartItem", {
  enumerable: true,
  get: function get() {
    return _removeCartItem["default"];
  }
});
Object.defineProperty(exports, "home", {
  enumerable: true,
  get: function get() {
    return _home["default"];
  }
});
Object.defineProperty(exports, "product", {
  enumerable: true,
  get: function get() {
    return _product["default"];
  }
});
Object.defineProperty(exports, "productMedia", {
  enumerable: true,
  get: function get() {
    return _productMedia["default"];
  }
});
Object.defineProperty(exports, "productSuggestions", {
  enumerable: true,
  get: function get() {
    return _productSuggestions["default"];
  }
});
Object.defineProperty(exports, "search", {
  enumerable: true,
  get: function get() {
    return _search["default"];
  }
});
Object.defineProperty(exports, "searchSuggestions", {
  enumerable: true,
  get: function get() {
    return _searchSuggestions["default"];
  }
});
Object.defineProperty(exports, "session", {
  enumerable: true,
  get: function get() {
    return _session["default"];
  }
});
Object.defineProperty(exports, "subcategory", {
  enumerable: true,
  get: function get() {
    return _subcategory["default"];
  }
});

var _cart = _interopRequireDefault(__webpack_require__(/*! ./cart.js */ "./node_modules/react-storefront/mock-connector/cart.js"));

var _account = _interopRequireDefault(__webpack_require__(/*! ./account.js */ "./node_modules/react-storefront/mock-connector/account.js"));

var _addToCart = _interopRequireDefault(__webpack_require__(/*! ./addToCart.js */ "./node_modules/react-storefront/mock-connector/addToCart.js"));

var _updateCartItem = _interopRequireDefault(__webpack_require__(/*! ./updateCartItem.js */ "./node_modules/react-storefront/mock-connector/updateCartItem.js"));

var _removeCartItem = _interopRequireDefault(__webpack_require__(/*! ./removeCartItem.js */ "./node_modules/react-storefront/mock-connector/removeCartItem.js"));

var _home = _interopRequireDefault(__webpack_require__(/*! ./home.js */ "./node_modules/react-storefront/mock-connector/home.js"));

var _product = _interopRequireDefault(__webpack_require__(/*! ./product.js */ "./node_modules/react-storefront/mock-connector/product.js"));

var _productMedia = _interopRequireDefault(__webpack_require__(/*! ./productMedia.js */ "./node_modules/react-storefront/mock-connector/productMedia.js"));

var _productSuggestions = _interopRequireDefault(__webpack_require__(/*! ./productSuggestions.js */ "./node_modules/react-storefront/mock-connector/productSuggestions.js"));

var _search = _interopRequireDefault(__webpack_require__(/*! ./search.js */ "./node_modules/react-storefront/mock-connector/search.js"));

var _searchSuggestions = _interopRequireDefault(__webpack_require__(/*! ./searchSuggestions.js */ "./node_modules/react-storefront/mock-connector/searchSuggestions.js"));

var _session = _interopRequireDefault(__webpack_require__(/*! ./session.js */ "./node_modules/react-storefront/mock-connector/session.js"));

var _subcategory = _interopRequireDefault(__webpack_require__(/*! ./subcategory.js */ "./node_modules/react-storefront/mock-connector/subcategory.js"));
//# sourceMappingURL=index.js.map

/***/ }),

/***/ "./node_modules/react-storefront/mock-connector/product.js":
/*!*****************************************************************!*\
  !*** ./node_modules/react-storefront/mock-connector/product.js ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = product;

var _regenerator = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js"));

var _asyncToGenerator2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/asyncToGenerator.js"));

var _fulfillAPIRequest = _interopRequireDefault(__webpack_require__(/*! ../props/fulfillAPIRequest */ "./node_modules/react-storefront/props/fulfillAPIRequest.js"));

var _createProduct = _interopRequireDefault(__webpack_require__(/*! ./utils/createProduct */ "./node_modules/react-storefront/mock-connector/utils/createProduct.js"));

var _createAppData = _interopRequireDefault(__webpack_require__(/*! ./utils/createAppData */ "./node_modules/react-storefront/mock-connector/utils/createAppData.js"));

var _getBase64ForImage = _interopRequireDefault(__webpack_require__(/*! react-storefront/utils/getBase64ForImage */ "react-storefront/utils/getBase64ForImage"));

function asciiSum() {
  var string = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '';
  return string.split('').reduce(function (s, e) {
    return s + e.charCodeAt();
  }, 0);
}

function product(_x, _x2, _x3) {
  return _product.apply(this, arguments);
}

function _product() {
  _product = (0, _asyncToGenerator2["default"])( /*#__PURE__*/_regenerator["default"].mark(function _callee(params, req, res) {
    var id, color, size, result, data, mockPrice;
    return _regenerator["default"].wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            id = params.id, color = params.color, size = params.size;
            _context.next = 3;
            return (0, _fulfillAPIRequest["default"])(req, {
              appData: _createAppData["default"],
              pageData: function pageData() {
                return getPageData(id);
              }
            });

          case 3:
            result = _context.sent;

            if (!(color || size)) {
              _context.next = 13;
              break;
            }

            _context.next = 7;
            return getPageData(id);

          case 7:
            data = _context.sent;
            data.carousel = {
              index: 0
            }; // A price for the fetched product variant would be included in
            // the response, but for demo purposes only, we are setting the
            // price based on the color name.

            mockPrice = (asciiSum(color) + asciiSum(size)) / 100;
            data.product.price = mockPrice;
            data.product.priceText = "$".concat(mockPrice.toFixed(2));
            return _context.abrupt("return", data);

          case 13:
            return _context.abrupt("return", result);

          case 14:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));
  return _product.apply(this, arguments);
}

function getPageData(_x4) {
  return _getPageData.apply(this, arguments);
}

function _getPageData() {
  _getPageData = (0, _asyncToGenerator2["default"])( /*#__PURE__*/_regenerator["default"].mark(function _callee2(id) {
    var result, mainProductImage;
    return _regenerator["default"].wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            result = {
              title: "Product ".concat(id),
              product: (0, _createProduct["default"])(id),
              breadcrumbs: [{
                text: "Home",
                href: '/'
              }, {
                text: "Subcategory ".concat(id),
                as: "/s/".concat(id),
                href: '/s/[subcategoryId]'
              }]
            };
            mainProductImage = result.product.media.full[0];
            _context2.next = 4;
            return (0, _getBase64ForImage["default"])(mainProductImage.src);

          case 4:
            mainProductImage.src = _context2.sent;
            return _context2.abrupt("return", result);

          case 6:
          case "end":
            return _context2.stop();
        }
      }
    }, _callee2);
  }));
  return _getPageData.apply(this, arguments);
}
//# sourceMappingURL=product.js.map

/***/ }),

/***/ "./node_modules/react-storefront/mock-connector/productMedia.js":
/*!**********************************************************************!*\
  !*** ./node_modules/react-storefront/mock-connector/productMedia.js ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = productMedia;

var _regenerator = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js"));

var _asyncToGenerator2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/asyncToGenerator.js"));

var _createMedia = _interopRequireDefault(__webpack_require__(/*! ./utils/createMedia */ "./node_modules/react-storefront/mock-connector/utils/createMedia.js"));

function productMedia(_x, _x2, _x3) {
  return _productMedia.apply(this, arguments);
}

function _productMedia() {
  _productMedia = (0, _asyncToGenerator2["default"])( /*#__PURE__*/_regenerator["default"].mark(function _callee(_ref, req, res) {
    var id, color;
    return _regenerator["default"].wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            id = _ref.id, color = _ref.color;
            return _context.abrupt("return", {
              media: (0, _createMedia["default"])(id, color)
            });

          case 2:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));
  return _productMedia.apply(this, arguments);
}
//# sourceMappingURL=productMedia.js.map

/***/ }),

/***/ "./node_modules/react-storefront/mock-connector/productSuggestions.js":
/*!****************************************************************************!*\
  !*** ./node_modules/react-storefront/mock-connector/productSuggestions.js ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = productSuggestions;

var _regenerator = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js"));

var _asyncToGenerator2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/asyncToGenerator.js"));

var _createProduct = _interopRequireDefault(__webpack_require__(/*! ./utils/createProduct */ "./node_modules/react-storefront/mock-connector/utils/createProduct.js"));

/**
 * An example endpoint that returns mock product suggestions for a PDP.
 * @param {*} req
 * @param {*} res
 */
function productSuggestions(_x, _x2) {
  return _productSuggestions.apply(this, arguments);
}

function _productSuggestions() {
  _productSuggestions = (0, _asyncToGenerator2["default"])( /*#__PURE__*/_regenerator["default"].mark(function _callee(req, res) {
    var products, i;
    return _regenerator["default"].wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            products = [];

            for (i = 1; i <= 10; i++) {
              products.push((0, _createProduct["default"])(i));
            }

            return _context.abrupt("return", products);

          case 3:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));
  return _productSuggestions.apply(this, arguments);
}
//# sourceMappingURL=productSuggestions.js.map

/***/ }),

/***/ "./node_modules/react-storefront/mock-connector/removeCartItem.js":
/*!************************************************************************!*\
  !*** ./node_modules/react-storefront/mock-connector/removeCartItem.js ***!
  \************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = removeCartItem;

var _regenerator = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js"));

var _asyncToGenerator2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/asyncToGenerator.js"));

var _cartStore = __webpack_require__(/*! ./utils/cartStore */ "./node_modules/react-storefront/mock-connector/utils/cartStore.js");

function removeCartItem(_x, _x2, _x3) {
  return _removeCartItem.apply(this, arguments);
}

function _removeCartItem() {
  _removeCartItem = (0, _asyncToGenerator2["default"])( /*#__PURE__*/_regenerator["default"].mark(function _callee(item, req, res) {
    return _regenerator["default"].wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            return _context.abrupt("return", {
              cart: {
                items: (0, _cartStore.removeItem)(item.id, req, res)
              }
            });

          case 1:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));
  return _removeCartItem.apply(this, arguments);
}
//# sourceMappingURL=removeCartItem.js.map

/***/ }),

/***/ "./node_modules/react-storefront/mock-connector/search.js":
/*!****************************************************************!*\
  !*** ./node_modules/react-storefront/mock-connector/search.js ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js");

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "default", {
  enumerable: true,
  get: function get() {
    return _subcategory["default"];
  }
});

var _subcategory = _interopRequireDefault(__webpack_require__(/*! ./subcategory */ "./node_modules/react-storefront/mock-connector/subcategory.js"));
//# sourceMappingURL=search.js.map

/***/ }),

/***/ "./node_modules/react-storefront/mock-connector/searchSuggestions.js":
/*!***************************************************************************!*\
  !*** ./node_modules/react-storefront/mock-connector/searchSuggestions.js ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = searchSuggestions;

var _regenerator = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js"));

var _asyncToGenerator2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/asyncToGenerator.js"));

/**
 * An example implementation of the API for the SearchPopup component using placeholder data.
 * @param {Object} params
 * @param {String} params.q The search text
 * @return {Object} An object whose shape matches AppModelBase
 */
function searchSuggestions(_x, _x2, _x3) {
  return _searchSuggestions.apply(this, arguments);
}

function _searchSuggestions() {
  _searchSuggestions = (0, _asyncToGenerator2["default"])( /*#__PURE__*/_regenerator["default"].mark(function _callee(q, req, res) {
    return _regenerator["default"].wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            return _context.abrupt("return", {
              text: q,
              groups: [{
                caption: 'Suggested Searches',
                ui: 'list',
                links: ["Small ".concat(q), "Large ".concat(q), "".concat(q, " with red stripes")].map(function (text) {
                  return {
                    text: text,
                    as: "/search?q=".concat(encodeURIComponent(text)),
                    href: '/search'
                  };
                })
              }, {
                caption: 'Suggested Categories',
                ui: 'list',
                links: [{
                  text: 'Category 1',
                  href: '/s/[subcategoryId]',
                  as: '/s/1'
                }, {
                  text: 'Category 2',
                  href: '/s/[subcategoryId]',
                  as: '/s/2'
                }, {
                  text: 'Category 3',
                  href: '/s/[subcategoryId]',
                  as: '/s/3'
                }]
              }, {
                caption: 'Suggested Products',
                ui: 'thumbnails',
                links: [{
                  text: 'Product 1',
                  href: '/p/[productId]',
                  as: '/p/1?s=1&c=1',
                  thumbnail: {
                    src: 'https://dummyimage.com/120x120',
                    alt: 'Product 1'
                  }
                }, {
                  text: 'Product 2',
                  href: '/p/[productId]',
                  as: '/p/2?s=1&c=1',
                  thumbnail: {
                    src: 'https://dummyimage.com/120x120',
                    alt: 'Product 1'
                  }
                }, {
                  text: 'Product 3',
                  href: '/p/[productId]',
                  as: '/p/3?s=1&c=1',
                  thumbnail: {
                    src: 'https://dummyimage.com/120x120',
                    alt: 'Product 1'
                  }
                }, {
                  text: 'Product 4',
                  href: '/p/[productId]',
                  as: '/p/3?s=1&c=1',
                  thumbnail: {
                    src: 'https://dummyimage.com/120x120',
                    alt: 'Product 1'
                  }
                }, {
                  text: 'Product 5',
                  href: '/p/[productId]',
                  as: '/p/5?s=1&c=1',
                  thumbnail: {
                    src: 'https://dummyimage.com/120x120',
                    alt: 'Product 1'
                  }
                }]
              }]
            });

          case 1:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));
  return _searchSuggestions.apply(this, arguments);
}
//# sourceMappingURL=searchSuggestions.js.map

/***/ }),

/***/ "./node_modules/react-storefront/mock-connector/session.js":
/*!*****************************************************************!*\
  !*** ./node_modules/react-storefront/mock-connector/session.js ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = session;

var _regenerator = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js"));

var _asyncToGenerator2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/asyncToGenerator.js"));

var _cartStore = __webpack_require__(/*! ./utils/cartStore */ "./node_modules/react-storefront/mock-connector/utils/cartStore.js");

function session(_x, _x2) {
  return _session.apply(this, arguments);
}

function _session() {
  _session = (0, _asyncToGenerator2["default"])( /*#__PURE__*/_regenerator["default"].mark(function _callee(req, res) {
    return _regenerator["default"].wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            return _context.abrupt("return", {
              name: 'Mark',
              email: 'mark@domain.com',
              cart: {
                items: (0, _cartStore.getProducts)(req, res)
              },
              currency: 'USD'
            });

          case 1:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));
  return _session.apply(this, arguments);
}
//# sourceMappingURL=session.js.map

/***/ }),

/***/ "./node_modules/react-storefront/mock-connector/subcategory.js":
/*!*********************************************************************!*\
  !*** ./node_modules/react-storefront/mock-connector/subcategory.js ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireWildcard = __webpack_require__(/*! @babel/runtime/helpers/interopRequireWildcard */ "./node_modules/@babel/runtime/helpers/interopRequireWildcard.js");

var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = subcategory;

var _regenerator = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js"));

var _toConsumableArray2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/toConsumableArray */ "./node_modules/@babel/runtime/helpers/toConsumableArray.js"));

var _asyncToGenerator2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/asyncToGenerator.js"));

var _createFacets = _interopRequireDefault(__webpack_require__(/*! ./utils/createFacets */ "./node_modules/react-storefront/mock-connector/utils/createFacets.js"));

var _createSortOptions = _interopRequireDefault(__webpack_require__(/*! ./utils/createSortOptions */ "./node_modules/react-storefront/mock-connector/utils/createSortOptions.js"));

var _createProduct = _interopRequireDefault(__webpack_require__(/*! ./utils/createProduct */ "./node_modules/react-storefront/mock-connector/utils/createProduct.js"));

var _colors = _interopRequireWildcard(__webpack_require__(/*! ./utils/colors */ "./node_modules/react-storefront/mock-connector/utils/colors.js"));

var _fulfillAPIRequest = _interopRequireDefault(__webpack_require__(/*! react-storefront/props/fulfillAPIRequest */ "react-storefront/props/fulfillAPIRequest"));

var _createAppData = _interopRequireDefault(__webpack_require__(/*! ./utils/createAppData */ "./node_modules/react-storefront/mock-connector/utils/createAppData.js"));

function _createForOfIteratorHelper(o, allowArrayLike) { var it; if (typeof Symbol === "undefined" || o[Symbol.iterator] == null) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = o[Symbol.iterator](); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function subcategory(_x, _x2, _x3) {
  return _subcategory.apply(this, arguments);
}

function _subcategory() {
  _subcategory = (0, _asyncToGenerator2["default"])( /*#__PURE__*/_regenerator["default"].mark(function _callee(params, req, res) {
    var q, _params$slug, slug, _params$page, page, filters, sort, _params$more, more;

    return _regenerator["default"].wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            q = params.q, _params$slug = params.slug, slug = _params$slug === void 0 ? '1' : _params$slug, _params$page = params.page, page = _params$page === void 0 ? 0 : _params$page, filters = params.filters, sort = params.sort, _params$more = params.more, more = _params$more === void 0 ? false : _params$more;

            if (filters) {
              filters = JSON.parse(filters);
            } else {
              filters = [];
            }

            _context.next = 4;
            return (0, _fulfillAPIRequest["default"])(req, {
              appData: _createAppData["default"],
              pageData: function pageData() {
                return Promise.resolve({
                  id: slug,
                  name: q != null ? "Results for \"".concat(q, "\"") : "Subcategory ".concat(slug),
                  title: q != null ? "Results for \"".concat(q, "\"") : "Subcategory ".concat(slug),
                  total: 100,
                  page: parseInt(page),
                  totalPages: 5,
                  filters: filters,
                  sort: sort,
                  sortOptions: (0, _createSortOptions["default"])(),
                  facets: (0, _createFacets["default"])(),
                  products: filterProducts(page, filters, more),
                  breadcrumbs: [{
                    text: "Home",
                    href: '/'
                  }]
                });
              }
            });

          case 4:
            return _context.abrupt("return", _context.sent);

          case 5:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));
  return _subcategory.apply(this, arguments);
}

function filterProducts(page, filters, more) {
  var products = [];
  var filteredColors = filters ? filters.filter(function (f) {
    return f.startsWith('color');
  }).map(function (f) {
    return f.replace(/^color:/, '');
  }) : [];
  var count = more ? 20 : 10;

  while (products.length < count) {
    if (filteredColors && filteredColors.length) {
      var _iterator = _createForOfIteratorHelper(filteredColors),
          _step;

      try {
        var _loop = function _loop() {
          var color = _step.value;
          var index = (0, _colors.indexForColor)(color);

          var colorGap = function colorGap(i) {
            return Math.floor(page * count / filteredColors.length) + i;
          };

          products.push.apply(products, (0, _toConsumableArray2["default"])(Array.from({
            length: count
          }, function (v, i) {
            return colorGap(i);
          }).map(function (i) {
            return (0, _createProduct["default"])('' + (i * Object.keys(_colors["default"]).length + index));
          })));
        };

        for (_iterator.s(); !(_step = _iterator.n()).done;) {
          _loop();
        }
      } catch (err) {
        _iterator.e(err);
      } finally {
        _iterator.f();
      }
    } else {
      var id = page * 10 + products.length + 1;
      products.push((0, _createProduct["default"])(id + ''));
    }
  }

  return products.sort(function (a, b) {
    return a.id - b.id;
  }).slice(0, count);
}
//# sourceMappingURL=subcategory.js.map

/***/ }),

/***/ "./node_modules/react-storefront/mock-connector/updateCartItem.js":
/*!************************************************************************!*\
  !*** ./node_modules/react-storefront/mock-connector/updateCartItem.js ***!
  \************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = updateCartItem;

var _cartStore = __webpack_require__(/*! ./utils/cartStore */ "./node_modules/react-storefront/mock-connector/utils/cartStore.js");

function updateCartItem(item, quantity, req, res) {
  return {
    cart: {
      items: (0, _cartStore.updateItem)(item.id, quantity, req, res)
    }
  };
}
//# sourceMappingURL=updateCartItem.js.map

/***/ }),

/***/ "./node_modules/react-storefront/mock-connector/utils/cartStore.js":
/*!*************************************************************************!*\
  !*** ./node_modules/react-storefront/mock-connector/utils/cartStore.js ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getProducts = getProducts;
exports.updateItem = updateItem;
exports.removeItem = removeItem;
exports.addItem = addItem;

var _toConsumableArray2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/toConsumableArray */ "./node_modules/@babel/runtime/helpers/toConsumableArray.js"));

var _defineProperty2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "./node_modules/@babel/runtime/helpers/defineProperty.js"));

var _createProduct = _interopRequireDefault(__webpack_require__(/*! ./createProduct */ "./node_modules/react-storefront/mock-connector/utils/createProduct.js"));

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { (0, _defineProperty2["default"])(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

var CART_COOKIE = 'rsf_mock_cart';
var initialStore = [{
  id: 1,
  quantity: 1
}, {
  id: 2,
  quantity: 1
}];

function getStore(req, res) {
  if (!req.cookies[CART_COOKIE]) {
    res.setHeader('Set-Cookie', "".concat(CART_COOKIE, "=").concat(JSON.stringify(initialStore), "; Path=/"));
  }

  var store = req.cookies[CART_COOKIE] || initialStore;

  try {
    return JSON.parse(store);
  } catch (err) {
    console.log('Failed parsing store from cookie', req.cookies[CART_COOKIE]);
    return [];
  }
}

function toProduct(_ref) {
  var id = _ref.id,
      quantity = _ref.quantity;
  return _objectSpread(_objectSpread({}, (0, _createProduct["default"])(id)), {}, {
    quantity: quantity
  });
}

function getProducts(req, res) {
  return getStore(req, res).map(toProduct);
}

function updateItem(id, quantity, req, res) {
  var newStore = (0, _toConsumableArray2["default"])(getStore(req, res));
  var item = newStore.find(function (e) {
    return e.id === id;
  });
  item.quantity = quantity;
  res.setHeader('Set-Cookie', "".concat(CART_COOKIE, "=").concat(JSON.stringify(newStore), "; Path=/"));
  return newStore.map(toProduct);
}

function removeItem(id, req, res) {
  var newStore = (0, _toConsumableArray2["default"])(getStore(req, res)).filter(function (e) {
    return e.id !== id;
  });
  res.setHeader('Set-Cookie', "".concat(CART_COOKIE, "=").concat(JSON.stringify(newStore), "; Path=/"));
  return newStore.map(toProduct);
}

function addItem(id, quantity, req, res) {
  var newStore = [{
    id: id,
    quantity: quantity
  }].concat((0, _toConsumableArray2["default"])(getStore(req, res)));
  res.setHeader('Set-Cookie', "".concat(CART_COOKIE, "=").concat(JSON.stringify(newStore), "; Path=/"));
  return newStore.map(toProduct);
}
//# sourceMappingURL=cartStore.js.map

/***/ }),

/***/ "./node_modules/react-storefront/mock-connector/utils/colors.js":
/*!**********************************************************************!*\
  !*** ./node_modules/react-storefront/mock-connector/utils/colors.js ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.colorForId = colorForId;
exports.indexForColor = indexForColor;
exports["default"] = void 0;

var _colors = __webpack_require__(/*! @material-ui/core/colors */ "@material-ui/core/colors");

var color = function color(c) {
  return c.toString().replace(/\#/, '');
};

var colors = {
  red: {
    background: color(_colors.red[500]),
    foreground: 'ffffff'
  },
  green: {
    background: color(_colors.green[500]),
    foreground: 'ffffff'
  },
  blue: {
    background: color(_colors.blue[500]),
    foreground: 'ffffff'
  },
  grey: {
    background: color(_colors.grey[300]),
    foreground: color(_colors.grey[600])
  },
  teal: {
    background: color(_colors.teal[500]),
    foreground: 'ffffff'
  },
  orange: {
    background: color(_colors.orange[500]),
    foreground: 'ffffff'
  },
  purple: {
    background: color(_colors.purple[500]),
    foreground: 'ffffff'
  },
  black: {
    background: color(_colors.grey[800]),
    foreground: 'ffffff'
  }
};
var _default = colors;
exports["default"] = _default;

function colorForId(id) {
  var keys = Object.keys(colors);
  var index = id % keys.length;
  return keys[index];
}

function indexForColor(color) {
  return Object.keys(colors).indexOf(color);
}
//# sourceMappingURL=colors.js.map

/***/ }),

/***/ "./node_modules/react-storefront/mock-connector/utils/createAppData.js":
/*!*****************************************************************************!*\
  !*** ./node_modules/react-storefront/mock-connector/utils/createAppData.js ***!
  \*****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = createAppData;

var _createMenu = _interopRequireDefault(__webpack_require__(/*! ./createMenu */ "./node_modules/react-storefront/mock-connector/utils/createMenu.js"));

var _createTabs = _interopRequireDefault(__webpack_require__(/*! ./createTabs */ "./node_modules/react-storefront/mock-connector/utils/createTabs.js"));

function createAppData() {
  return Promise.resolve({
    menu: (0, _createMenu["default"])(),
    tabs: (0, _createTabs["default"])()
  });
}
//# sourceMappingURL=createAppData.js.map

/***/ }),

/***/ "./node_modules/react-storefront/mock-connector/utils/createFacets.js":
/*!****************************************************************************!*\
  !*** ./node_modules/react-storefront/mock-connector/utils/createFacets.js ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = createFacets;

var _colors = _interopRequireDefault(__webpack_require__(/*! ./colors */ "./node_modules/react-storefront/mock-connector/utils/colors.js"));

var _capitalize = _interopRequireDefault(__webpack_require__(/*! lodash/capitalize */ "lodash/capitalize"));

function createFacets() {
  return [{
    name: 'Color',
    ui: 'buttons',
    options: Object.keys(_colors["default"]).map(function (name) {
      return {
        name: (0, _capitalize["default"])(name),
        code: "color:".concat(name),
        image: {
          src: "https://dummyimage.com/48x48/".concat(_colors["default"][name].background, "?text=").concat(encodeURIComponent(' ')),
          alt: name
        }
      };
    })
  }, {
    name: 'Size',
    ui: 'buttons',
    options: [{
      name: 'SM',
      code: 'size:sm'
    }, {
      name: 'MD',
      code: 'size:md'
    }, {
      name: 'LG',
      code: 'size:lg'
    }, {
      name: 'XL',
      code: 'size:xl'
    }, {
      name: 'XXL',
      code: 'size:xxl'
    }]
  }, {
    name: 'Type',
    ui: 'checkboxes',
    options: [{
      name: 'New',
      code: 'type:new',
      matches: 100
    }, {
      name: 'Used',
      code: 'type:used',
      matches: 20
    }]
  }];
}
//# sourceMappingURL=createFacets.js.map

/***/ }),

/***/ "./node_modules/react-storefront/mock-connector/utils/createMedia.js":
/*!***************************************************************************!*\
  !*** ./node_modules/react-storefront/mock-connector/utils/createMedia.js ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = createMedia;

var _colors = _interopRequireDefault(__webpack_require__(/*! ./colors */ "./node_modules/react-storefront/mock-connector/utils/colors.js"));

function createMedia(id, color) {
  return {
    full: [color].map(function (key, i) {
      return {
        src: "https://dummyimage.com/".concat(i === 2 ? 400 : 600, "x").concat(i === 1 ? 400 : 600, "/").concat(_colors["default"][key].background, "/").concat(_colors["default"][key].foreground, "?text=").concat(encodeURIComponent('Product ' + id)),
        alt: "Product ".concat(id),
        magnify: {
          height: i === 1 ? 800 : 1200,
          width: i === 2 ? 800 : 1200,
          src: "https://dummyimage.com/".concat(i === 2 ? 800 : 1200, "x").concat(i === 1 ? 800 : 1200, "/").concat(_colors["default"][key].background, "/").concat(_colors["default"][key].foreground, "?text=").concat(encodeURIComponent('Product ' + id))
        }
      };
    }),
    thumbnails: [color].map(function (key, i) {
      return {
        src: "https://dummyimage.com/".concat(i === 2 ? 300 : 400, "x").concat(i === 1 ? 300 : 400, "/").concat(_colors["default"][key].background, "?text=").concat(encodeURIComponent("Product ".concat(id))),
        alt: key
      };
    })
  };
}
//# sourceMappingURL=createMedia.js.map

/***/ }),

/***/ "./node_modules/react-storefront/mock-connector/utils/createMenu.js":
/*!**************************************************************************!*\
  !*** ./node_modules/react-storefront/mock-connector/utils/createMenu.js ***!
  \**************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = createMenu;

function createMenu() {
  var items = [];

  for (var i = 1; i <= 5; i++) {
    items.push(createCategoryItem(i));
  }

  return {
    items: items,
    header: 'header',
    footer: 'footer'
  };
}

function createCategoryItem(i) {
  var items = [];

  for (var j = 1; j <= 5; j++) {
    items.push(createSubcategoryItem(j));
  }

  return {
    text: "Category ".concat(i),
    items: items
  };
}

function createSubcategoryItem(i) {
  var items = [];

  for (var j = 1; j <= 5; j++) {
    items.push(createProductItem(j));
  }

  return {
    text: "Subcategory ".concat(i),
    href: "/s/[...categorySlug]",
    as: "/s/".concat(i),
    expanded: i === 1,
    items: items
  };
}

function createProductItem(i) {
  return {
    text: "Product ".concat(i),
    href: "/p/[productId]",
    as: "/p/".concat(i)
  };
}
//# sourceMappingURL=createMenu.js.map

/***/ }),

/***/ "./node_modules/react-storefront/mock-connector/utils/createProduct.js":
/*!*****************************************************************************!*\
  !*** ./node_modules/react-storefront/mock-connector/utils/createProduct.js ***!
  \*****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js");

var _interopRequireWildcard = __webpack_require__(/*! @babel/runtime/helpers/interopRequireWildcard */ "./node_modules/@babel/runtime/helpers/interopRequireWildcard.js");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = createProduct;

var _colors = _interopRequireWildcard(__webpack_require__(/*! ./colors */ "./node_modules/react-storefront/mock-connector/utils/colors.js"));

var _capitalize = _interopRequireDefault(__webpack_require__(/*! lodash/capitalize */ "lodash/capitalize"));

var _loremIpsum = __webpack_require__(/*! lorem-ipsum */ "lorem-ipsum");

function createProduct(id) {
  var numColors = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 4;
  var color = (0, _colors.colorForId)(id);
  var variants = [color, 'red', 'blue'];
  var price = id % 10 * 10 + 0.99;
  return {
    id: id,
    url: "/p/".concat(id),
    name: "Product ".concat(id),
    price: price,
    priceText: "$".concat(price),
    rating: (10 - id % 10) / 2.0,
    thumbnail: {
      src: "https://dummyimage.com/400x400/".concat(_colors["default"][color].background, "/").concat(_colors["default"][color].foreground, "?text=").concat(encodeURIComponent('Product ' + id)),
      alt: "Product ".concat(id)
    },
    media: {
      full: variants.map(function (key, i) {
        return {
          src: "https://dummyimage.com/".concat(i === 2 ? 400 : 600, "x").concat(i === 1 ? 400 : 600, "/").concat(_colors["default"][key].background, "/").concat(_colors["default"][key].foreground, "?text=").concat(encodeURIComponent('Product ' + id)),
          alt: "Product ".concat(id),
          magnify: {
            height: i === 1 ? 800 : 1200,
            width: i === 2 ? 800 : 1200,
            src: "https://dummyimage.com/".concat(i === 2 ? 800 : 1200, "x").concat(i === 1 ? 800 : 1200, "/").concat(_colors["default"][key].background, "/").concat(_colors["default"][key].foreground, "?text=").concat(encodeURIComponent('Product ' + id))
          }
        };
      }),
      thumbnails: variants.map(function (key, i) {
        return {
          src: "https://dummyimage.com/".concat(i === 2 ? 233 : 300, "x").concat(i === 1 ? 233 : 300, "/").concat(_colors["default"][key].background, "/").concat(_colors["default"][key].foreground, "?text=").concat(encodeURIComponent('Product ' + id)),
          alt: "Product ".concat(id)
        };
      })
    },
    sizes: [{
      id: 'sm',
      text: 'SM'
    }, {
      id: 'md',
      text: 'MD'
    }, {
      id: 'lg',
      text: 'LG'
    }, {
      id: 'xl',
      text: 'XL',
      disabled: true
    }, {
      id: 'xxl',
      text: 'XXL'
    }],
    description: (0, _loremIpsum.loremIpsum)({
      count: 10
    }),
    specs: (0, _loremIpsum.loremIpsum)({
      count: 10
    }),
    colors: Object.keys(_colors["default"]).slice(0, numColors).map(function (name, idx) {
      return {
        text: (0, _capitalize["default"])(name),
        id: name,
        disabled: idx === 2,
        image: {
          src: "https://dummyimage.com/48x48/".concat(_colors["default"][name].background, "?text=").concat(encodeURIComponent(' ')),
          alt: name
        },
        media: {
          full: [name, name, name].map(function (key, i) {
            return {
              src: "https://dummyimage.com/".concat(i === 2 ? 400 : 600, "x").concat(i === 1 ? 400 : 600, "/").concat(_colors["default"][key].background, "/").concat(_colors["default"][key].foreground, "?text=").concat(encodeURIComponent('Product ' + id)),
              alt: "Product ".concat(id),
              magnify: {
                height: i === 1 ? 800 : 1200,
                width: i === 2 ? 800 : 1200,
                src: "https://dummyimage.com/".concat(i === 2 ? 800 : 1200, "x").concat(i === 1 ? 800 : 1200, "/").concat(_colors["default"][key].background, "/").concat(_colors["default"][key].foreground, "?text=").concat(encodeURIComponent('Product ' + id))
              }
            };
          }),
          thumbnails: [name, name, name].map(function (key, i) {
            return {
              src: "https://dummyimage.com/".concat(i === 2 ? 300 : 400, "x").concat(i === 1 ? 300 : 400, "/").concat(_colors["default"][key].background, "/").concat(_colors["default"][key].foreground, "?text=").concat(encodeURIComponent("Product ".concat(id))),
              alt: key
            };
          }),
          thumbnail: [name].map(function (key) {
            return {
              src: "https://dummyimage.com/400x400/".concat(_colors["default"][key].background, "/").concat(_colors["default"][key].foreground, "?text=").concat(encodeURIComponent('Product ' + id)),
              alt: "Product ".concat(id)
            };
          })[0]
        }
      };
    })
  };
}
//# sourceMappingURL=createProduct.js.map

/***/ }),

/***/ "./node_modules/react-storefront/mock-connector/utils/createSortOptions.js":
/*!*********************************************************************************!*\
  !*** ./node_modules/react-storefront/mock-connector/utils/createSortOptions.js ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = createSortOptions;

function createSortOptions() {
  return [{
    name: 'Price - Lowest',
    code: 'price_asc'
  }, {
    name: 'Price - Highest',
    code: 'price_desc'
  }, {
    name: 'Most Popular',
    code: 'pop'
  }, {
    name: 'Highest Rated',
    code: 'rating'
  }];
}
//# sourceMappingURL=createSortOptions.js.map

/***/ }),

/***/ "./node_modules/react-storefront/mock-connector/utils/createTabs.js":
/*!**************************************************************************!*\
  !*** ./node_modules/react-storefront/mock-connector/utils/createTabs.js ***!
  \**************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = createTabs;

function createTabs() {
  var tabs = [];
  var subcategories = [];

  for (var i = 1; i <= 3; i++) {
    subcategories.push({
      as: "/s/".concat(i),
      href: '/s/[...categorySlug]',
      text: "Subcategory ".concat(i)
    });
  }

  for (var _i = 1; _i <= 10; _i++) {
    tabs.push({
      as: "/s/".concat(_i),
      href: '/s/[...categorySlug]',
      text: "Category ".concat(_i),
      items: subcategories
    });
  }

  return tabs;
}
//# sourceMappingURL=createTabs.js.map

/***/ }),

/***/ "./node_modules/react-storefront/props/fulfillAPIRequest.js":
/*!******************************************************************!*\
  !*** ./node_modules/react-storefront/props/fulfillAPIRequest.js ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = fulfillAPIRequest;

var _regenerator = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js"));

var _asyncToGenerator2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/asyncToGenerator.js"));

function _createForOfIteratorHelper(o, allowArrayLike) { var it; if (typeof Symbol === "undefined" || o[Symbol.iterator] == null) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = o[Symbol.iterator](); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

/**
 * Creates an API response that contains app level data only when `?_includeAppData=1` is present in
 * the query string. Otherwise, the `appData` promise provided will not be resolved.
 *
 * @param {Request} req The request being served
 * @param {Object} options
 * @param {Function} options.appData An async function that returns a data for shared component in
 * the app such as menu, nav, and footer
 * @param {Function} options.pageData An async function that return data for the page component
 * @return {Object} the result of `appData` and `pageData` merged into a single object.
 */
function fulfillAPIRequest(_x, _x2) {
  return _fulfillAPIRequest.apply(this, arguments);
}

function _fulfillAPIRequest() {
  _fulfillAPIRequest = (0, _asyncToGenerator2["default"])( /*#__PURE__*/_regenerator["default"].mark(function _callee(req, _ref) {
    var appData, pageData, promises, results, data, _iterator, _step, result;

    return _regenerator["default"].wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            appData = _ref.appData, pageData = _ref.pageData;
            promises = [pageData(req).then(function (pageData) {
              return {
                pageData: pageData
              };
            })];

            if (req.query._includeAppData === '1') {
              promises.push(appData(req).then(function (appData) {
                return {
                  appData: appData
                };
              }));
            }

            _context.next = 5;
            return Promise.all(promises);

          case 5:
            results = _context.sent;
            data = {};
            _iterator = _createForOfIteratorHelper(results);

            try {
              for (_iterator.s(); !(_step = _iterator.n()).done;) {
                result = _step.value;
                Object.assign(data, result);
              }
            } catch (err) {
              _iterator.e(err);
            } finally {
              _iterator.f();
            }

            return _context.abrupt("return", data);

          case 10:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));
  return _fulfillAPIRequest.apply(this, arguments);
}
//# sourceMappingURL=fulfillAPIRequest.js.map

/***/ }),

/***/ "./pages/api/index.js":
/*!****************************!*\
  !*** ./pages/api/index.js ***!
  \****************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_storefront_connector__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react-storefront-connector */ "./node_modules/react-storefront/mock-connector/index.js");
/* harmony import */ var react_storefront_connector__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_storefront_connector__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ __webpack_exports__["default"] = (async function (req, res) {
  res.json(await Object(react_storefront_connector__WEBPACK_IMPORTED_MODULE_0__["home"])(req, res));
});

/***/ }),

/***/ "@material-ui/core/colors":
/*!*******************************************!*\
  !*** external "@material-ui/core/colors" ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/colors");

/***/ }),

/***/ "lodash/capitalize":
/*!************************************!*\
  !*** external "lodash/capitalize" ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("lodash/capitalize");

/***/ }),

/***/ "lorem-ipsum":
/*!******************************!*\
  !*** external "lorem-ipsum" ***!
  \******************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("lorem-ipsum");

/***/ }),

/***/ "react-storefront/props/fulfillAPIRequest":
/*!***********************************************************!*\
  !*** external "react-storefront/props/fulfillAPIRequest" ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react-storefront/props/fulfillAPIRequest");

/***/ }),

/***/ "react-storefront/utils/getBase64ForImage":
/*!***********************************************************!*\
  !*** external "react-storefront/utils/getBase64ForImage" ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react-storefront/utils/getBase64ForImage");

/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL0BiYWJlbC9ydW50aW1lL2hlbHBlcnMvYXJyYXlMaWtlVG9BcnJheS5qcyIsIndlYnBhY2s6Ly8vLi9ub2RlX21vZHVsZXMvQGJhYmVsL3J1bnRpbWUvaGVscGVycy9hcnJheVdpdGhvdXRIb2xlcy5qcyIsIndlYnBhY2s6Ly8vLi9ub2RlX21vZHVsZXMvQGJhYmVsL3J1bnRpbWUvaGVscGVycy9hc3luY1RvR2VuZXJhdG9yLmpzIiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy9AYmFiZWwvcnVudGltZS9oZWxwZXJzL2RlZmluZVByb3BlcnR5LmpzIiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy9AYmFiZWwvcnVudGltZS9oZWxwZXJzL2ludGVyb3BSZXF1aXJlRGVmYXVsdC5qcyIsIndlYnBhY2s6Ly8vLi9ub2RlX21vZHVsZXMvQGJhYmVsL3J1bnRpbWUvaGVscGVycy9pbnRlcm9wUmVxdWlyZVdpbGRjYXJkLmpzIiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy9AYmFiZWwvcnVudGltZS9oZWxwZXJzL2l0ZXJhYmxlVG9BcnJheS5qcyIsIndlYnBhY2s6Ly8vLi9ub2RlX21vZHVsZXMvQGJhYmVsL3J1bnRpbWUvaGVscGVycy9ub25JdGVyYWJsZVNwcmVhZC5qcyIsIndlYnBhY2s6Ly8vLi9ub2RlX21vZHVsZXMvQGJhYmVsL3J1bnRpbWUvaGVscGVycy9yZWdlbmVyYXRvclJ1bnRpbWUuanMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL0BiYWJlbC9ydW50aW1lL2hlbHBlcnMvdG9Db25zdW1hYmxlQXJyYXkuanMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL0BiYWJlbC9ydW50aW1lL2hlbHBlcnMvdHlwZW9mLmpzIiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy9AYmFiZWwvcnVudGltZS9oZWxwZXJzL3Vuc3VwcG9ydGVkSXRlcmFibGVUb0FycmF5LmpzIiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy9AYmFiZWwvcnVudGltZS9yZWdlbmVyYXRvci9pbmRleC5qcyIsIndlYnBhY2s6Ly8vLi9ub2RlX21vZHVsZXMvcmVhY3Qtc3RvcmVmcm9udC9tb2NrLWNvbm5lY3Rvci9hY2NvdW50LmpzIiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy9yZWFjdC1zdG9yZWZyb250L21vY2stY29ubmVjdG9yL2FkZFRvQ2FydC5qcyIsIndlYnBhY2s6Ly8vLi9ub2RlX21vZHVsZXMvcmVhY3Qtc3RvcmVmcm9udC9tb2NrLWNvbm5lY3Rvci9jYXJ0LmpzIiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy9yZWFjdC1zdG9yZWZyb250L21vY2stY29ubmVjdG9yL2hvbWUuanMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL3JlYWN0LXN0b3JlZnJvbnQvbW9jay1jb25uZWN0b3IvaW5kZXguanMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL3JlYWN0LXN0b3JlZnJvbnQvbW9jay1jb25uZWN0b3IvcHJvZHVjdC5qcyIsIndlYnBhY2s6Ly8vLi9ub2RlX21vZHVsZXMvcmVhY3Qtc3RvcmVmcm9udC9tb2NrLWNvbm5lY3Rvci9wcm9kdWN0TWVkaWEuanMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL3JlYWN0LXN0b3JlZnJvbnQvbW9jay1jb25uZWN0b3IvcHJvZHVjdFN1Z2dlc3Rpb25zLmpzIiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy9yZWFjdC1zdG9yZWZyb250L21vY2stY29ubmVjdG9yL3JlbW92ZUNhcnRJdGVtLmpzIiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy9yZWFjdC1zdG9yZWZyb250L21vY2stY29ubmVjdG9yL3NlYXJjaC5qcyIsIndlYnBhY2s6Ly8vLi9ub2RlX21vZHVsZXMvcmVhY3Qtc3RvcmVmcm9udC9tb2NrLWNvbm5lY3Rvci9zZWFyY2hTdWdnZXN0aW9ucy5qcyIsIndlYnBhY2s6Ly8vLi9ub2RlX21vZHVsZXMvcmVhY3Qtc3RvcmVmcm9udC9tb2NrLWNvbm5lY3Rvci9zZXNzaW9uLmpzIiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy9yZWFjdC1zdG9yZWZyb250L21vY2stY29ubmVjdG9yL3N1YmNhdGVnb3J5LmpzIiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy9yZWFjdC1zdG9yZWZyb250L21vY2stY29ubmVjdG9yL3VwZGF0ZUNhcnRJdGVtLmpzIiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy9yZWFjdC1zdG9yZWZyb250L21vY2stY29ubmVjdG9yL3V0aWxzL2NhcnRTdG9yZS5qcyIsIndlYnBhY2s6Ly8vLi9ub2RlX21vZHVsZXMvcmVhY3Qtc3RvcmVmcm9udC9tb2NrLWNvbm5lY3Rvci91dGlscy9jb2xvcnMuanMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL3JlYWN0LXN0b3JlZnJvbnQvbW9jay1jb25uZWN0b3IvdXRpbHMvY3JlYXRlQXBwRGF0YS5qcyIsIndlYnBhY2s6Ly8vLi9ub2RlX21vZHVsZXMvcmVhY3Qtc3RvcmVmcm9udC9tb2NrLWNvbm5lY3Rvci91dGlscy9jcmVhdGVGYWNldHMuanMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL3JlYWN0LXN0b3JlZnJvbnQvbW9jay1jb25uZWN0b3IvdXRpbHMvY3JlYXRlTWVkaWEuanMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL3JlYWN0LXN0b3JlZnJvbnQvbW9jay1jb25uZWN0b3IvdXRpbHMvY3JlYXRlTWVudS5qcyIsIndlYnBhY2s6Ly8vLi9ub2RlX21vZHVsZXMvcmVhY3Qtc3RvcmVmcm9udC9tb2NrLWNvbm5lY3Rvci91dGlscy9jcmVhdGVQcm9kdWN0LmpzIiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy9yZWFjdC1zdG9yZWZyb250L21vY2stY29ubmVjdG9yL3V0aWxzL2NyZWF0ZVNvcnRPcHRpb25zLmpzIiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy9yZWFjdC1zdG9yZWZyb250L21vY2stY29ubmVjdG9yL3V0aWxzL2NyZWF0ZVRhYnMuanMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL3JlYWN0LXN0b3JlZnJvbnQvcHJvcHMvZnVsZmlsbEFQSVJlcXVlc3QuanMiLCJ3ZWJwYWNrOi8vLy4vcGFnZXMvYXBpL2luZGV4LmpzIiwid2VicGFjazovLy9leHRlcm5hbCBcIkBtYXRlcmlhbC11aS9jb3JlL2NvbG9yc1wiIiwid2VicGFjazovLy9leHRlcm5hbCBcImxvZGFzaC9jYXBpdGFsaXplXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwibG9yZW0taXBzdW1cIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJyZWFjdC1zdG9yZWZyb250L3Byb3BzL2Z1bGZpbGxBUElSZXF1ZXN0XCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwicmVhY3Qtc3RvcmVmcm9udC91dGlscy9nZXRCYXNlNjRGb3JJbWFnZVwiIl0sIm5hbWVzIjpbInJlcSIsInJlcyIsImpzb24iLCJob21lIl0sIm1hcHBpbmdzIjoiOztRQUFBO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0EsSUFBSTtRQUNKO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7OztRQUdBO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQSwwQ0FBMEMsZ0NBQWdDO1FBQzFFO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0Esd0RBQXdELGtCQUFrQjtRQUMxRTtRQUNBLGlEQUFpRCxjQUFjO1FBQy9EOztRQUVBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQSx5Q0FBeUMsaUNBQWlDO1FBQzFFLGdIQUFnSCxtQkFBbUIsRUFBRTtRQUNySTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBLDJCQUEyQiwwQkFBMEIsRUFBRTtRQUN2RCxpQ0FBaUMsZUFBZTtRQUNoRDtRQUNBO1FBQ0E7O1FBRUE7UUFDQSxzREFBc0QsK0RBQStEOztRQUVySDtRQUNBOzs7UUFHQTtRQUNBOzs7Ozs7Ozs7Ozs7QUN4RkE7QUFDQTs7QUFFQSx3Q0FBd0MsU0FBUztBQUNqRDtBQUNBOztBQUVBO0FBQ0E7O0FBRUEsaUg7Ozs7Ozs7Ozs7O0FDVkEsdUJBQXVCLG1CQUFPLENBQUMsd0ZBQXVCOztBQUV0RDtBQUNBO0FBQ0E7O0FBRUEsa0g7Ozs7Ozs7Ozs7O0FDTkE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7O0FBRUEsaUg7Ozs7Ozs7Ozs7O0FDcENBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMLEdBQUc7QUFDSDtBQUNBOztBQUVBO0FBQ0E7O0FBRUEsK0c7Ozs7Ozs7Ozs7O0FDZkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxzSDs7Ozs7Ozs7Ozs7QUNOQSxjQUFjLG1CQUFPLENBQUMsb0VBQWE7O0FBRW5DO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBLHVIOzs7Ozs7Ozs7OztBQ3BEQTtBQUNBO0FBQ0E7O0FBRUEsZ0g7Ozs7Ozs7Ozs7O0FDSkE7QUFDQTtBQUNBOztBQUVBLGtIOzs7Ozs7Ozs7OztBQ0pBLGNBQWMsbUJBQU8sQ0FBQyxvRUFBYTs7QUFFbkM7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxHQUFHO0FBQ0gsa0JBQWtCO0FBQ2xCO0FBQ0E7QUFDQSx5REFBeUQ7QUFDekQ7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDs7QUFFQTtBQUNBLGFBQWE7QUFDYixHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSx5REFBeUQ7QUFDekQ7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLG9GQUFvRjtBQUNwRjtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTs7QUFFQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1AsS0FBSztBQUNMOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0EsU0FBUztBQUNUO0FBQ0EsU0FBUztBQUNUO0FBQ0EsU0FBUztBQUNUOztBQUVBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQix1QkFBdUI7QUFDdkM7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTCxHQUFHO0FBQ0g7QUFDQSxHQUFHO0FBQ0g7QUFDQSxHQUFHO0FBQ0g7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0EsWUFBWSxhQUFhO0FBQ3pCO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBLDhDQUE4QyxRQUFRO0FBQ3REO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQSw4Q0FBOEMsUUFBUTtBQUN0RDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQSw4Q0FBOEMsUUFBUTtBQUN0RDtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQSw4Q0FBOEMsUUFBUTtBQUN0RDs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0EsR0FBRztBQUNIOztBQUVBLG1IOzs7Ozs7Ozs7OztBQ2pXQSx3QkFBd0IsbUJBQU8sQ0FBQywwRkFBd0I7O0FBRXhELHNCQUFzQixtQkFBTyxDQUFDLHNGQUFzQjs7QUFFcEQsaUNBQWlDLG1CQUFPLENBQUMsNEdBQWlDOztBQUUxRSx3QkFBd0IsbUJBQU8sQ0FBQywwRkFBd0I7O0FBRXhEO0FBQ0E7QUFDQTs7QUFFQSxrSDs7Ozs7Ozs7Ozs7QUNaQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQSxHQUFHO0FBQ0g7O0FBRUEsdUc7Ozs7Ozs7Ozs7O0FDVkEsdUJBQXVCLG1CQUFPLENBQUMsd0ZBQXVCOztBQUV0RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLDJIOzs7Ozs7Ozs7OztBQ1hBOztBQUVBLGNBQWMsbUJBQU8sQ0FBQyxrR0FBK0I7QUFDckQ7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNEO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7O0FDZGE7O0FBRWIsNkJBQTZCLG1CQUFPLENBQUMsb0hBQThDOztBQUVuRjtBQUNBO0FBQ0EsQ0FBQztBQUNEOztBQUVBLDBDQUEwQyxtQkFBTyxDQUFDLHNGQUE0Qjs7QUFFOUUsZ0RBQWdELG1CQUFPLENBQUMsMEdBQXlDOztBQUVqRyxnREFBZ0QsbUJBQU8sQ0FBQywrRkFBNkI7O0FBRXJGLDRDQUE0QyxtQkFBTyxDQUFDLG9HQUF1Qjs7QUFFM0U7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDZCQUE2QjtBQUM3QjtBQUNBO0FBQ0E7QUFDQSxtQkFBbUI7QUFDbkIsaUJBQWlCO0FBQ2pCO0FBQ0EsYUFBYTs7QUFFYjtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0wsR0FBRztBQUNIO0FBQ0E7QUFDQSxtQzs7Ozs7Ozs7Ozs7O0FDdERhOztBQUViLDZCQUE2QixtQkFBTyxDQUFDLG9IQUE4Qzs7QUFFbkY7QUFDQTtBQUNBLENBQUM7QUFDRDs7QUFFQSwwQ0FBMEMsbUJBQU8sQ0FBQyxzRkFBNEI7O0FBRTlFLGdEQUFnRCxtQkFBTyxDQUFDLDBHQUF5Qzs7QUFFakcsaUJBQWlCLG1CQUFPLENBQUMsNEZBQW1COztBQUU1QztBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTs7QUFFYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMLEdBQUc7QUFDSDtBQUNBO0FBQ0EscUM7Ozs7Ozs7Ozs7OztBQzFDYTs7QUFFYiw2QkFBNkIsbUJBQU8sQ0FBQyxvSEFBOEM7O0FBRW5GO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7O0FBRUEsMENBQTBDLG1CQUFPLENBQUMsc0ZBQTRCOztBQUU5RSxnREFBZ0QsbUJBQU8sQ0FBQywwR0FBeUM7O0FBRWpHLGdEQUFnRCxtQkFBTyxDQUFDLDhGQUE0Qjs7QUFFcEYsNENBQTRDLG1CQUFPLENBQUMsb0dBQXVCOztBQUUzRSxpQkFBaUIsbUJBQU8sQ0FBQyw0RkFBbUI7O0FBRTVDO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbUJBQW1CO0FBQ25CO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBLGFBQWE7O0FBRWI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTCxHQUFHO0FBQ0g7QUFDQTtBQUNBLGdDOzs7Ozs7Ozs7Ozs7QUN0RGE7O0FBRWIsNkJBQTZCLG1CQUFPLENBQUMsb0hBQThDOztBQUVuRjtBQUNBO0FBQ0EsQ0FBQztBQUNEOztBQUVBLDBDQUEwQyxtQkFBTyxDQUFDLHNGQUE0Qjs7QUFFOUUsZ0RBQWdELG1CQUFPLENBQUMsMEdBQXlDOztBQUVqRyxnREFBZ0QsbUJBQU8sQ0FBQyw4RkFBNEI7O0FBRXBGLDRDQUE0QyxtQkFBTyxDQUFDLG9HQUF1Qjs7QUFFM0U7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0EsYUFBYTs7QUFFYjtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0wsR0FBRztBQUNIO0FBQ0E7QUFDQSxnQzs7Ozs7Ozs7Ozs7O0FDckRhOztBQUViLDZCQUE2QixtQkFBTyxDQUFDLG9IQUE4Qzs7QUFFbkY7QUFDQTtBQUNBLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQzs7QUFFRCxtQ0FBbUMsbUJBQU8sQ0FBQyx5RUFBVzs7QUFFdEQsc0NBQXNDLG1CQUFPLENBQUMsK0VBQWM7O0FBRTVELHdDQUF3QyxtQkFBTyxDQUFDLG1GQUFnQjs7QUFFaEUsNkNBQTZDLG1CQUFPLENBQUMsNkZBQXFCOztBQUUxRSw2Q0FBNkMsbUJBQU8sQ0FBQyw2RkFBcUI7O0FBRTFFLG1DQUFtQyxtQkFBTyxDQUFDLHlFQUFXOztBQUV0RCxzQ0FBc0MsbUJBQU8sQ0FBQywrRUFBYzs7QUFFNUQsMkNBQTJDLG1CQUFPLENBQUMseUZBQW1COztBQUV0RSxpREFBaUQsbUJBQU8sQ0FBQyxxR0FBeUI7O0FBRWxGLHFDQUFxQyxtQkFBTyxDQUFDLDZFQUFhOztBQUUxRCxnREFBZ0QsbUJBQU8sQ0FBQyxtR0FBd0I7O0FBRWhGLHNDQUFzQyxtQkFBTyxDQUFDLCtFQUFjOztBQUU1RCwwQ0FBMEMsbUJBQU8sQ0FBQyx1RkFBa0I7QUFDcEUsaUM7Ozs7Ozs7Ozs7OztBQy9HYTs7QUFFYiw2QkFBNkIsbUJBQU8sQ0FBQyxvSEFBOEM7O0FBRW5GO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7O0FBRUEsMENBQTBDLG1CQUFPLENBQUMsc0ZBQTRCOztBQUU5RSxnREFBZ0QsbUJBQU8sQ0FBQywwR0FBeUM7O0FBRWpHLGdEQUFnRCxtQkFBTyxDQUFDLDhGQUE0Qjs7QUFFcEYsNENBQTRDLG1CQUFPLENBQUMsb0dBQXVCOztBQUUzRSw0Q0FBNEMsbUJBQU8sQ0FBQyxvR0FBdUI7O0FBRTNFLGdEQUFnRCxtQkFBTyxDQUFDLDBGQUEwQzs7QUFFbEc7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhOztBQUViO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGNBQWM7QUFDZDtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTCxHQUFHO0FBQ0g7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxlQUFlO0FBQ2Y7QUFDQTtBQUNBO0FBQ0EsZUFBZTtBQUNmO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMLEdBQUc7QUFDSDtBQUNBO0FBQ0EsbUM7Ozs7Ozs7Ozs7OztBQzdIYTs7QUFFYiw2QkFBNkIsbUJBQU8sQ0FBQyxvSEFBOEM7O0FBRW5GO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7O0FBRUEsMENBQTBDLG1CQUFPLENBQUMsc0ZBQTRCOztBQUU5RSxnREFBZ0QsbUJBQU8sQ0FBQywwR0FBeUM7O0FBRWpHLDBDQUEwQyxtQkFBTyxDQUFDLGdHQUFxQjs7QUFFdkU7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTs7QUFFYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMLEdBQUc7QUFDSDtBQUNBO0FBQ0Esd0M7Ozs7Ozs7Ozs7OztBQ3hDYTs7QUFFYiw2QkFBNkIsbUJBQU8sQ0FBQyxvSEFBOEM7O0FBRW5GO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7O0FBRUEsMENBQTBDLG1CQUFPLENBQUMsc0ZBQTRCOztBQUU5RSxnREFBZ0QsbUJBQU8sQ0FBQywwR0FBeUM7O0FBRWpHLDRDQUE0QyxtQkFBTyxDQUFDLG9HQUF1Qjs7QUFFM0U7QUFDQTtBQUNBLFdBQVcsRUFBRTtBQUNiLFdBQVcsRUFBRTtBQUNiO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsdUJBQXVCLFNBQVM7QUFDaEM7QUFDQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMLEdBQUc7QUFDSDtBQUNBO0FBQ0EsOEM7Ozs7Ozs7Ozs7OztBQ2hEYTs7QUFFYiw2QkFBNkIsbUJBQU8sQ0FBQyxvSEFBOEM7O0FBRW5GO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7O0FBRUEsMENBQTBDLG1CQUFPLENBQUMsc0ZBQTRCOztBQUU5RSxnREFBZ0QsbUJBQU8sQ0FBQywwR0FBeUM7O0FBRWpHLGlCQUFpQixtQkFBTyxDQUFDLDRGQUFtQjs7QUFFNUM7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTs7QUFFYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMLEdBQUc7QUFDSDtBQUNBO0FBQ0EsMEM7Ozs7Ozs7Ozs7OztBQ3hDYTs7QUFFYiw2QkFBNkIsbUJBQU8sQ0FBQyxvSEFBOEM7O0FBRW5GO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7O0FBRUQsMENBQTBDLG1CQUFPLENBQUMsb0ZBQWU7QUFDakUsa0M7Ozs7Ozs7Ozs7OztBQ2ZhOztBQUViLDZCQUE2QixtQkFBTyxDQUFDLG9IQUE4Qzs7QUFFbkY7QUFDQTtBQUNBLENBQUM7QUFDRDs7QUFFQSwwQ0FBMEMsbUJBQU8sQ0FBQyxzRkFBNEI7O0FBRTlFLGdEQUFnRCxtQkFBTyxDQUFDLDBHQUF5Qzs7QUFFakc7QUFDQTtBQUNBLFdBQVcsT0FBTztBQUNsQixXQUFXLE9BQU87QUFDbEIsWUFBWSxPQUFPO0FBQ25CO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakIsZUFBZTtBQUNmO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakI7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCLGVBQWU7QUFDZjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQixlQUFlO0FBQ2YsYUFBYTs7QUFFYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMLEdBQUc7QUFDSDtBQUNBO0FBQ0EsNkM7Ozs7Ozs7Ozs7OztBQ2pIYTs7QUFFYiw2QkFBNkIsbUJBQU8sQ0FBQyxvSEFBOEM7O0FBRW5GO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7O0FBRUEsMENBQTBDLG1CQUFPLENBQUMsc0ZBQTRCOztBQUU5RSxnREFBZ0QsbUJBQU8sQ0FBQywwR0FBeUM7O0FBRWpHLGlCQUFpQixtQkFBTyxDQUFDLDRGQUFtQjs7QUFFNUM7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxlQUFlO0FBQ2Y7QUFDQSxhQUFhOztBQUViO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0wsR0FBRztBQUNIO0FBQ0E7QUFDQSxtQzs7Ozs7Ozs7Ozs7O0FDM0NhOztBQUViLDhCQUE4QixtQkFBTyxDQUFDLHNIQUErQzs7QUFFckYsNkJBQTZCLG1CQUFPLENBQUMsb0hBQThDOztBQUVuRjtBQUNBO0FBQ0EsQ0FBQztBQUNEOztBQUVBLDBDQUEwQyxtQkFBTyxDQUFDLHNGQUE0Qjs7QUFFOUUsaURBQWlELG1CQUFPLENBQUMsNEdBQTBDOztBQUVuRyxnREFBZ0QsbUJBQU8sQ0FBQywwR0FBeUM7O0FBRWpHLDJDQUEyQyxtQkFBTyxDQUFDLGtHQUFzQjs7QUFFekUsZ0RBQWdELG1CQUFPLENBQUMsNEdBQTJCOztBQUVuRiw0Q0FBNEMsbUJBQU8sQ0FBQyxvR0FBdUI7O0FBRTNFLHNDQUFzQyxtQkFBTyxDQUFDLHNGQUFnQjs7QUFFOUQsZ0RBQWdELG1CQUFPLENBQUMsMEZBQTBDOztBQUVsRyw0Q0FBNEMsbUJBQU8sQ0FBQyxvR0FBdUI7O0FBRTNFLHdEQUF3RCxRQUFRLG1FQUFtRSx3SEFBd0gsZ0JBQWdCLFdBQVcseUJBQXlCLFNBQVMsd0JBQXdCLDRCQUE0QixjQUFjLFNBQVMsOEJBQThCLEVBQUUscUJBQXFCLFVBQVUsRUFBRSxTQUFTLEVBQUUsOEpBQThKLEVBQUUsa0RBQWtELFNBQVMsa0JBQWtCLDJCQUEyQixFQUFFLG1CQUFtQixzQkFBc0IsOEJBQThCLGFBQWEsRUFBRSxzQkFBc0IsZUFBZSxXQUFXLEVBQUUsbUJBQW1CLE1BQU0sK0RBQStELEVBQUUsVUFBVSx1QkFBdUIsRUFBRSxFQUFFLEdBQUc7O0FBRW4rQixpREFBaUQsZ0JBQWdCLGdFQUFnRSx3REFBd0QsNkRBQTZELHNEQUFzRCxrSEFBa0g7O0FBRTlaLHNDQUFzQyx1REFBdUQsdUNBQXVDLFNBQVMsT0FBTyxrQkFBa0IsRUFBRSxhQUFhOztBQUVyTDtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbUJBQW1CO0FBQ25CLGlCQUFpQjtBQUNqQjtBQUNBLGFBQWE7O0FBRWI7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMLEdBQUc7QUFDSDtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0EsR0FBRztBQUNIOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0EsV0FBVztBQUNYO0FBQ0EsV0FBVztBQUNYOztBQUVBLDJCQUEyQiwrQkFBK0I7QUFDMUQ7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQSx1Qzs7Ozs7Ozs7Ozs7O0FDOUlhOztBQUViO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7O0FBRUEsaUJBQWlCLG1CQUFPLENBQUMsNEZBQW1COztBQUU1QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDBDOzs7Ozs7Ozs7Ozs7QUNoQmE7O0FBRWIsNkJBQTZCLG1CQUFPLENBQUMsb0hBQThDOztBQUVuRjtBQUNBO0FBQ0EsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBOztBQUVBLGlEQUFpRCxtQkFBTyxDQUFDLDRHQUEwQzs7QUFFbkcsOENBQThDLG1CQUFPLENBQUMsc0dBQXVDOztBQUU3Riw0Q0FBNEMsbUJBQU8sQ0FBQyw4RkFBaUI7O0FBRXJFLDBDQUEwQyxnQ0FBZ0Msb0NBQW9DLG9EQUFvRCw4REFBOEQsZ0VBQWdFLEVBQUUsRUFBRSxnQ0FBZ0MsRUFBRSxhQUFhOztBQUVuVixnQ0FBZ0MsZ0JBQWdCLHNCQUFzQixPQUFPLHVEQUF1RCxhQUFhLHVEQUF1RCw0REFBNEQsRUFBRSxFQUFFLEVBQUUsNkNBQTZDLDJFQUEyRSxFQUFFLE9BQU8saURBQWlELGtGQUFrRixFQUFFLEVBQUUsRUFBRSxFQUFFLGVBQWU7O0FBRXJpQjtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7QUFDRDtBQUNBO0FBQ0EsQ0FBQzs7QUFFRDtBQUNBO0FBQ0EsbUdBQW1HO0FBQ25HOztBQUVBOztBQUVBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsdUNBQXVDLHlDQUF5QztBQUNoRjtBQUNBLEdBQUc7QUFDSDs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQSw2RkFBNkY7QUFDN0Y7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0gsNkZBQTZGO0FBQzdGO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0gsNkZBQTZGO0FBQzdGO0FBQ0E7QUFDQSxxQzs7Ozs7Ozs7Ozs7O0FDcEZhOztBQUViO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7QUFDQTtBQUNBOztBQUVBLGNBQWMsbUJBQU8sQ0FBQywwREFBMEI7O0FBRWhEO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLGtDOzs7Ozs7Ozs7Ozs7QUM3RGE7O0FBRWIsNkJBQTZCLG1CQUFPLENBQUMsb0hBQThDOztBQUVuRjtBQUNBO0FBQ0EsQ0FBQztBQUNEOztBQUVBLHlDQUF5QyxtQkFBTyxDQUFDLHdGQUFjOztBQUUvRCx5Q0FBeUMsbUJBQU8sQ0FBQyx3RkFBYzs7QUFFL0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQSx5Qzs7Ozs7Ozs7Ozs7O0FDbkJhOztBQUViLDZCQUE2QixtQkFBTyxDQUFDLG9IQUE4Qzs7QUFFbkY7QUFDQTtBQUNBLENBQUM7QUFDRDs7QUFFQSxxQ0FBcUMsbUJBQU8sQ0FBQyxnRkFBVTs7QUFFdkQseUNBQXlDLG1CQUFPLENBQUMsNENBQW1COztBQUVwRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTCxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0EsS0FBSztBQUNMLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMLEdBQUc7QUFDSDtBQUNBLHdDOzs7Ozs7Ozs7Ozs7QUM1RGE7O0FBRWIsNkJBQTZCLG1CQUFPLENBQUMsb0hBQThDOztBQUVuRjtBQUNBO0FBQ0EsQ0FBQztBQUNEOztBQUVBLHFDQUFxQyxtQkFBTyxDQUFDLGdGQUFVOztBQUV2RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0EsdUM7Ozs7Ozs7Ozs7OztBQ2hDYTs7QUFFYjtBQUNBO0FBQ0EsQ0FBQztBQUNEOztBQUVBO0FBQ0E7O0FBRUEsaUJBQWlCLFFBQVE7QUFDekI7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQSxpQkFBaUIsUUFBUTtBQUN6QjtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQSxpQkFBaUIsUUFBUTtBQUN6QjtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxzQzs7Ozs7Ozs7Ozs7O0FDekRhOztBQUViLDZCQUE2QixtQkFBTyxDQUFDLG9IQUE4Qzs7QUFFbkYsOEJBQThCLG1CQUFPLENBQUMsc0hBQStDOztBQUVyRjtBQUNBO0FBQ0EsQ0FBQztBQUNEOztBQUVBLHNDQUFzQyxtQkFBTyxDQUFDLGdGQUFVOztBQUV4RCx5Q0FBeUMsbUJBQU8sQ0FBQyw0Q0FBbUI7O0FBRXBFLGtCQUFrQixtQkFBTyxDQUFDLGdDQUFhOztBQUV2QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBLHlDOzs7Ozs7Ozs7Ozs7QUNqSGE7O0FBRWI7QUFDQTtBQUNBLENBQUM7QUFDRDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBLDZDOzs7Ozs7Ozs7Ozs7QUN0QmE7O0FBRWI7QUFDQTtBQUNBLENBQUM7QUFDRDs7QUFFQTtBQUNBO0FBQ0E7O0FBRUEsaUJBQWlCLFFBQVE7QUFDekI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7O0FBRUEsa0JBQWtCLFVBQVU7QUFDNUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDs7QUFFQTtBQUNBO0FBQ0Esc0M7Ozs7Ozs7Ozs7OztBQzlCYTs7QUFFYiw2QkFBNkIsbUJBQU8sQ0FBQyxvSEFBOEM7O0FBRW5GO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7O0FBRUEsMENBQTBDLG1CQUFPLENBQUMsc0ZBQTRCOztBQUU5RSxnREFBZ0QsbUJBQU8sQ0FBQywwR0FBeUM7O0FBRWpHLHdEQUF3RCxRQUFRLG1FQUFtRSx3SEFBd0gsZ0JBQWdCLFdBQVcseUJBQXlCLFNBQVMsd0JBQXdCLDRCQUE0QixjQUFjLFNBQVMsOEJBQThCLEVBQUUscUJBQXFCLFVBQVUsRUFBRSxTQUFTLEVBQUUsOEpBQThKLEVBQUUsa0RBQWtELFNBQVMsa0JBQWtCLDJCQUEyQixFQUFFLG1CQUFtQixzQkFBc0IsOEJBQThCLGFBQWEsRUFBRSxzQkFBc0IsZUFBZSxXQUFXLEVBQUUsbUJBQW1CLE1BQU0sK0RBQStELEVBQUUsVUFBVSx1QkFBdUIsRUFBRSxFQUFFLEdBQUc7O0FBRW4rQixpREFBaUQsZ0JBQWdCLGdFQUFnRSx3REFBd0QsNkRBQTZELHNEQUFzRCxrSEFBa0g7O0FBRTlaLHNDQUFzQyx1REFBdUQsdUNBQXVDLFNBQVMsT0FBTyxrQkFBa0IsRUFBRSxhQUFhOztBQUVyTDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVcsUUFBUTtBQUNuQixXQUFXLE9BQU87QUFDbEIsV0FBVyxTQUFTO0FBQ3BCO0FBQ0EsV0FBVyxTQUFTO0FBQ3BCLFlBQVksT0FBTztBQUNuQjtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTs7QUFFYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZUFBZTtBQUNmOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQSxpQ0FBaUMsK0JBQStCO0FBQ2hFO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBLGFBQWE7QUFDYjtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0wsR0FBRztBQUNIO0FBQ0E7QUFDQSw2Qzs7Ozs7Ozs7Ozs7O0FDdkZBO0FBQUE7QUFBQTtBQUFBO0FBRWUsK0VBQWVBLEdBQWYsRUFBb0JDLEdBQXBCLEVBQXlCO0FBQ3RDQSxLQUFHLENBQUNDLElBQUosQ0FBUyxNQUFNQyx1RUFBSSxDQUFDSCxHQUFELEVBQU1DLEdBQU4sQ0FBbkI7QUFDRCxDOzs7Ozs7Ozs7OztBQ0pELHFEOzs7Ozs7Ozs7OztBQ0FBLDhDOzs7Ozs7Ozs7OztBQ0FBLHdDOzs7Ozs7Ozs7OztBQ0FBLHFFOzs7Ozs7Ozs7OztBQ0FBLHFFIiwiZmlsZSI6InBhZ2VzL2FwaS5qcyIsInNvdXJjZXNDb250ZW50IjpbIiBcdC8vIFRoZSBtb2R1bGUgY2FjaGVcbiBcdHZhciBpbnN0YWxsZWRNb2R1bGVzID0gcmVxdWlyZSgnLi4vc3NyLW1vZHVsZS1jYWNoZS5qcycpO1xuXG4gXHQvLyBUaGUgcmVxdWlyZSBmdW5jdGlvblxuIFx0ZnVuY3Rpb24gX193ZWJwYWNrX3JlcXVpcmVfXyhtb2R1bGVJZCkge1xuXG4gXHRcdC8vIENoZWNrIGlmIG1vZHVsZSBpcyBpbiBjYWNoZVxuIFx0XHRpZihpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXSkge1xuIFx0XHRcdHJldHVybiBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXS5leHBvcnRzO1xuIFx0XHR9XG4gXHRcdC8vIENyZWF0ZSBhIG5ldyBtb2R1bGUgKGFuZCBwdXQgaXQgaW50byB0aGUgY2FjaGUpXG4gXHRcdHZhciBtb2R1bGUgPSBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXSA9IHtcbiBcdFx0XHRpOiBtb2R1bGVJZCxcbiBcdFx0XHRsOiBmYWxzZSxcbiBcdFx0XHRleHBvcnRzOiB7fVxuIFx0XHR9O1xuXG4gXHRcdC8vIEV4ZWN1dGUgdGhlIG1vZHVsZSBmdW5jdGlvblxuIFx0XHR2YXIgdGhyZXcgPSB0cnVlO1xuIFx0XHR0cnkge1xuIFx0XHRcdG1vZHVsZXNbbW9kdWxlSWRdLmNhbGwobW9kdWxlLmV4cG9ydHMsIG1vZHVsZSwgbW9kdWxlLmV4cG9ydHMsIF9fd2VicGFja19yZXF1aXJlX18pO1xuIFx0XHRcdHRocmV3ID0gZmFsc2U7XG4gXHRcdH0gZmluYWxseSB7XG4gXHRcdFx0aWYodGhyZXcpIGRlbGV0ZSBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXTtcbiBcdFx0fVxuXG4gXHRcdC8vIEZsYWcgdGhlIG1vZHVsZSBhcyBsb2FkZWRcbiBcdFx0bW9kdWxlLmwgPSB0cnVlO1xuXG4gXHRcdC8vIFJldHVybiB0aGUgZXhwb3J0cyBvZiB0aGUgbW9kdWxlXG4gXHRcdHJldHVybiBtb2R1bGUuZXhwb3J0cztcbiBcdH1cblxuXG4gXHQvLyBleHBvc2UgdGhlIG1vZHVsZXMgb2JqZWN0IChfX3dlYnBhY2tfbW9kdWxlc19fKVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5tID0gbW9kdWxlcztcblxuIFx0Ly8gZXhwb3NlIHRoZSBtb2R1bGUgY2FjaGVcbiBcdF9fd2VicGFja19yZXF1aXJlX18uYyA9IGluc3RhbGxlZE1vZHVsZXM7XG5cbiBcdC8vIGRlZmluZSBnZXR0ZXIgZnVuY3Rpb24gZm9yIGhhcm1vbnkgZXhwb3J0c1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5kID0gZnVuY3Rpb24oZXhwb3J0cywgbmFtZSwgZ2V0dGVyKSB7XG4gXHRcdGlmKCFfX3dlYnBhY2tfcmVxdWlyZV9fLm8oZXhwb3J0cywgbmFtZSkpIHtcbiBcdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgbmFtZSwgeyBlbnVtZXJhYmxlOiB0cnVlLCBnZXQ6IGdldHRlciB9KTtcbiBcdFx0fVxuIFx0fTtcblxuIFx0Ly8gZGVmaW5lIF9fZXNNb2R1bGUgb24gZXhwb3J0c1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5yID0gZnVuY3Rpb24oZXhwb3J0cykge1xuIFx0XHRpZih0eXBlb2YgU3ltYm9sICE9PSAndW5kZWZpbmVkJyAmJiBTeW1ib2wudG9TdHJpbmdUYWcpIHtcbiBcdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgU3ltYm9sLnRvU3RyaW5nVGFnLCB7IHZhbHVlOiAnTW9kdWxlJyB9KTtcbiBcdFx0fVxuIFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgJ19fZXNNb2R1bGUnLCB7IHZhbHVlOiB0cnVlIH0pO1xuIFx0fTtcblxuIFx0Ly8gY3JlYXRlIGEgZmFrZSBuYW1lc3BhY2Ugb2JqZWN0XG4gXHQvLyBtb2RlICYgMTogdmFsdWUgaXMgYSBtb2R1bGUgaWQsIHJlcXVpcmUgaXRcbiBcdC8vIG1vZGUgJiAyOiBtZXJnZSBhbGwgcHJvcGVydGllcyBvZiB2YWx1ZSBpbnRvIHRoZSBuc1xuIFx0Ly8gbW9kZSAmIDQ6IHJldHVybiB2YWx1ZSB3aGVuIGFscmVhZHkgbnMgb2JqZWN0XG4gXHQvLyBtb2RlICYgOHwxOiBiZWhhdmUgbGlrZSByZXF1aXJlXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnQgPSBmdW5jdGlvbih2YWx1ZSwgbW9kZSkge1xuIFx0XHRpZihtb2RlICYgMSkgdmFsdWUgPSBfX3dlYnBhY2tfcmVxdWlyZV9fKHZhbHVlKTtcbiBcdFx0aWYobW9kZSAmIDgpIHJldHVybiB2YWx1ZTtcbiBcdFx0aWYoKG1vZGUgJiA0KSAmJiB0eXBlb2YgdmFsdWUgPT09ICdvYmplY3QnICYmIHZhbHVlICYmIHZhbHVlLl9fZXNNb2R1bGUpIHJldHVybiB2YWx1ZTtcbiBcdFx0dmFyIG5zID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiBcdFx0X193ZWJwYWNrX3JlcXVpcmVfXy5yKG5zKTtcbiBcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KG5zLCAnZGVmYXVsdCcsIHsgZW51bWVyYWJsZTogdHJ1ZSwgdmFsdWU6IHZhbHVlIH0pO1xuIFx0XHRpZihtb2RlICYgMiAmJiB0eXBlb2YgdmFsdWUgIT0gJ3N0cmluZycpIGZvcih2YXIga2V5IGluIHZhbHVlKSBfX3dlYnBhY2tfcmVxdWlyZV9fLmQobnMsIGtleSwgZnVuY3Rpb24oa2V5KSB7IHJldHVybiB2YWx1ZVtrZXldOyB9LmJpbmQobnVsbCwga2V5KSk7XG4gXHRcdHJldHVybiBucztcbiBcdH07XG5cbiBcdC8vIGdldERlZmF1bHRFeHBvcnQgZnVuY3Rpb24gZm9yIGNvbXBhdGliaWxpdHkgd2l0aCBub24taGFybW9ueSBtb2R1bGVzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm4gPSBmdW5jdGlvbihtb2R1bGUpIHtcbiBcdFx0dmFyIGdldHRlciA9IG1vZHVsZSAmJiBtb2R1bGUuX19lc01vZHVsZSA/XG4gXHRcdFx0ZnVuY3Rpb24gZ2V0RGVmYXVsdCgpIHsgcmV0dXJuIG1vZHVsZVsnZGVmYXVsdCddOyB9IDpcbiBcdFx0XHRmdW5jdGlvbiBnZXRNb2R1bGVFeHBvcnRzKCkgeyByZXR1cm4gbW9kdWxlOyB9O1xuIFx0XHRfX3dlYnBhY2tfcmVxdWlyZV9fLmQoZ2V0dGVyLCAnYScsIGdldHRlcik7XG4gXHRcdHJldHVybiBnZXR0ZXI7XG4gXHR9O1xuXG4gXHQvLyBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGxcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubyA9IGZ1bmN0aW9uKG9iamVjdCwgcHJvcGVydHkpIHsgcmV0dXJuIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvYmplY3QsIHByb3BlcnR5KTsgfTtcblxuIFx0Ly8gX193ZWJwYWNrX3B1YmxpY19wYXRoX19cbiBcdF9fd2VicGFja19yZXF1aXJlX18ucCA9IFwiXCI7XG5cblxuIFx0Ly8gTG9hZCBlbnRyeSBtb2R1bGUgYW5kIHJldHVybiBleHBvcnRzXG4gXHRyZXR1cm4gX193ZWJwYWNrX3JlcXVpcmVfXyhfX3dlYnBhY2tfcmVxdWlyZV9fLnMgPSBcIi4vcGFnZXMvYXBpL2luZGV4LmpzXCIpO1xuIiwiZnVuY3Rpb24gX2FycmF5TGlrZVRvQXJyYXkoYXJyLCBsZW4pIHtcbiAgaWYgKGxlbiA9PSBudWxsIHx8IGxlbiA+IGFyci5sZW5ndGgpIGxlbiA9IGFyci5sZW5ndGg7XG5cbiAgZm9yICh2YXIgaSA9IDAsIGFycjIgPSBuZXcgQXJyYXkobGVuKTsgaSA8IGxlbjsgaSsrKSB7XG4gICAgYXJyMltpXSA9IGFycltpXTtcbiAgfVxuXG4gIHJldHVybiBhcnIyO1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IF9hcnJheUxpa2VUb0FycmF5LCBtb2R1bGUuZXhwb3J0cy5fX2VzTW9kdWxlID0gdHJ1ZSwgbW9kdWxlLmV4cG9ydHNbXCJkZWZhdWx0XCJdID0gbW9kdWxlLmV4cG9ydHM7IiwidmFyIGFycmF5TGlrZVRvQXJyYXkgPSByZXF1aXJlKFwiLi9hcnJheUxpa2VUb0FycmF5LmpzXCIpO1xuXG5mdW5jdGlvbiBfYXJyYXlXaXRob3V0SG9sZXMoYXJyKSB7XG4gIGlmIChBcnJheS5pc0FycmF5KGFycikpIHJldHVybiBhcnJheUxpa2VUb0FycmF5KGFycik7XG59XG5cbm1vZHVsZS5leHBvcnRzID0gX2FycmF5V2l0aG91dEhvbGVzLCBtb2R1bGUuZXhwb3J0cy5fX2VzTW9kdWxlID0gdHJ1ZSwgbW9kdWxlLmV4cG9ydHNbXCJkZWZhdWx0XCJdID0gbW9kdWxlLmV4cG9ydHM7IiwiZnVuY3Rpb24gYXN5bmNHZW5lcmF0b3JTdGVwKGdlbiwgcmVzb2x2ZSwgcmVqZWN0LCBfbmV4dCwgX3Rocm93LCBrZXksIGFyZykge1xuICB0cnkge1xuICAgIHZhciBpbmZvID0gZ2VuW2tleV0oYXJnKTtcbiAgICB2YXIgdmFsdWUgPSBpbmZvLnZhbHVlO1xuICB9IGNhdGNoIChlcnJvcikge1xuICAgIHJlamVjdChlcnJvcik7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgaWYgKGluZm8uZG9uZSkge1xuICAgIHJlc29sdmUodmFsdWUpO1xuICB9IGVsc2Uge1xuICAgIFByb21pc2UucmVzb2x2ZSh2YWx1ZSkudGhlbihfbmV4dCwgX3Rocm93KTtcbiAgfVxufVxuXG5mdW5jdGlvbiBfYXN5bmNUb0dlbmVyYXRvcihmbikge1xuICByZXR1cm4gZnVuY3Rpb24gKCkge1xuICAgIHZhciBzZWxmID0gdGhpcyxcbiAgICAgICAgYXJncyA9IGFyZ3VtZW50cztcbiAgICByZXR1cm4gbmV3IFByb21pc2UoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgdmFyIGdlbiA9IGZuLmFwcGx5KHNlbGYsIGFyZ3MpO1xuXG4gICAgICBmdW5jdGlvbiBfbmV4dCh2YWx1ZSkge1xuICAgICAgICBhc3luY0dlbmVyYXRvclN0ZXAoZ2VuLCByZXNvbHZlLCByZWplY3QsIF9uZXh0LCBfdGhyb3csIFwibmV4dFwiLCB2YWx1ZSk7XG4gICAgICB9XG5cbiAgICAgIGZ1bmN0aW9uIF90aHJvdyhlcnIpIHtcbiAgICAgICAgYXN5bmNHZW5lcmF0b3JTdGVwKGdlbiwgcmVzb2x2ZSwgcmVqZWN0LCBfbmV4dCwgX3Rocm93LCBcInRocm93XCIsIGVycik7XG4gICAgICB9XG5cbiAgICAgIF9uZXh0KHVuZGVmaW5lZCk7XG4gICAgfSk7XG4gIH07XG59XG5cbm1vZHVsZS5leHBvcnRzID0gX2FzeW5jVG9HZW5lcmF0b3IsIG1vZHVsZS5leHBvcnRzLl9fZXNNb2R1bGUgPSB0cnVlLCBtb2R1bGUuZXhwb3J0c1tcImRlZmF1bHRcIl0gPSBtb2R1bGUuZXhwb3J0czsiLCJmdW5jdGlvbiBfZGVmaW5lUHJvcGVydHkob2JqLCBrZXksIHZhbHVlKSB7XG4gIGlmIChrZXkgaW4gb2JqKSB7XG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KG9iaiwga2V5LCB7XG4gICAgICB2YWx1ZTogdmFsdWUsXG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlLFxuICAgICAgd3JpdGFibGU6IHRydWVcbiAgICB9KTtcbiAgfSBlbHNlIHtcbiAgICBvYmpba2V5XSA9IHZhbHVlO1xuICB9XG5cbiAgcmV0dXJuIG9iajtcbn1cblxubW9kdWxlLmV4cG9ydHMgPSBfZGVmaW5lUHJvcGVydHksIG1vZHVsZS5leHBvcnRzLl9fZXNNb2R1bGUgPSB0cnVlLCBtb2R1bGUuZXhwb3J0c1tcImRlZmF1bHRcIl0gPSBtb2R1bGUuZXhwb3J0czsiLCJmdW5jdGlvbiBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0KG9iaikge1xuICByZXR1cm4gb2JqICYmIG9iai5fX2VzTW9kdWxlID8gb2JqIDoge1xuICAgIFwiZGVmYXVsdFwiOiBvYmpcbiAgfTtcbn1cblxubW9kdWxlLmV4cG9ydHMgPSBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0LCBtb2R1bGUuZXhwb3J0cy5fX2VzTW9kdWxlID0gdHJ1ZSwgbW9kdWxlLmV4cG9ydHNbXCJkZWZhdWx0XCJdID0gbW9kdWxlLmV4cG9ydHM7IiwidmFyIF90eXBlb2YgPSByZXF1aXJlKFwiLi90eXBlb2YuanNcIilbXCJkZWZhdWx0XCJdO1xuXG5mdW5jdGlvbiBfZ2V0UmVxdWlyZVdpbGRjYXJkQ2FjaGUobm9kZUludGVyb3ApIHtcbiAgaWYgKHR5cGVvZiBXZWFrTWFwICE9PSBcImZ1bmN0aW9uXCIpIHJldHVybiBudWxsO1xuICB2YXIgY2FjaGVCYWJlbEludGVyb3AgPSBuZXcgV2Vha01hcCgpO1xuICB2YXIgY2FjaGVOb2RlSW50ZXJvcCA9IG5ldyBXZWFrTWFwKCk7XG4gIHJldHVybiAoX2dldFJlcXVpcmVXaWxkY2FyZENhY2hlID0gZnVuY3Rpb24gX2dldFJlcXVpcmVXaWxkY2FyZENhY2hlKG5vZGVJbnRlcm9wKSB7XG4gICAgcmV0dXJuIG5vZGVJbnRlcm9wID8gY2FjaGVOb2RlSW50ZXJvcCA6IGNhY2hlQmFiZWxJbnRlcm9wO1xuICB9KShub2RlSW50ZXJvcCk7XG59XG5cbmZ1bmN0aW9uIF9pbnRlcm9wUmVxdWlyZVdpbGRjYXJkKG9iaiwgbm9kZUludGVyb3ApIHtcbiAgaWYgKCFub2RlSW50ZXJvcCAmJiBvYmogJiYgb2JqLl9fZXNNb2R1bGUpIHtcbiAgICByZXR1cm4gb2JqO1xuICB9XG5cbiAgaWYgKG9iaiA9PT0gbnVsbCB8fCBfdHlwZW9mKG9iaikgIT09IFwib2JqZWN0XCIgJiYgdHlwZW9mIG9iaiAhPT0gXCJmdW5jdGlvblwiKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIFwiZGVmYXVsdFwiOiBvYmpcbiAgICB9O1xuICB9XG5cbiAgdmFyIGNhY2hlID0gX2dldFJlcXVpcmVXaWxkY2FyZENhY2hlKG5vZGVJbnRlcm9wKTtcblxuICBpZiAoY2FjaGUgJiYgY2FjaGUuaGFzKG9iaikpIHtcbiAgICByZXR1cm4gY2FjaGUuZ2V0KG9iaik7XG4gIH1cblxuICB2YXIgbmV3T2JqID0ge307XG4gIHZhciBoYXNQcm9wZXJ0eURlc2NyaXB0b3IgPSBPYmplY3QuZGVmaW5lUHJvcGVydHkgJiYgT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcjtcblxuICBmb3IgKHZhciBrZXkgaW4gb2JqKSB7XG4gICAgaWYgKGtleSAhPT0gXCJkZWZhdWx0XCIgJiYgT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKG9iaiwga2V5KSkge1xuICAgICAgdmFyIGRlc2MgPSBoYXNQcm9wZXJ0eURlc2NyaXB0b3IgPyBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKG9iaiwga2V5KSA6IG51bGw7XG5cbiAgICAgIGlmIChkZXNjICYmIChkZXNjLmdldCB8fCBkZXNjLnNldCkpIHtcbiAgICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KG5ld09iaiwga2V5LCBkZXNjKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIG5ld09ialtrZXldID0gb2JqW2tleV07XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgbmV3T2JqW1wiZGVmYXVsdFwiXSA9IG9iajtcblxuICBpZiAoY2FjaGUpIHtcbiAgICBjYWNoZS5zZXQob2JqLCBuZXdPYmopO1xuICB9XG5cbiAgcmV0dXJuIG5ld09iajtcbn1cblxubW9kdWxlLmV4cG9ydHMgPSBfaW50ZXJvcFJlcXVpcmVXaWxkY2FyZCwgbW9kdWxlLmV4cG9ydHMuX19lc01vZHVsZSA9IHRydWUsIG1vZHVsZS5leHBvcnRzW1wiZGVmYXVsdFwiXSA9IG1vZHVsZS5leHBvcnRzOyIsImZ1bmN0aW9uIF9pdGVyYWJsZVRvQXJyYXkoaXRlcikge1xuICBpZiAodHlwZW9mIFN5bWJvbCAhPT0gXCJ1bmRlZmluZWRcIiAmJiBpdGVyW1N5bWJvbC5pdGVyYXRvcl0gIT0gbnVsbCB8fCBpdGVyW1wiQEBpdGVyYXRvclwiXSAhPSBudWxsKSByZXR1cm4gQXJyYXkuZnJvbShpdGVyKTtcbn1cblxubW9kdWxlLmV4cG9ydHMgPSBfaXRlcmFibGVUb0FycmF5LCBtb2R1bGUuZXhwb3J0cy5fX2VzTW9kdWxlID0gdHJ1ZSwgbW9kdWxlLmV4cG9ydHNbXCJkZWZhdWx0XCJdID0gbW9kdWxlLmV4cG9ydHM7IiwiZnVuY3Rpb24gX25vbkl0ZXJhYmxlU3ByZWFkKCkge1xuICB0aHJvdyBuZXcgVHlwZUVycm9yKFwiSW52YWxpZCBhdHRlbXB0IHRvIHNwcmVhZCBub24taXRlcmFibGUgaW5zdGFuY2UuXFxuSW4gb3JkZXIgdG8gYmUgaXRlcmFibGUsIG5vbi1hcnJheSBvYmplY3RzIG11c3QgaGF2ZSBhIFtTeW1ib2wuaXRlcmF0b3JdKCkgbWV0aG9kLlwiKTtcbn1cblxubW9kdWxlLmV4cG9ydHMgPSBfbm9uSXRlcmFibGVTcHJlYWQsIG1vZHVsZS5leHBvcnRzLl9fZXNNb2R1bGUgPSB0cnVlLCBtb2R1bGUuZXhwb3J0c1tcImRlZmF1bHRcIl0gPSBtb2R1bGUuZXhwb3J0czsiLCJ2YXIgX3R5cGVvZiA9IHJlcXVpcmUoXCIuL3R5cGVvZi5qc1wiKVtcImRlZmF1bHRcIl07XG5cbmZ1bmN0aW9uIF9yZWdlbmVyYXRvclJ1bnRpbWUoKSB7XG4gIFwidXNlIHN0cmljdFwiO1xuICAvKiEgcmVnZW5lcmF0b3ItcnVudGltZSAtLSBDb3B5cmlnaHQgKGMpIDIwMTQtcHJlc2VudCwgRmFjZWJvb2ssIEluYy4gLS0gbGljZW5zZSAoTUlUKTogaHR0cHM6Ly9naXRodWIuY29tL2ZhY2Vib29rL3JlZ2VuZXJhdG9yL2Jsb2IvbWFpbi9MSUNFTlNFICovXG5cbiAgbW9kdWxlLmV4cG9ydHMgPSBfcmVnZW5lcmF0b3JSdW50aW1lID0gZnVuY3Rpb24gX3JlZ2VuZXJhdG9yUnVudGltZSgpIHtcbiAgICByZXR1cm4gZXhwb3J0cztcbiAgfSwgbW9kdWxlLmV4cG9ydHMuX19lc01vZHVsZSA9IHRydWUsIG1vZHVsZS5leHBvcnRzW1wiZGVmYXVsdFwiXSA9IG1vZHVsZS5leHBvcnRzO1xuICB2YXIgZXhwb3J0cyA9IHt9LFxuICAgICAgT3AgPSBPYmplY3QucHJvdG90eXBlLFxuICAgICAgaGFzT3duID0gT3AuaGFzT3duUHJvcGVydHksXG4gICAgICAkU3ltYm9sID0gXCJmdW5jdGlvblwiID09IHR5cGVvZiBTeW1ib2wgPyBTeW1ib2wgOiB7fSxcbiAgICAgIGl0ZXJhdG9yU3ltYm9sID0gJFN5bWJvbC5pdGVyYXRvciB8fCBcIkBAaXRlcmF0b3JcIixcbiAgICAgIGFzeW5jSXRlcmF0b3JTeW1ib2wgPSAkU3ltYm9sLmFzeW5jSXRlcmF0b3IgfHwgXCJAQGFzeW5jSXRlcmF0b3JcIixcbiAgICAgIHRvU3RyaW5nVGFnU3ltYm9sID0gJFN5bWJvbC50b1N0cmluZ1RhZyB8fCBcIkBAdG9TdHJpbmdUYWdcIjtcblxuICBmdW5jdGlvbiBkZWZpbmUob2JqLCBrZXksIHZhbHVlKSB7XG4gICAgcmV0dXJuIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShvYmosIGtleSwge1xuICAgICAgdmFsdWU6IHZhbHVlLFxuICAgICAgZW51bWVyYWJsZTogITAsXG4gICAgICBjb25maWd1cmFibGU6ICEwLFxuICAgICAgd3JpdGFibGU6ICEwXG4gICAgfSksIG9ialtrZXldO1xuICB9XG5cbiAgdHJ5IHtcbiAgICBkZWZpbmUoe30sIFwiXCIpO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBkZWZpbmUgPSBmdW5jdGlvbiBkZWZpbmUob2JqLCBrZXksIHZhbHVlKSB7XG4gICAgICByZXR1cm4gb2JqW2tleV0gPSB2YWx1ZTtcbiAgICB9O1xuICB9XG5cbiAgZnVuY3Rpb24gd3JhcChpbm5lckZuLCBvdXRlckZuLCBzZWxmLCB0cnlMb2NzTGlzdCkge1xuICAgIHZhciBwcm90b0dlbmVyYXRvciA9IG91dGVyRm4gJiYgb3V0ZXJGbi5wcm90b3R5cGUgaW5zdGFuY2VvZiBHZW5lcmF0b3IgPyBvdXRlckZuIDogR2VuZXJhdG9yLFxuICAgICAgICBnZW5lcmF0b3IgPSBPYmplY3QuY3JlYXRlKHByb3RvR2VuZXJhdG9yLnByb3RvdHlwZSksXG4gICAgICAgIGNvbnRleHQgPSBuZXcgQ29udGV4dCh0cnlMb2NzTGlzdCB8fCBbXSk7XG4gICAgcmV0dXJuIGdlbmVyYXRvci5faW52b2tlID0gZnVuY3Rpb24gKGlubmVyRm4sIHNlbGYsIGNvbnRleHQpIHtcbiAgICAgIHZhciBzdGF0ZSA9IFwic3VzcGVuZGVkU3RhcnRcIjtcbiAgICAgIHJldHVybiBmdW5jdGlvbiAobWV0aG9kLCBhcmcpIHtcbiAgICAgICAgaWYgKFwiZXhlY3V0aW5nXCIgPT09IHN0YXRlKSB0aHJvdyBuZXcgRXJyb3IoXCJHZW5lcmF0b3IgaXMgYWxyZWFkeSBydW5uaW5nXCIpO1xuXG4gICAgICAgIGlmIChcImNvbXBsZXRlZFwiID09PSBzdGF0ZSkge1xuICAgICAgICAgIGlmIChcInRocm93XCIgPT09IG1ldGhvZCkgdGhyb3cgYXJnO1xuICAgICAgICAgIHJldHVybiBkb25lUmVzdWx0KCk7XG4gICAgICAgIH1cblxuICAgICAgICBmb3IgKGNvbnRleHQubWV0aG9kID0gbWV0aG9kLCBjb250ZXh0LmFyZyA9IGFyZzs7KSB7XG4gICAgICAgICAgdmFyIGRlbGVnYXRlID0gY29udGV4dC5kZWxlZ2F0ZTtcblxuICAgICAgICAgIGlmIChkZWxlZ2F0ZSkge1xuICAgICAgICAgICAgdmFyIGRlbGVnYXRlUmVzdWx0ID0gbWF5YmVJbnZva2VEZWxlZ2F0ZShkZWxlZ2F0ZSwgY29udGV4dCk7XG5cbiAgICAgICAgICAgIGlmIChkZWxlZ2F0ZVJlc3VsdCkge1xuICAgICAgICAgICAgICBpZiAoZGVsZWdhdGVSZXN1bHQgPT09IENvbnRpbnVlU2VudGluZWwpIGNvbnRpbnVlO1xuICAgICAgICAgICAgICByZXR1cm4gZGVsZWdhdGVSZXN1bHQ7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgaWYgKFwibmV4dFwiID09PSBjb250ZXh0Lm1ldGhvZCkgY29udGV4dC5zZW50ID0gY29udGV4dC5fc2VudCA9IGNvbnRleHQuYXJnO2Vsc2UgaWYgKFwidGhyb3dcIiA9PT0gY29udGV4dC5tZXRob2QpIHtcbiAgICAgICAgICAgIGlmIChcInN1c3BlbmRlZFN0YXJ0XCIgPT09IHN0YXRlKSB0aHJvdyBzdGF0ZSA9IFwiY29tcGxldGVkXCIsIGNvbnRleHQuYXJnO1xuICAgICAgICAgICAgY29udGV4dC5kaXNwYXRjaEV4Y2VwdGlvbihjb250ZXh0LmFyZyk7XG4gICAgICAgICAgfSBlbHNlIFwicmV0dXJuXCIgPT09IGNvbnRleHQubWV0aG9kICYmIGNvbnRleHQuYWJydXB0KFwicmV0dXJuXCIsIGNvbnRleHQuYXJnKTtcbiAgICAgICAgICBzdGF0ZSA9IFwiZXhlY3V0aW5nXCI7XG4gICAgICAgICAgdmFyIHJlY29yZCA9IHRyeUNhdGNoKGlubmVyRm4sIHNlbGYsIGNvbnRleHQpO1xuXG4gICAgICAgICAgaWYgKFwibm9ybWFsXCIgPT09IHJlY29yZC50eXBlKSB7XG4gICAgICAgICAgICBpZiAoc3RhdGUgPSBjb250ZXh0LmRvbmUgPyBcImNvbXBsZXRlZFwiIDogXCJzdXNwZW5kZWRZaWVsZFwiLCByZWNvcmQuYXJnID09PSBDb250aW51ZVNlbnRpbmVsKSBjb250aW51ZTtcbiAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgIHZhbHVlOiByZWNvcmQuYXJnLFxuICAgICAgICAgICAgICBkb25lOiBjb250ZXh0LmRvbmVcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgXCJ0aHJvd1wiID09PSByZWNvcmQudHlwZSAmJiAoc3RhdGUgPSBcImNvbXBsZXRlZFwiLCBjb250ZXh0Lm1ldGhvZCA9IFwidGhyb3dcIiwgY29udGV4dC5hcmcgPSByZWNvcmQuYXJnKTtcbiAgICAgICAgfVxuICAgICAgfTtcbiAgICB9KGlubmVyRm4sIHNlbGYsIGNvbnRleHQpLCBnZW5lcmF0b3I7XG4gIH1cblxuICBmdW5jdGlvbiB0cnlDYXRjaChmbiwgb2JqLCBhcmcpIHtcbiAgICB0cnkge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgdHlwZTogXCJub3JtYWxcIixcbiAgICAgICAgYXJnOiBmbi5jYWxsKG9iaiwgYXJnKVxuICAgICAgfTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHR5cGU6IFwidGhyb3dcIixcbiAgICAgICAgYXJnOiBlcnJcbiAgICAgIH07XG4gICAgfVxuICB9XG5cbiAgZXhwb3J0cy53cmFwID0gd3JhcDtcbiAgdmFyIENvbnRpbnVlU2VudGluZWwgPSB7fTtcblxuICBmdW5jdGlvbiBHZW5lcmF0b3IoKSB7fVxuXG4gIGZ1bmN0aW9uIEdlbmVyYXRvckZ1bmN0aW9uKCkge31cblxuICBmdW5jdGlvbiBHZW5lcmF0b3JGdW5jdGlvblByb3RvdHlwZSgpIHt9XG5cbiAgdmFyIEl0ZXJhdG9yUHJvdG90eXBlID0ge307XG4gIGRlZmluZShJdGVyYXRvclByb3RvdHlwZSwgaXRlcmF0b3JTeW1ib2wsIGZ1bmN0aW9uICgpIHtcbiAgICByZXR1cm4gdGhpcztcbiAgfSk7XG4gIHZhciBnZXRQcm90byA9IE9iamVjdC5nZXRQcm90b3R5cGVPZixcbiAgICAgIE5hdGl2ZUl0ZXJhdG9yUHJvdG90eXBlID0gZ2V0UHJvdG8gJiYgZ2V0UHJvdG8oZ2V0UHJvdG8odmFsdWVzKFtdKSkpO1xuICBOYXRpdmVJdGVyYXRvclByb3RvdHlwZSAmJiBOYXRpdmVJdGVyYXRvclByb3RvdHlwZSAhPT0gT3AgJiYgaGFzT3duLmNhbGwoTmF0aXZlSXRlcmF0b3JQcm90b3R5cGUsIGl0ZXJhdG9yU3ltYm9sKSAmJiAoSXRlcmF0b3JQcm90b3R5cGUgPSBOYXRpdmVJdGVyYXRvclByb3RvdHlwZSk7XG4gIHZhciBHcCA9IEdlbmVyYXRvckZ1bmN0aW9uUHJvdG90eXBlLnByb3RvdHlwZSA9IEdlbmVyYXRvci5wcm90b3R5cGUgPSBPYmplY3QuY3JlYXRlKEl0ZXJhdG9yUHJvdG90eXBlKTtcblxuICBmdW5jdGlvbiBkZWZpbmVJdGVyYXRvck1ldGhvZHMocHJvdG90eXBlKSB7XG4gICAgW1wibmV4dFwiLCBcInRocm93XCIsIFwicmV0dXJuXCJdLmZvckVhY2goZnVuY3Rpb24gKG1ldGhvZCkge1xuICAgICAgZGVmaW5lKHByb3RvdHlwZSwgbWV0aG9kLCBmdW5jdGlvbiAoYXJnKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9pbnZva2UobWV0aG9kLCBhcmcpO1xuICAgICAgfSk7XG4gICAgfSk7XG4gIH1cblxuICBmdW5jdGlvbiBBc3luY0l0ZXJhdG9yKGdlbmVyYXRvciwgUHJvbWlzZUltcGwpIHtcbiAgICBmdW5jdGlvbiBpbnZva2UobWV0aG9kLCBhcmcsIHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgdmFyIHJlY29yZCA9IHRyeUNhdGNoKGdlbmVyYXRvclttZXRob2RdLCBnZW5lcmF0b3IsIGFyZyk7XG5cbiAgICAgIGlmIChcInRocm93XCIgIT09IHJlY29yZC50eXBlKSB7XG4gICAgICAgIHZhciByZXN1bHQgPSByZWNvcmQuYXJnLFxuICAgICAgICAgICAgdmFsdWUgPSByZXN1bHQudmFsdWU7XG4gICAgICAgIHJldHVybiB2YWx1ZSAmJiBcIm9iamVjdFwiID09IF90eXBlb2YodmFsdWUpICYmIGhhc093bi5jYWxsKHZhbHVlLCBcIl9fYXdhaXRcIikgPyBQcm9taXNlSW1wbC5yZXNvbHZlKHZhbHVlLl9fYXdhaXQpLnRoZW4oZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgICAgICAgaW52b2tlKFwibmV4dFwiLCB2YWx1ZSwgcmVzb2x2ZSwgcmVqZWN0KTtcbiAgICAgICAgfSwgZnVuY3Rpb24gKGVycikge1xuICAgICAgICAgIGludm9rZShcInRocm93XCIsIGVyciwgcmVzb2x2ZSwgcmVqZWN0KTtcbiAgICAgICAgfSkgOiBQcm9taXNlSW1wbC5yZXNvbHZlKHZhbHVlKS50aGVuKGZ1bmN0aW9uICh1bndyYXBwZWQpIHtcbiAgICAgICAgICByZXN1bHQudmFsdWUgPSB1bndyYXBwZWQsIHJlc29sdmUocmVzdWx0KTtcbiAgICAgICAgfSwgZnVuY3Rpb24gKGVycm9yKSB7XG4gICAgICAgICAgcmV0dXJuIGludm9rZShcInRocm93XCIsIGVycm9yLCByZXNvbHZlLCByZWplY3QpO1xuICAgICAgICB9KTtcbiAgICAgIH1cblxuICAgICAgcmVqZWN0KHJlY29yZC5hcmcpO1xuICAgIH1cblxuICAgIHZhciBwcmV2aW91c1Byb21pc2U7XG5cbiAgICB0aGlzLl9pbnZva2UgPSBmdW5jdGlvbiAobWV0aG9kLCBhcmcpIHtcbiAgICAgIGZ1bmN0aW9uIGNhbGxJbnZva2VXaXRoTWV0aG9kQW5kQXJnKCkge1xuICAgICAgICByZXR1cm4gbmV3IFByb21pc2VJbXBsKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgICAgICBpbnZva2UobWV0aG9kLCBhcmcsIHJlc29sdmUsIHJlamVjdCk7XG4gICAgICAgIH0pO1xuICAgICAgfVxuXG4gICAgICByZXR1cm4gcHJldmlvdXNQcm9taXNlID0gcHJldmlvdXNQcm9taXNlID8gcHJldmlvdXNQcm9taXNlLnRoZW4oY2FsbEludm9rZVdpdGhNZXRob2RBbmRBcmcsIGNhbGxJbnZva2VXaXRoTWV0aG9kQW5kQXJnKSA6IGNhbGxJbnZva2VXaXRoTWV0aG9kQW5kQXJnKCk7XG4gICAgfTtcbiAgfVxuXG4gIGZ1bmN0aW9uIG1heWJlSW52b2tlRGVsZWdhdGUoZGVsZWdhdGUsIGNvbnRleHQpIHtcbiAgICB2YXIgbWV0aG9kID0gZGVsZWdhdGUuaXRlcmF0b3JbY29udGV4dC5tZXRob2RdO1xuXG4gICAgaWYgKHVuZGVmaW5lZCA9PT0gbWV0aG9kKSB7XG4gICAgICBpZiAoY29udGV4dC5kZWxlZ2F0ZSA9IG51bGwsIFwidGhyb3dcIiA9PT0gY29udGV4dC5tZXRob2QpIHtcbiAgICAgICAgaWYgKGRlbGVnYXRlLml0ZXJhdG9yW1wicmV0dXJuXCJdICYmIChjb250ZXh0Lm1ldGhvZCA9IFwicmV0dXJuXCIsIGNvbnRleHQuYXJnID0gdW5kZWZpbmVkLCBtYXliZUludm9rZURlbGVnYXRlKGRlbGVnYXRlLCBjb250ZXh0KSwgXCJ0aHJvd1wiID09PSBjb250ZXh0Lm1ldGhvZCkpIHJldHVybiBDb250aW51ZVNlbnRpbmVsO1xuICAgICAgICBjb250ZXh0Lm1ldGhvZCA9IFwidGhyb3dcIiwgY29udGV4dC5hcmcgPSBuZXcgVHlwZUVycm9yKFwiVGhlIGl0ZXJhdG9yIGRvZXMgbm90IHByb3ZpZGUgYSAndGhyb3cnIG1ldGhvZFwiKTtcbiAgICAgIH1cblxuICAgICAgcmV0dXJuIENvbnRpbnVlU2VudGluZWw7XG4gICAgfVxuXG4gICAgdmFyIHJlY29yZCA9IHRyeUNhdGNoKG1ldGhvZCwgZGVsZWdhdGUuaXRlcmF0b3IsIGNvbnRleHQuYXJnKTtcbiAgICBpZiAoXCJ0aHJvd1wiID09PSByZWNvcmQudHlwZSkgcmV0dXJuIGNvbnRleHQubWV0aG9kID0gXCJ0aHJvd1wiLCBjb250ZXh0LmFyZyA9IHJlY29yZC5hcmcsIGNvbnRleHQuZGVsZWdhdGUgPSBudWxsLCBDb250aW51ZVNlbnRpbmVsO1xuICAgIHZhciBpbmZvID0gcmVjb3JkLmFyZztcbiAgICByZXR1cm4gaW5mbyA/IGluZm8uZG9uZSA/IChjb250ZXh0W2RlbGVnYXRlLnJlc3VsdE5hbWVdID0gaW5mby52YWx1ZSwgY29udGV4dC5uZXh0ID0gZGVsZWdhdGUubmV4dExvYywgXCJyZXR1cm5cIiAhPT0gY29udGV4dC5tZXRob2QgJiYgKGNvbnRleHQubWV0aG9kID0gXCJuZXh0XCIsIGNvbnRleHQuYXJnID0gdW5kZWZpbmVkKSwgY29udGV4dC5kZWxlZ2F0ZSA9IG51bGwsIENvbnRpbnVlU2VudGluZWwpIDogaW5mbyA6IChjb250ZXh0Lm1ldGhvZCA9IFwidGhyb3dcIiwgY29udGV4dC5hcmcgPSBuZXcgVHlwZUVycm9yKFwiaXRlcmF0b3IgcmVzdWx0IGlzIG5vdCBhbiBvYmplY3RcIiksIGNvbnRleHQuZGVsZWdhdGUgPSBudWxsLCBDb250aW51ZVNlbnRpbmVsKTtcbiAgfVxuXG4gIGZ1bmN0aW9uIHB1c2hUcnlFbnRyeShsb2NzKSB7XG4gICAgdmFyIGVudHJ5ID0ge1xuICAgICAgdHJ5TG9jOiBsb2NzWzBdXG4gICAgfTtcbiAgICAxIGluIGxvY3MgJiYgKGVudHJ5LmNhdGNoTG9jID0gbG9jc1sxXSksIDIgaW4gbG9jcyAmJiAoZW50cnkuZmluYWxseUxvYyA9IGxvY3NbMl0sIGVudHJ5LmFmdGVyTG9jID0gbG9jc1szXSksIHRoaXMudHJ5RW50cmllcy5wdXNoKGVudHJ5KTtcbiAgfVxuXG4gIGZ1bmN0aW9uIHJlc2V0VHJ5RW50cnkoZW50cnkpIHtcbiAgICB2YXIgcmVjb3JkID0gZW50cnkuY29tcGxldGlvbiB8fCB7fTtcbiAgICByZWNvcmQudHlwZSA9IFwibm9ybWFsXCIsIGRlbGV0ZSByZWNvcmQuYXJnLCBlbnRyeS5jb21wbGV0aW9uID0gcmVjb3JkO1xuICB9XG5cbiAgZnVuY3Rpb24gQ29udGV4dCh0cnlMb2NzTGlzdCkge1xuICAgIHRoaXMudHJ5RW50cmllcyA9IFt7XG4gICAgICB0cnlMb2M6IFwicm9vdFwiXG4gICAgfV0sIHRyeUxvY3NMaXN0LmZvckVhY2gocHVzaFRyeUVudHJ5LCB0aGlzKSwgdGhpcy5yZXNldCghMCk7XG4gIH1cblxuICBmdW5jdGlvbiB2YWx1ZXMoaXRlcmFibGUpIHtcbiAgICBpZiAoaXRlcmFibGUpIHtcbiAgICAgIHZhciBpdGVyYXRvck1ldGhvZCA9IGl0ZXJhYmxlW2l0ZXJhdG9yU3ltYm9sXTtcbiAgICAgIGlmIChpdGVyYXRvck1ldGhvZCkgcmV0dXJuIGl0ZXJhdG9yTWV0aG9kLmNhbGwoaXRlcmFibGUpO1xuICAgICAgaWYgKFwiZnVuY3Rpb25cIiA9PSB0eXBlb2YgaXRlcmFibGUubmV4dCkgcmV0dXJuIGl0ZXJhYmxlO1xuXG4gICAgICBpZiAoIWlzTmFOKGl0ZXJhYmxlLmxlbmd0aCkpIHtcbiAgICAgICAgdmFyIGkgPSAtMSxcbiAgICAgICAgICAgIG5leHQgPSBmdW5jdGlvbiBuZXh0KCkge1xuICAgICAgICAgIGZvciAoOyArK2kgPCBpdGVyYWJsZS5sZW5ndGg7KSB7XG4gICAgICAgICAgICBpZiAoaGFzT3duLmNhbGwoaXRlcmFibGUsIGkpKSByZXR1cm4gbmV4dC52YWx1ZSA9IGl0ZXJhYmxlW2ldLCBuZXh0LmRvbmUgPSAhMSwgbmV4dDtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICByZXR1cm4gbmV4dC52YWx1ZSA9IHVuZGVmaW5lZCwgbmV4dC5kb25lID0gITAsIG5leHQ7XG4gICAgICAgIH07XG5cbiAgICAgICAgcmV0dXJuIG5leHQubmV4dCA9IG5leHQ7XG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIHtcbiAgICAgIG5leHQ6IGRvbmVSZXN1bHRcbiAgICB9O1xuICB9XG5cbiAgZnVuY3Rpb24gZG9uZVJlc3VsdCgpIHtcbiAgICByZXR1cm4ge1xuICAgICAgdmFsdWU6IHVuZGVmaW5lZCxcbiAgICAgIGRvbmU6ICEwXG4gICAgfTtcbiAgfVxuXG4gIHJldHVybiBHZW5lcmF0b3JGdW5jdGlvbi5wcm90b3R5cGUgPSBHZW5lcmF0b3JGdW5jdGlvblByb3RvdHlwZSwgZGVmaW5lKEdwLCBcImNvbnN0cnVjdG9yXCIsIEdlbmVyYXRvckZ1bmN0aW9uUHJvdG90eXBlKSwgZGVmaW5lKEdlbmVyYXRvckZ1bmN0aW9uUHJvdG90eXBlLCBcImNvbnN0cnVjdG9yXCIsIEdlbmVyYXRvckZ1bmN0aW9uKSwgR2VuZXJhdG9yRnVuY3Rpb24uZGlzcGxheU5hbWUgPSBkZWZpbmUoR2VuZXJhdG9yRnVuY3Rpb25Qcm90b3R5cGUsIHRvU3RyaW5nVGFnU3ltYm9sLCBcIkdlbmVyYXRvckZ1bmN0aW9uXCIpLCBleHBvcnRzLmlzR2VuZXJhdG9yRnVuY3Rpb24gPSBmdW5jdGlvbiAoZ2VuRnVuKSB7XG4gICAgdmFyIGN0b3IgPSBcImZ1bmN0aW9uXCIgPT0gdHlwZW9mIGdlbkZ1biAmJiBnZW5GdW4uY29uc3RydWN0b3I7XG4gICAgcmV0dXJuICEhY3RvciAmJiAoY3RvciA9PT0gR2VuZXJhdG9yRnVuY3Rpb24gfHwgXCJHZW5lcmF0b3JGdW5jdGlvblwiID09PSAoY3Rvci5kaXNwbGF5TmFtZSB8fCBjdG9yLm5hbWUpKTtcbiAgfSwgZXhwb3J0cy5tYXJrID0gZnVuY3Rpb24gKGdlbkZ1bikge1xuICAgIHJldHVybiBPYmplY3Quc2V0UHJvdG90eXBlT2YgPyBPYmplY3Quc2V0UHJvdG90eXBlT2YoZ2VuRnVuLCBHZW5lcmF0b3JGdW5jdGlvblByb3RvdHlwZSkgOiAoZ2VuRnVuLl9fcHJvdG9fXyA9IEdlbmVyYXRvckZ1bmN0aW9uUHJvdG90eXBlLCBkZWZpbmUoZ2VuRnVuLCB0b1N0cmluZ1RhZ1N5bWJvbCwgXCJHZW5lcmF0b3JGdW5jdGlvblwiKSksIGdlbkZ1bi5wcm90b3R5cGUgPSBPYmplY3QuY3JlYXRlKEdwKSwgZ2VuRnVuO1xuICB9LCBleHBvcnRzLmF3cmFwID0gZnVuY3Rpb24gKGFyZykge1xuICAgIHJldHVybiB7XG4gICAgICBfX2F3YWl0OiBhcmdcbiAgICB9O1xuICB9LCBkZWZpbmVJdGVyYXRvck1ldGhvZHMoQXN5bmNJdGVyYXRvci5wcm90b3R5cGUpLCBkZWZpbmUoQXN5bmNJdGVyYXRvci5wcm90b3R5cGUsIGFzeW5jSXRlcmF0b3JTeW1ib2wsIGZ1bmN0aW9uICgpIHtcbiAgICByZXR1cm4gdGhpcztcbiAgfSksIGV4cG9ydHMuQXN5bmNJdGVyYXRvciA9IEFzeW5jSXRlcmF0b3IsIGV4cG9ydHMuYXN5bmMgPSBmdW5jdGlvbiAoaW5uZXJGbiwgb3V0ZXJGbiwgc2VsZiwgdHJ5TG9jc0xpc3QsIFByb21pc2VJbXBsKSB7XG4gICAgdm9pZCAwID09PSBQcm9taXNlSW1wbCAmJiAoUHJvbWlzZUltcGwgPSBQcm9taXNlKTtcbiAgICB2YXIgaXRlciA9IG5ldyBBc3luY0l0ZXJhdG9yKHdyYXAoaW5uZXJGbiwgb3V0ZXJGbiwgc2VsZiwgdHJ5TG9jc0xpc3QpLCBQcm9taXNlSW1wbCk7XG4gICAgcmV0dXJuIGV4cG9ydHMuaXNHZW5lcmF0b3JGdW5jdGlvbihvdXRlckZuKSA/IGl0ZXIgOiBpdGVyLm5leHQoKS50aGVuKGZ1bmN0aW9uIChyZXN1bHQpIHtcbiAgICAgIHJldHVybiByZXN1bHQuZG9uZSA/IHJlc3VsdC52YWx1ZSA6IGl0ZXIubmV4dCgpO1xuICAgIH0pO1xuICB9LCBkZWZpbmVJdGVyYXRvck1ldGhvZHMoR3ApLCBkZWZpbmUoR3AsIHRvU3RyaW5nVGFnU3ltYm9sLCBcIkdlbmVyYXRvclwiKSwgZGVmaW5lKEdwLCBpdGVyYXRvclN5bWJvbCwgZnVuY3Rpb24gKCkge1xuICAgIHJldHVybiB0aGlzO1xuICB9KSwgZGVmaW5lKEdwLCBcInRvU3RyaW5nXCIsIGZ1bmN0aW9uICgpIHtcbiAgICByZXR1cm4gXCJbb2JqZWN0IEdlbmVyYXRvcl1cIjtcbiAgfSksIGV4cG9ydHMua2V5cyA9IGZ1bmN0aW9uIChvYmplY3QpIHtcbiAgICB2YXIga2V5cyA9IFtdO1xuXG4gICAgZm9yICh2YXIga2V5IGluIG9iamVjdCkge1xuICAgICAga2V5cy5wdXNoKGtleSk7XG4gICAgfVxuXG4gICAgcmV0dXJuIGtleXMucmV2ZXJzZSgpLCBmdW5jdGlvbiBuZXh0KCkge1xuICAgICAgZm9yICg7IGtleXMubGVuZ3RoOykge1xuICAgICAgICB2YXIga2V5ID0ga2V5cy5wb3AoKTtcbiAgICAgICAgaWYgKGtleSBpbiBvYmplY3QpIHJldHVybiBuZXh0LnZhbHVlID0ga2V5LCBuZXh0LmRvbmUgPSAhMSwgbmV4dDtcbiAgICAgIH1cblxuICAgICAgcmV0dXJuIG5leHQuZG9uZSA9ICEwLCBuZXh0O1xuICAgIH07XG4gIH0sIGV4cG9ydHMudmFsdWVzID0gdmFsdWVzLCBDb250ZXh0LnByb3RvdHlwZSA9IHtcbiAgICBjb25zdHJ1Y3RvcjogQ29udGV4dCxcbiAgICByZXNldDogZnVuY3Rpb24gcmVzZXQoc2tpcFRlbXBSZXNldCkge1xuICAgICAgaWYgKHRoaXMucHJldiA9IDAsIHRoaXMubmV4dCA9IDAsIHRoaXMuc2VudCA9IHRoaXMuX3NlbnQgPSB1bmRlZmluZWQsIHRoaXMuZG9uZSA9ICExLCB0aGlzLmRlbGVnYXRlID0gbnVsbCwgdGhpcy5tZXRob2QgPSBcIm5leHRcIiwgdGhpcy5hcmcgPSB1bmRlZmluZWQsIHRoaXMudHJ5RW50cmllcy5mb3JFYWNoKHJlc2V0VHJ5RW50cnkpLCAhc2tpcFRlbXBSZXNldCkgZm9yICh2YXIgbmFtZSBpbiB0aGlzKSB7XG4gICAgICAgIFwidFwiID09PSBuYW1lLmNoYXJBdCgwKSAmJiBoYXNPd24uY2FsbCh0aGlzLCBuYW1lKSAmJiAhaXNOYU4oK25hbWUuc2xpY2UoMSkpICYmICh0aGlzW25hbWVdID0gdW5kZWZpbmVkKTtcbiAgICAgIH1cbiAgICB9LFxuICAgIHN0b3A6IGZ1bmN0aW9uIHN0b3AoKSB7XG4gICAgICB0aGlzLmRvbmUgPSAhMDtcbiAgICAgIHZhciByb290UmVjb3JkID0gdGhpcy50cnlFbnRyaWVzWzBdLmNvbXBsZXRpb247XG4gICAgICBpZiAoXCJ0aHJvd1wiID09PSByb290UmVjb3JkLnR5cGUpIHRocm93IHJvb3RSZWNvcmQuYXJnO1xuICAgICAgcmV0dXJuIHRoaXMucnZhbDtcbiAgICB9LFxuICAgIGRpc3BhdGNoRXhjZXB0aW9uOiBmdW5jdGlvbiBkaXNwYXRjaEV4Y2VwdGlvbihleGNlcHRpb24pIHtcbiAgICAgIGlmICh0aGlzLmRvbmUpIHRocm93IGV4Y2VwdGlvbjtcbiAgICAgIHZhciBjb250ZXh0ID0gdGhpcztcblxuICAgICAgZnVuY3Rpb24gaGFuZGxlKGxvYywgY2F1Z2h0KSB7XG4gICAgICAgIHJldHVybiByZWNvcmQudHlwZSA9IFwidGhyb3dcIiwgcmVjb3JkLmFyZyA9IGV4Y2VwdGlvbiwgY29udGV4dC5uZXh0ID0gbG9jLCBjYXVnaHQgJiYgKGNvbnRleHQubWV0aG9kID0gXCJuZXh0XCIsIGNvbnRleHQuYXJnID0gdW5kZWZpbmVkKSwgISFjYXVnaHQ7XG4gICAgICB9XG5cbiAgICAgIGZvciAodmFyIGkgPSB0aGlzLnRyeUVudHJpZXMubGVuZ3RoIC0gMTsgaSA+PSAwOyAtLWkpIHtcbiAgICAgICAgdmFyIGVudHJ5ID0gdGhpcy50cnlFbnRyaWVzW2ldLFxuICAgICAgICAgICAgcmVjb3JkID0gZW50cnkuY29tcGxldGlvbjtcbiAgICAgICAgaWYgKFwicm9vdFwiID09PSBlbnRyeS50cnlMb2MpIHJldHVybiBoYW5kbGUoXCJlbmRcIik7XG5cbiAgICAgICAgaWYgKGVudHJ5LnRyeUxvYyA8PSB0aGlzLnByZXYpIHtcbiAgICAgICAgICB2YXIgaGFzQ2F0Y2ggPSBoYXNPd24uY2FsbChlbnRyeSwgXCJjYXRjaExvY1wiKSxcbiAgICAgICAgICAgICAgaGFzRmluYWxseSA9IGhhc093bi5jYWxsKGVudHJ5LCBcImZpbmFsbHlMb2NcIik7XG5cbiAgICAgICAgICBpZiAoaGFzQ2F0Y2ggJiYgaGFzRmluYWxseSkge1xuICAgICAgICAgICAgaWYgKHRoaXMucHJldiA8IGVudHJ5LmNhdGNoTG9jKSByZXR1cm4gaGFuZGxlKGVudHJ5LmNhdGNoTG9jLCAhMCk7XG4gICAgICAgICAgICBpZiAodGhpcy5wcmV2IDwgZW50cnkuZmluYWxseUxvYykgcmV0dXJuIGhhbmRsZShlbnRyeS5maW5hbGx5TG9jKTtcbiAgICAgICAgICB9IGVsc2UgaWYgKGhhc0NhdGNoKSB7XG4gICAgICAgICAgICBpZiAodGhpcy5wcmV2IDwgZW50cnkuY2F0Y2hMb2MpIHJldHVybiBoYW5kbGUoZW50cnkuY2F0Y2hMb2MsICEwKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgaWYgKCFoYXNGaW5hbGx5KSB0aHJvdyBuZXcgRXJyb3IoXCJ0cnkgc3RhdGVtZW50IHdpdGhvdXQgY2F0Y2ggb3IgZmluYWxseVwiKTtcbiAgICAgICAgICAgIGlmICh0aGlzLnByZXYgPCBlbnRyeS5maW5hbGx5TG9jKSByZXR1cm4gaGFuZGxlKGVudHJ5LmZpbmFsbHlMb2MpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0sXG4gICAgYWJydXB0OiBmdW5jdGlvbiBhYnJ1cHQodHlwZSwgYXJnKSB7XG4gICAgICBmb3IgKHZhciBpID0gdGhpcy50cnlFbnRyaWVzLmxlbmd0aCAtIDE7IGkgPj0gMDsgLS1pKSB7XG4gICAgICAgIHZhciBlbnRyeSA9IHRoaXMudHJ5RW50cmllc1tpXTtcblxuICAgICAgICBpZiAoZW50cnkudHJ5TG9jIDw9IHRoaXMucHJldiAmJiBoYXNPd24uY2FsbChlbnRyeSwgXCJmaW5hbGx5TG9jXCIpICYmIHRoaXMucHJldiA8IGVudHJ5LmZpbmFsbHlMb2MpIHtcbiAgICAgICAgICB2YXIgZmluYWxseUVudHJ5ID0gZW50cnk7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgZmluYWxseUVudHJ5ICYmIChcImJyZWFrXCIgPT09IHR5cGUgfHwgXCJjb250aW51ZVwiID09PSB0eXBlKSAmJiBmaW5hbGx5RW50cnkudHJ5TG9jIDw9IGFyZyAmJiBhcmcgPD0gZmluYWxseUVudHJ5LmZpbmFsbHlMb2MgJiYgKGZpbmFsbHlFbnRyeSA9IG51bGwpO1xuICAgICAgdmFyIHJlY29yZCA9IGZpbmFsbHlFbnRyeSA/IGZpbmFsbHlFbnRyeS5jb21wbGV0aW9uIDoge307XG4gICAgICByZXR1cm4gcmVjb3JkLnR5cGUgPSB0eXBlLCByZWNvcmQuYXJnID0gYXJnLCBmaW5hbGx5RW50cnkgPyAodGhpcy5tZXRob2QgPSBcIm5leHRcIiwgdGhpcy5uZXh0ID0gZmluYWxseUVudHJ5LmZpbmFsbHlMb2MsIENvbnRpbnVlU2VudGluZWwpIDogdGhpcy5jb21wbGV0ZShyZWNvcmQpO1xuICAgIH0sXG4gICAgY29tcGxldGU6IGZ1bmN0aW9uIGNvbXBsZXRlKHJlY29yZCwgYWZ0ZXJMb2MpIHtcbiAgICAgIGlmIChcInRocm93XCIgPT09IHJlY29yZC50eXBlKSB0aHJvdyByZWNvcmQuYXJnO1xuICAgICAgcmV0dXJuIFwiYnJlYWtcIiA9PT0gcmVjb3JkLnR5cGUgfHwgXCJjb250aW51ZVwiID09PSByZWNvcmQudHlwZSA/IHRoaXMubmV4dCA9IHJlY29yZC5hcmcgOiBcInJldHVyblwiID09PSByZWNvcmQudHlwZSA/ICh0aGlzLnJ2YWwgPSB0aGlzLmFyZyA9IHJlY29yZC5hcmcsIHRoaXMubWV0aG9kID0gXCJyZXR1cm5cIiwgdGhpcy5uZXh0ID0gXCJlbmRcIikgOiBcIm5vcm1hbFwiID09PSByZWNvcmQudHlwZSAmJiBhZnRlckxvYyAmJiAodGhpcy5uZXh0ID0gYWZ0ZXJMb2MpLCBDb250aW51ZVNlbnRpbmVsO1xuICAgIH0sXG4gICAgZmluaXNoOiBmdW5jdGlvbiBmaW5pc2goZmluYWxseUxvYykge1xuICAgICAgZm9yICh2YXIgaSA9IHRoaXMudHJ5RW50cmllcy5sZW5ndGggLSAxOyBpID49IDA7IC0taSkge1xuICAgICAgICB2YXIgZW50cnkgPSB0aGlzLnRyeUVudHJpZXNbaV07XG4gICAgICAgIGlmIChlbnRyeS5maW5hbGx5TG9jID09PSBmaW5hbGx5TG9jKSByZXR1cm4gdGhpcy5jb21wbGV0ZShlbnRyeS5jb21wbGV0aW9uLCBlbnRyeS5hZnRlckxvYyksIHJlc2V0VHJ5RW50cnkoZW50cnkpLCBDb250aW51ZVNlbnRpbmVsO1xuICAgICAgfVxuICAgIH0sXG4gICAgXCJjYXRjaFwiOiBmdW5jdGlvbiBfY2F0Y2godHJ5TG9jKSB7XG4gICAgICBmb3IgKHZhciBpID0gdGhpcy50cnlFbnRyaWVzLmxlbmd0aCAtIDE7IGkgPj0gMDsgLS1pKSB7XG4gICAgICAgIHZhciBlbnRyeSA9IHRoaXMudHJ5RW50cmllc1tpXTtcblxuICAgICAgICBpZiAoZW50cnkudHJ5TG9jID09PSB0cnlMb2MpIHtcbiAgICAgICAgICB2YXIgcmVjb3JkID0gZW50cnkuY29tcGxldGlvbjtcblxuICAgICAgICAgIGlmIChcInRocm93XCIgPT09IHJlY29yZC50eXBlKSB7XG4gICAgICAgICAgICB2YXIgdGhyb3duID0gcmVjb3JkLmFyZztcbiAgICAgICAgICAgIHJlc2V0VHJ5RW50cnkoZW50cnkpO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIHJldHVybiB0aHJvd247XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiaWxsZWdhbCBjYXRjaCBhdHRlbXB0XCIpO1xuICAgIH0sXG4gICAgZGVsZWdhdGVZaWVsZDogZnVuY3Rpb24gZGVsZWdhdGVZaWVsZChpdGVyYWJsZSwgcmVzdWx0TmFtZSwgbmV4dExvYykge1xuICAgICAgcmV0dXJuIHRoaXMuZGVsZWdhdGUgPSB7XG4gICAgICAgIGl0ZXJhdG9yOiB2YWx1ZXMoaXRlcmFibGUpLFxuICAgICAgICByZXN1bHROYW1lOiByZXN1bHROYW1lLFxuICAgICAgICBuZXh0TG9jOiBuZXh0TG9jXG4gICAgICB9LCBcIm5leHRcIiA9PT0gdGhpcy5tZXRob2QgJiYgKHRoaXMuYXJnID0gdW5kZWZpbmVkKSwgQ29udGludWVTZW50aW5lbDtcbiAgICB9XG4gIH0sIGV4cG9ydHM7XG59XG5cbm1vZHVsZS5leHBvcnRzID0gX3JlZ2VuZXJhdG9yUnVudGltZSwgbW9kdWxlLmV4cG9ydHMuX19lc01vZHVsZSA9IHRydWUsIG1vZHVsZS5leHBvcnRzW1wiZGVmYXVsdFwiXSA9IG1vZHVsZS5leHBvcnRzOyIsInZhciBhcnJheVdpdGhvdXRIb2xlcyA9IHJlcXVpcmUoXCIuL2FycmF5V2l0aG91dEhvbGVzLmpzXCIpO1xuXG52YXIgaXRlcmFibGVUb0FycmF5ID0gcmVxdWlyZShcIi4vaXRlcmFibGVUb0FycmF5LmpzXCIpO1xuXG52YXIgdW5zdXBwb3J0ZWRJdGVyYWJsZVRvQXJyYXkgPSByZXF1aXJlKFwiLi91bnN1cHBvcnRlZEl0ZXJhYmxlVG9BcnJheS5qc1wiKTtcblxudmFyIG5vbkl0ZXJhYmxlU3ByZWFkID0gcmVxdWlyZShcIi4vbm9uSXRlcmFibGVTcHJlYWQuanNcIik7XG5cbmZ1bmN0aW9uIF90b0NvbnN1bWFibGVBcnJheShhcnIpIHtcbiAgcmV0dXJuIGFycmF5V2l0aG91dEhvbGVzKGFycikgfHwgaXRlcmFibGVUb0FycmF5KGFycikgfHwgdW5zdXBwb3J0ZWRJdGVyYWJsZVRvQXJyYXkoYXJyKSB8fCBub25JdGVyYWJsZVNwcmVhZCgpO1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IF90b0NvbnN1bWFibGVBcnJheSwgbW9kdWxlLmV4cG9ydHMuX19lc01vZHVsZSA9IHRydWUsIG1vZHVsZS5leHBvcnRzW1wiZGVmYXVsdFwiXSA9IG1vZHVsZS5leHBvcnRzOyIsImZ1bmN0aW9uIF90eXBlb2Yob2JqKSB7XG4gIFwiQGJhYmVsL2hlbHBlcnMgLSB0eXBlb2ZcIjtcblxuICByZXR1cm4gKG1vZHVsZS5leHBvcnRzID0gX3R5cGVvZiA9IFwiZnVuY3Rpb25cIiA9PSB0eXBlb2YgU3ltYm9sICYmIFwic3ltYm9sXCIgPT0gdHlwZW9mIFN5bWJvbC5pdGVyYXRvciA/IGZ1bmN0aW9uIChvYmopIHtcbiAgICByZXR1cm4gdHlwZW9mIG9iajtcbiAgfSA6IGZ1bmN0aW9uIChvYmopIHtcbiAgICByZXR1cm4gb2JqICYmIFwiZnVuY3Rpb25cIiA9PSB0eXBlb2YgU3ltYm9sICYmIG9iai5jb25zdHJ1Y3RvciA9PT0gU3ltYm9sICYmIG9iaiAhPT0gU3ltYm9sLnByb3RvdHlwZSA/IFwic3ltYm9sXCIgOiB0eXBlb2Ygb2JqO1xuICB9LCBtb2R1bGUuZXhwb3J0cy5fX2VzTW9kdWxlID0gdHJ1ZSwgbW9kdWxlLmV4cG9ydHNbXCJkZWZhdWx0XCJdID0gbW9kdWxlLmV4cG9ydHMpLCBfdHlwZW9mKG9iaik7XG59XG5cbm1vZHVsZS5leHBvcnRzID0gX3R5cGVvZiwgbW9kdWxlLmV4cG9ydHMuX19lc01vZHVsZSA9IHRydWUsIG1vZHVsZS5leHBvcnRzW1wiZGVmYXVsdFwiXSA9IG1vZHVsZS5leHBvcnRzOyIsInZhciBhcnJheUxpa2VUb0FycmF5ID0gcmVxdWlyZShcIi4vYXJyYXlMaWtlVG9BcnJheS5qc1wiKTtcblxuZnVuY3Rpb24gX3Vuc3VwcG9ydGVkSXRlcmFibGVUb0FycmF5KG8sIG1pbkxlbikge1xuICBpZiAoIW8pIHJldHVybjtcbiAgaWYgKHR5cGVvZiBvID09PSBcInN0cmluZ1wiKSByZXR1cm4gYXJyYXlMaWtlVG9BcnJheShvLCBtaW5MZW4pO1xuICB2YXIgbiA9IE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmcuY2FsbChvKS5zbGljZSg4LCAtMSk7XG4gIGlmIChuID09PSBcIk9iamVjdFwiICYmIG8uY29uc3RydWN0b3IpIG4gPSBvLmNvbnN0cnVjdG9yLm5hbWU7XG4gIGlmIChuID09PSBcIk1hcFwiIHx8IG4gPT09IFwiU2V0XCIpIHJldHVybiBBcnJheS5mcm9tKG8pO1xuICBpZiAobiA9PT0gXCJBcmd1bWVudHNcIiB8fCAvXig/OlVpfEkpbnQoPzo4fDE2fDMyKSg/OkNsYW1wZWQpP0FycmF5JC8udGVzdChuKSkgcmV0dXJuIGFycmF5TGlrZVRvQXJyYXkobywgbWluTGVuKTtcbn1cblxubW9kdWxlLmV4cG9ydHMgPSBfdW5zdXBwb3J0ZWRJdGVyYWJsZVRvQXJyYXksIG1vZHVsZS5leHBvcnRzLl9fZXNNb2R1bGUgPSB0cnVlLCBtb2R1bGUuZXhwb3J0c1tcImRlZmF1bHRcIl0gPSBtb2R1bGUuZXhwb3J0czsiLCIvLyBUT0RPKEJhYmVsIDgpOiBSZW1vdmUgdGhpcyBmaWxlLlxuXG52YXIgcnVudGltZSA9IHJlcXVpcmUoXCIuLi9oZWxwZXJzL3JlZ2VuZXJhdG9yUnVudGltZVwiKSgpO1xubW9kdWxlLmV4cG9ydHMgPSBydW50aW1lO1xuXG4vLyBDb3BpZWQgZnJvbSBodHRwczovL2dpdGh1Yi5jb20vZmFjZWJvb2svcmVnZW5lcmF0b3IvYmxvYi9tYWluL3BhY2thZ2VzL3J1bnRpbWUvcnVudGltZS5qcyNMNzM2PVxudHJ5IHtcbiAgcmVnZW5lcmF0b3JSdW50aW1lID0gcnVudGltZTtcbn0gY2F0Y2ggKGFjY2lkZW50YWxTdHJpY3RNb2RlKSB7XG4gIGlmICh0eXBlb2YgZ2xvYmFsVGhpcyA9PT0gXCJvYmplY3RcIikge1xuICAgIGdsb2JhbFRoaXMucmVnZW5lcmF0b3JSdW50aW1lID0gcnVudGltZTtcbiAgfSBlbHNlIHtcbiAgICBGdW5jdGlvbihcInJcIiwgXCJyZWdlbmVyYXRvclJ1bnRpbWUgPSByXCIpKHJ1bnRpbWUpO1xuICB9XG59XG4iLCJcInVzZSBzdHJpY3RcIjtcblxudmFyIF9pbnRlcm9wUmVxdWlyZURlZmF1bHQgPSByZXF1aXJlKFwiQGJhYmVsL3J1bnRpbWUvaGVscGVycy9pbnRlcm9wUmVxdWlyZURlZmF1bHRcIik7XG5cbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwge1xuICB2YWx1ZTogdHJ1ZVxufSk7XG5leHBvcnRzW1wiZGVmYXVsdFwiXSA9IGFjY291bnQ7XG5cbnZhciBfcmVnZW5lcmF0b3IgPSBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0KHJlcXVpcmUoXCJAYmFiZWwvcnVudGltZS9yZWdlbmVyYXRvclwiKSk7XG5cbnZhciBfYXN5bmNUb0dlbmVyYXRvcjIgPSBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0KHJlcXVpcmUoXCJAYmFiZWwvcnVudGltZS9oZWxwZXJzL2FzeW5jVG9HZW5lcmF0b3JcIikpO1xuXG52YXIgX2Z1bGZpbGxBUElSZXF1ZXN0ID0gX2ludGVyb3BSZXF1aXJlRGVmYXVsdChyZXF1aXJlKFwiLi4vL3Byb3BzL2Z1bGZpbGxBUElSZXF1ZXN0XCIpKTtcblxudmFyIF9jcmVhdGVBcHBEYXRhID0gX2ludGVyb3BSZXF1aXJlRGVmYXVsdChyZXF1aXJlKFwiLi91dGlscy9jcmVhdGVBcHBEYXRhXCIpKTtcblxuZnVuY3Rpb24gYWNjb3VudChfeCwgX3gyKSB7XG4gIHJldHVybiBfYWNjb3VudC5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xufVxuXG5mdW5jdGlvbiBfYWNjb3VudCgpIHtcbiAgX2FjY291bnQgPSAoMCwgX2FzeW5jVG9HZW5lcmF0b3IyW1wiZGVmYXVsdFwiXSkoIC8qI19fUFVSRV9fKi9fcmVnZW5lcmF0b3JbXCJkZWZhdWx0XCJdLm1hcmsoZnVuY3Rpb24gX2NhbGxlZShyZXEsIHJlcykge1xuICAgIHJldHVybiBfcmVnZW5lcmF0b3JbXCJkZWZhdWx0XCJdLndyYXAoZnVuY3Rpb24gX2NhbGxlZSQoX2NvbnRleHQpIHtcbiAgICAgIHdoaWxlICgxKSB7XG4gICAgICAgIHN3aXRjaCAoX2NvbnRleHQucHJldiA9IF9jb250ZXh0Lm5leHQpIHtcbiAgICAgICAgICBjYXNlIDA6XG4gICAgICAgICAgICBfY29udGV4dC5uZXh0ID0gMjtcbiAgICAgICAgICAgIHJldHVybiAoMCwgX2Z1bGZpbGxBUElSZXF1ZXN0W1wiZGVmYXVsdFwiXSkocmVxLCB7XG4gICAgICAgICAgICAgIGFwcERhdGE6IF9jcmVhdGVBcHBEYXRhW1wiZGVmYXVsdFwiXSxcbiAgICAgICAgICAgICAgcGFnZURhdGE6IGZ1bmN0aW9uIHBhZ2VEYXRhKCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoe1xuICAgICAgICAgICAgICAgICAgdGl0bGU6ICdNeSBBY2NvdW50JyxcbiAgICAgICAgICAgICAgICAgIGFjY291bnQ6IHt9LFxuICAgICAgICAgICAgICAgICAgYnJlYWRjcnVtYnM6IFt7XG4gICAgICAgICAgICAgICAgICAgIHRleHQ6ICdIb21lJyxcbiAgICAgICAgICAgICAgICAgICAgaHJlZjogJy8nXG4gICAgICAgICAgICAgICAgICB9XVxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcblxuICAgICAgICAgIGNhc2UgMjpcbiAgICAgICAgICAgIHJldHVybiBfY29udGV4dC5hYnJ1cHQoXCJyZXR1cm5cIiwgX2NvbnRleHQuc2VudCk7XG5cbiAgICAgICAgICBjYXNlIDM6XG4gICAgICAgICAgY2FzZSBcImVuZFwiOlxuICAgICAgICAgICAgcmV0dXJuIF9jb250ZXh0LnN0b3AoKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0sIF9jYWxsZWUpO1xuICB9KSk7XG4gIHJldHVybiBfYWNjb3VudC5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xufVxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9YWNjb3VudC5qcy5tYXAiLCJcInVzZSBzdHJpY3RcIjtcblxudmFyIF9pbnRlcm9wUmVxdWlyZURlZmF1bHQgPSByZXF1aXJlKFwiQGJhYmVsL3J1bnRpbWUvaGVscGVycy9pbnRlcm9wUmVxdWlyZURlZmF1bHRcIik7XG5cbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwge1xuICB2YWx1ZTogdHJ1ZVxufSk7XG5leHBvcnRzW1wiZGVmYXVsdFwiXSA9IGFkZFRvQ2FydDtcblxudmFyIF9yZWdlbmVyYXRvciA9IF9pbnRlcm9wUmVxdWlyZURlZmF1bHQocmVxdWlyZShcIkBiYWJlbC9ydW50aW1lL3JlZ2VuZXJhdG9yXCIpKTtcblxudmFyIF9hc3luY1RvR2VuZXJhdG9yMiA9IF9pbnRlcm9wUmVxdWlyZURlZmF1bHQocmVxdWlyZShcIkBiYWJlbC9ydW50aW1lL2hlbHBlcnMvYXN5bmNUb0dlbmVyYXRvclwiKSk7XG5cbnZhciBfY2FydFN0b3JlID0gcmVxdWlyZShcIi4vdXRpbHMvY2FydFN0b3JlXCIpO1xuXG5mdW5jdGlvbiBhZGRUb0NhcnQoX3gsIF94MiwgX3gzKSB7XG4gIHJldHVybiBfYWRkVG9DYXJ0LmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG59XG5cbmZ1bmN0aW9uIF9hZGRUb0NhcnQoKSB7XG4gIF9hZGRUb0NhcnQgPSAoMCwgX2FzeW5jVG9HZW5lcmF0b3IyW1wiZGVmYXVsdFwiXSkoIC8qI19fUFVSRV9fKi9fcmVnZW5lcmF0b3JbXCJkZWZhdWx0XCJdLm1hcmsoZnVuY3Rpb24gX2NhbGxlZShfcmVmLCByZXEsIHJlcykge1xuICAgIHZhciBjb2xvciwgc2l6ZSwgcHJvZHVjdCwgcXVhbnRpdHk7XG4gICAgcmV0dXJuIF9yZWdlbmVyYXRvcltcImRlZmF1bHRcIl0ud3JhcChmdW5jdGlvbiBfY2FsbGVlJChfY29udGV4dCkge1xuICAgICAgd2hpbGUgKDEpIHtcbiAgICAgICAgc3dpdGNoIChfY29udGV4dC5wcmV2ID0gX2NvbnRleHQubmV4dCkge1xuICAgICAgICAgIGNhc2UgMDpcbiAgICAgICAgICAgIGNvbG9yID0gX3JlZi5jb2xvciwgc2l6ZSA9IF9yZWYuc2l6ZSwgcHJvZHVjdCA9IF9yZWYucHJvZHVjdCwgcXVhbnRpdHkgPSBfcmVmLnF1YW50aXR5O1xuICAgICAgICAgICAgcmV0dXJuIF9jb250ZXh0LmFicnVwdChcInJldHVyblwiLCB7XG4gICAgICAgICAgICAgIGNhcnQ6IHtcbiAgICAgICAgICAgICAgICBpdGVtczogKDAsIF9jYXJ0U3RvcmUuYWRkSXRlbSkocHJvZHVjdC5pZCwgcXVhbnRpdHksIHJlcSwgcmVzKVxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcblxuICAgICAgICAgIGNhc2UgMjpcbiAgICAgICAgICBjYXNlIFwiZW5kXCI6XG4gICAgICAgICAgICByZXR1cm4gX2NvbnRleHQuc3RvcCgpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfSwgX2NhbGxlZSk7XG4gIH0pKTtcbiAgcmV0dXJuIF9hZGRUb0NhcnQuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcbn1cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWFkZFRvQ2FydC5qcy5tYXAiLCJcInVzZSBzdHJpY3RcIjtcblxudmFyIF9pbnRlcm9wUmVxdWlyZURlZmF1bHQgPSByZXF1aXJlKFwiQGJhYmVsL3J1bnRpbWUvaGVscGVycy9pbnRlcm9wUmVxdWlyZURlZmF1bHRcIik7XG5cbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwge1xuICB2YWx1ZTogdHJ1ZVxufSk7XG5leHBvcnRzW1wiZGVmYXVsdFwiXSA9IGNhcnQ7XG5cbnZhciBfcmVnZW5lcmF0b3IgPSBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0KHJlcXVpcmUoXCJAYmFiZWwvcnVudGltZS9yZWdlbmVyYXRvclwiKSk7XG5cbnZhciBfYXN5bmNUb0dlbmVyYXRvcjIgPSBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0KHJlcXVpcmUoXCJAYmFiZWwvcnVudGltZS9oZWxwZXJzL2FzeW5jVG9HZW5lcmF0b3JcIikpO1xuXG52YXIgX2Z1bGZpbGxBUElSZXF1ZXN0ID0gX2ludGVyb3BSZXF1aXJlRGVmYXVsdChyZXF1aXJlKFwiLi4vcHJvcHMvZnVsZmlsbEFQSVJlcXVlc3RcIikpO1xuXG52YXIgX2NyZWF0ZUFwcERhdGEgPSBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0KHJlcXVpcmUoXCIuL3V0aWxzL2NyZWF0ZUFwcERhdGFcIikpO1xuXG52YXIgX2NhcnRTdG9yZSA9IHJlcXVpcmUoXCIuL3V0aWxzL2NhcnRTdG9yZVwiKTtcblxuZnVuY3Rpb24gY2FydChfeCwgX3gyKSB7XG4gIHJldHVybiBfY2FydC5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xufVxuXG5mdW5jdGlvbiBfY2FydCgpIHtcbiAgX2NhcnQgPSAoMCwgX2FzeW5jVG9HZW5lcmF0b3IyW1wiZGVmYXVsdFwiXSkoIC8qI19fUFVSRV9fKi9fcmVnZW5lcmF0b3JbXCJkZWZhdWx0XCJdLm1hcmsoZnVuY3Rpb24gX2NhbGxlZShyZXEsIHJlcykge1xuICAgIHJldHVybiBfcmVnZW5lcmF0b3JbXCJkZWZhdWx0XCJdLndyYXAoZnVuY3Rpb24gX2NhbGxlZSQoX2NvbnRleHQpIHtcbiAgICAgIHdoaWxlICgxKSB7XG4gICAgICAgIHN3aXRjaCAoX2NvbnRleHQucHJldiA9IF9jb250ZXh0Lm5leHQpIHtcbiAgICAgICAgICBjYXNlIDA6XG4gICAgICAgICAgICByZXR1cm4gX2NvbnRleHQuYWJydXB0KFwicmV0dXJuXCIsICgwLCBfZnVsZmlsbEFQSVJlcXVlc3RbXCJkZWZhdWx0XCJdKShyZXEsIHtcbiAgICAgICAgICAgICAgYXBwRGF0YTogX2NyZWF0ZUFwcERhdGFbXCJkZWZhdWx0XCJdLFxuICAgICAgICAgICAgICBwYWdlRGF0YTogZnVuY3Rpb24gcGFnZURhdGEoKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZSh7XG4gICAgICAgICAgICAgICAgICB0aXRsZTogJ015IENhcnQnLFxuICAgICAgICAgICAgICAgICAgYnJlYWRjcnVtYnM6IFt7XG4gICAgICAgICAgICAgICAgICAgIHRleHQ6ICdIb21lJyxcbiAgICAgICAgICAgICAgICAgICAgaHJlZjogJy8nXG4gICAgICAgICAgICAgICAgICB9XSxcbiAgICAgICAgICAgICAgICAgIGNhcnQ6IHtcbiAgICAgICAgICAgICAgICAgICAgaXRlbXM6ICgwLCBfY2FydFN0b3JlLmdldFByb2R1Y3RzKShyZXEsIHJlcylcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSkpO1xuXG4gICAgICAgICAgY2FzZSAxOlxuICAgICAgICAgIGNhc2UgXCJlbmRcIjpcbiAgICAgICAgICAgIHJldHVybiBfY29udGV4dC5zdG9wKCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9LCBfY2FsbGVlKTtcbiAgfSkpO1xuICByZXR1cm4gX2NhcnQuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcbn1cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWNhcnQuanMubWFwIiwiXCJ1c2Ugc3RyaWN0XCI7XG5cbnZhciBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0ID0gcmVxdWlyZShcIkBiYWJlbC9ydW50aW1lL2hlbHBlcnMvaW50ZXJvcFJlcXVpcmVEZWZhdWx0XCIpO1xuXG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHtcbiAgdmFsdWU6IHRydWVcbn0pO1xuZXhwb3J0c1tcImRlZmF1bHRcIl0gPSBob21lO1xuXG52YXIgX3JlZ2VuZXJhdG9yID0gX2ludGVyb3BSZXF1aXJlRGVmYXVsdChyZXF1aXJlKFwiQGJhYmVsL3J1bnRpbWUvcmVnZW5lcmF0b3JcIikpO1xuXG52YXIgX2FzeW5jVG9HZW5lcmF0b3IyID0gX2ludGVyb3BSZXF1aXJlRGVmYXVsdChyZXF1aXJlKFwiQGJhYmVsL3J1bnRpbWUvaGVscGVycy9hc3luY1RvR2VuZXJhdG9yXCIpKTtcblxudmFyIF9mdWxmaWxsQVBJUmVxdWVzdCA9IF9pbnRlcm9wUmVxdWlyZURlZmF1bHQocmVxdWlyZShcIi4uL3Byb3BzL2Z1bGZpbGxBUElSZXF1ZXN0XCIpKTtcblxudmFyIF9jcmVhdGVBcHBEYXRhID0gX2ludGVyb3BSZXF1aXJlRGVmYXVsdChyZXF1aXJlKFwiLi91dGlscy9jcmVhdGVBcHBEYXRhXCIpKTtcblxuZnVuY3Rpb24gaG9tZShfeCwgX3gyKSB7XG4gIHJldHVybiBfaG9tZS5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xufVxuXG5mdW5jdGlvbiBfaG9tZSgpIHtcbiAgX2hvbWUgPSAoMCwgX2FzeW5jVG9HZW5lcmF0b3IyW1wiZGVmYXVsdFwiXSkoIC8qI19fUFVSRV9fKi9fcmVnZW5lcmF0b3JbXCJkZWZhdWx0XCJdLm1hcmsoZnVuY3Rpb24gX2NhbGxlZShyZXEsIHJlcykge1xuICAgIHJldHVybiBfcmVnZW5lcmF0b3JbXCJkZWZhdWx0XCJdLndyYXAoZnVuY3Rpb24gX2NhbGxlZSQoX2NvbnRleHQpIHtcbiAgICAgIHdoaWxlICgxKSB7XG4gICAgICAgIHN3aXRjaCAoX2NvbnRleHQucHJldiA9IF9jb250ZXh0Lm5leHQpIHtcbiAgICAgICAgICBjYXNlIDA6XG4gICAgICAgICAgICBfY29udGV4dC5uZXh0ID0gMjtcbiAgICAgICAgICAgIHJldHVybiAoMCwgX2Z1bGZpbGxBUElSZXF1ZXN0W1wiZGVmYXVsdFwiXSkocmVxLCB7XG4gICAgICAgICAgICAgIGFwcERhdGE6IF9jcmVhdGVBcHBEYXRhW1wiZGVmYXVsdFwiXSxcbiAgICAgICAgICAgICAgcGFnZURhdGE6IGZ1bmN0aW9uIHBhZ2VEYXRhKCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoe1xuICAgICAgICAgICAgICAgICAgdGl0bGU6ICdSZWFjdCBTdG9yZWZyb250JyxcbiAgICAgICAgICAgICAgICAgIHNsb3RzOiB7XG4gICAgICAgICAgICAgICAgICAgIGhlYWRpbmc6ICdXZWxjb21lIHRvIHlvdXIgbmV3IFJlYWN0IFN0b3JlZnJvbnQgYXBwLicsXG4gICAgICAgICAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBcIlxcbiAgICAgICAgICAgICAgICA8cD5cXG4gICAgICAgICAgICAgICAgSGVyZSB5b3UnbGwgZmluZCBtb2NrIGhvbWUsIGNhdGVnb3J5LCBzdWJjYXRlZ29yeSwgcHJvZHVjdCwgYW5kIGNhcnQgcGFnZXMgdGhhdCB5b3UgY2FuXFxuICAgICAgICAgICAgICAgIHVzZSBhcyBhIHN0YXJ0aW5nIHBvaW50IHRvIGJ1aWxkIHlvdXIgUFdBLlxcbiAgICAgICAgICAgICAgPC9wPlxcbiAgICAgICAgICAgICAgPHA+SGFwcHkgY29kaW5nITwvcD5cXG4gICAgICAgICAgICBcIlxuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcblxuICAgICAgICAgIGNhc2UgMjpcbiAgICAgICAgICAgIHJldHVybiBfY29udGV4dC5hYnJ1cHQoXCJyZXR1cm5cIiwgX2NvbnRleHQuc2VudCk7XG5cbiAgICAgICAgICBjYXNlIDM6XG4gICAgICAgICAgY2FzZSBcImVuZFwiOlxuICAgICAgICAgICAgcmV0dXJuIF9jb250ZXh0LnN0b3AoKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0sIF9jYWxsZWUpO1xuICB9KSk7XG4gIHJldHVybiBfaG9tZS5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xufVxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aG9tZS5qcy5tYXAiLCJcInVzZSBzdHJpY3RcIjtcblxudmFyIF9pbnRlcm9wUmVxdWlyZURlZmF1bHQgPSByZXF1aXJlKFwiQGJhYmVsL3J1bnRpbWUvaGVscGVycy9pbnRlcm9wUmVxdWlyZURlZmF1bHRcIik7XG5cbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwge1xuICB2YWx1ZTogdHJ1ZVxufSk7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJjYXJ0XCIsIHtcbiAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgZ2V0OiBmdW5jdGlvbiBnZXQoKSB7XG4gICAgcmV0dXJuIF9jYXJ0W1wiZGVmYXVsdFwiXTtcbiAgfVxufSk7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJhY2NvdW50XCIsIHtcbiAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgZ2V0OiBmdW5jdGlvbiBnZXQoKSB7XG4gICAgcmV0dXJuIF9hY2NvdW50W1wiZGVmYXVsdFwiXTtcbiAgfVxufSk7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJhZGRUb0NhcnRcIiwge1xuICBlbnVtZXJhYmxlOiB0cnVlLFxuICBnZXQ6IGZ1bmN0aW9uIGdldCgpIHtcbiAgICByZXR1cm4gX2FkZFRvQ2FydFtcImRlZmF1bHRcIl07XG4gIH1cbn0pO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwidXBkYXRlQ2FydEl0ZW1cIiwge1xuICBlbnVtZXJhYmxlOiB0cnVlLFxuICBnZXQ6IGZ1bmN0aW9uIGdldCgpIHtcbiAgICByZXR1cm4gX3VwZGF0ZUNhcnRJdGVtW1wiZGVmYXVsdFwiXTtcbiAgfVxufSk7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJyZW1vdmVDYXJ0SXRlbVwiLCB7XG4gIGVudW1lcmFibGU6IHRydWUsXG4gIGdldDogZnVuY3Rpb24gZ2V0KCkge1xuICAgIHJldHVybiBfcmVtb3ZlQ2FydEl0ZW1bXCJkZWZhdWx0XCJdO1xuICB9XG59KTtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcImhvbWVcIiwge1xuICBlbnVtZXJhYmxlOiB0cnVlLFxuICBnZXQ6IGZ1bmN0aW9uIGdldCgpIHtcbiAgICByZXR1cm4gX2hvbWVbXCJkZWZhdWx0XCJdO1xuICB9XG59KTtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcInByb2R1Y3RcIiwge1xuICBlbnVtZXJhYmxlOiB0cnVlLFxuICBnZXQ6IGZ1bmN0aW9uIGdldCgpIHtcbiAgICByZXR1cm4gX3Byb2R1Y3RbXCJkZWZhdWx0XCJdO1xuICB9XG59KTtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcInByb2R1Y3RNZWRpYVwiLCB7XG4gIGVudW1lcmFibGU6IHRydWUsXG4gIGdldDogZnVuY3Rpb24gZ2V0KCkge1xuICAgIHJldHVybiBfcHJvZHVjdE1lZGlhW1wiZGVmYXVsdFwiXTtcbiAgfVxufSk7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJwcm9kdWN0U3VnZ2VzdGlvbnNcIiwge1xuICBlbnVtZXJhYmxlOiB0cnVlLFxuICBnZXQ6IGZ1bmN0aW9uIGdldCgpIHtcbiAgICByZXR1cm4gX3Byb2R1Y3RTdWdnZXN0aW9uc1tcImRlZmF1bHRcIl07XG4gIH1cbn0pO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwic2VhcmNoXCIsIHtcbiAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgZ2V0OiBmdW5jdGlvbiBnZXQoKSB7XG4gICAgcmV0dXJuIF9zZWFyY2hbXCJkZWZhdWx0XCJdO1xuICB9XG59KTtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcInNlYXJjaFN1Z2dlc3Rpb25zXCIsIHtcbiAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgZ2V0OiBmdW5jdGlvbiBnZXQoKSB7XG4gICAgcmV0dXJuIF9zZWFyY2hTdWdnZXN0aW9uc1tcImRlZmF1bHRcIl07XG4gIH1cbn0pO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwic2Vzc2lvblwiLCB7XG4gIGVudW1lcmFibGU6IHRydWUsXG4gIGdldDogZnVuY3Rpb24gZ2V0KCkge1xuICAgIHJldHVybiBfc2Vzc2lvbltcImRlZmF1bHRcIl07XG4gIH1cbn0pO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwic3ViY2F0ZWdvcnlcIiwge1xuICBlbnVtZXJhYmxlOiB0cnVlLFxuICBnZXQ6IGZ1bmN0aW9uIGdldCgpIHtcbiAgICByZXR1cm4gX3N1YmNhdGVnb3J5W1wiZGVmYXVsdFwiXTtcbiAgfVxufSk7XG5cbnZhciBfY2FydCA9IF9pbnRlcm9wUmVxdWlyZURlZmF1bHQocmVxdWlyZShcIi4vY2FydC5qc1wiKSk7XG5cbnZhciBfYWNjb3VudCA9IF9pbnRlcm9wUmVxdWlyZURlZmF1bHQocmVxdWlyZShcIi4vYWNjb3VudC5qc1wiKSk7XG5cbnZhciBfYWRkVG9DYXJ0ID0gX2ludGVyb3BSZXF1aXJlRGVmYXVsdChyZXF1aXJlKFwiLi9hZGRUb0NhcnQuanNcIikpO1xuXG52YXIgX3VwZGF0ZUNhcnRJdGVtID0gX2ludGVyb3BSZXF1aXJlRGVmYXVsdChyZXF1aXJlKFwiLi91cGRhdGVDYXJ0SXRlbS5qc1wiKSk7XG5cbnZhciBfcmVtb3ZlQ2FydEl0ZW0gPSBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0KHJlcXVpcmUoXCIuL3JlbW92ZUNhcnRJdGVtLmpzXCIpKTtcblxudmFyIF9ob21lID0gX2ludGVyb3BSZXF1aXJlRGVmYXVsdChyZXF1aXJlKFwiLi9ob21lLmpzXCIpKTtcblxudmFyIF9wcm9kdWN0ID0gX2ludGVyb3BSZXF1aXJlRGVmYXVsdChyZXF1aXJlKFwiLi9wcm9kdWN0LmpzXCIpKTtcblxudmFyIF9wcm9kdWN0TWVkaWEgPSBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0KHJlcXVpcmUoXCIuL3Byb2R1Y3RNZWRpYS5qc1wiKSk7XG5cbnZhciBfcHJvZHVjdFN1Z2dlc3Rpb25zID0gX2ludGVyb3BSZXF1aXJlRGVmYXVsdChyZXF1aXJlKFwiLi9wcm9kdWN0U3VnZ2VzdGlvbnMuanNcIikpO1xuXG52YXIgX3NlYXJjaCA9IF9pbnRlcm9wUmVxdWlyZURlZmF1bHQocmVxdWlyZShcIi4vc2VhcmNoLmpzXCIpKTtcblxudmFyIF9zZWFyY2hTdWdnZXN0aW9ucyA9IF9pbnRlcm9wUmVxdWlyZURlZmF1bHQocmVxdWlyZShcIi4vc2VhcmNoU3VnZ2VzdGlvbnMuanNcIikpO1xuXG52YXIgX3Nlc3Npb24gPSBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0KHJlcXVpcmUoXCIuL3Nlc3Npb24uanNcIikpO1xuXG52YXIgX3N1YmNhdGVnb3J5ID0gX2ludGVyb3BSZXF1aXJlRGVmYXVsdChyZXF1aXJlKFwiLi9zdWJjYXRlZ29yeS5qc1wiKSk7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbmRleC5qcy5tYXAiLCJcInVzZSBzdHJpY3RcIjtcblxudmFyIF9pbnRlcm9wUmVxdWlyZURlZmF1bHQgPSByZXF1aXJlKFwiQGJhYmVsL3J1bnRpbWUvaGVscGVycy9pbnRlcm9wUmVxdWlyZURlZmF1bHRcIik7XG5cbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwge1xuICB2YWx1ZTogdHJ1ZVxufSk7XG5leHBvcnRzW1wiZGVmYXVsdFwiXSA9IHByb2R1Y3Q7XG5cbnZhciBfcmVnZW5lcmF0b3IgPSBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0KHJlcXVpcmUoXCJAYmFiZWwvcnVudGltZS9yZWdlbmVyYXRvclwiKSk7XG5cbnZhciBfYXN5bmNUb0dlbmVyYXRvcjIgPSBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0KHJlcXVpcmUoXCJAYmFiZWwvcnVudGltZS9oZWxwZXJzL2FzeW5jVG9HZW5lcmF0b3JcIikpO1xuXG52YXIgX2Z1bGZpbGxBUElSZXF1ZXN0ID0gX2ludGVyb3BSZXF1aXJlRGVmYXVsdChyZXF1aXJlKFwiLi4vcHJvcHMvZnVsZmlsbEFQSVJlcXVlc3RcIikpO1xuXG52YXIgX2NyZWF0ZVByb2R1Y3QgPSBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0KHJlcXVpcmUoXCIuL3V0aWxzL2NyZWF0ZVByb2R1Y3RcIikpO1xuXG52YXIgX2NyZWF0ZUFwcERhdGEgPSBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0KHJlcXVpcmUoXCIuL3V0aWxzL2NyZWF0ZUFwcERhdGFcIikpO1xuXG52YXIgX2dldEJhc2U2NEZvckltYWdlID0gX2ludGVyb3BSZXF1aXJlRGVmYXVsdChyZXF1aXJlKFwicmVhY3Qtc3RvcmVmcm9udC91dGlscy9nZXRCYXNlNjRGb3JJbWFnZVwiKSk7XG5cbmZ1bmN0aW9uIGFzY2lpU3VtKCkge1xuICB2YXIgc3RyaW5nID0gYXJndW1lbnRzLmxlbmd0aCA+IDAgJiYgYXJndW1lbnRzWzBdICE9PSB1bmRlZmluZWQgPyBhcmd1bWVudHNbMF0gOiAnJztcbiAgcmV0dXJuIHN0cmluZy5zcGxpdCgnJykucmVkdWNlKGZ1bmN0aW9uIChzLCBlKSB7XG4gICAgcmV0dXJuIHMgKyBlLmNoYXJDb2RlQXQoKTtcbiAgfSwgMCk7XG59XG5cbmZ1bmN0aW9uIHByb2R1Y3QoX3gsIF94MiwgX3gzKSB7XG4gIHJldHVybiBfcHJvZHVjdC5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xufVxuXG5mdW5jdGlvbiBfcHJvZHVjdCgpIHtcbiAgX3Byb2R1Y3QgPSAoMCwgX2FzeW5jVG9HZW5lcmF0b3IyW1wiZGVmYXVsdFwiXSkoIC8qI19fUFVSRV9fKi9fcmVnZW5lcmF0b3JbXCJkZWZhdWx0XCJdLm1hcmsoZnVuY3Rpb24gX2NhbGxlZShwYXJhbXMsIHJlcSwgcmVzKSB7XG4gICAgdmFyIGlkLCBjb2xvciwgc2l6ZSwgcmVzdWx0LCBkYXRhLCBtb2NrUHJpY2U7XG4gICAgcmV0dXJuIF9yZWdlbmVyYXRvcltcImRlZmF1bHRcIl0ud3JhcChmdW5jdGlvbiBfY2FsbGVlJChfY29udGV4dCkge1xuICAgICAgd2hpbGUgKDEpIHtcbiAgICAgICAgc3dpdGNoIChfY29udGV4dC5wcmV2ID0gX2NvbnRleHQubmV4dCkge1xuICAgICAgICAgIGNhc2UgMDpcbiAgICAgICAgICAgIGlkID0gcGFyYW1zLmlkLCBjb2xvciA9IHBhcmFtcy5jb2xvciwgc2l6ZSA9IHBhcmFtcy5zaXplO1xuICAgICAgICAgICAgX2NvbnRleHQubmV4dCA9IDM7XG4gICAgICAgICAgICByZXR1cm4gKDAsIF9mdWxmaWxsQVBJUmVxdWVzdFtcImRlZmF1bHRcIl0pKHJlcSwge1xuICAgICAgICAgICAgICBhcHBEYXRhOiBfY3JlYXRlQXBwRGF0YVtcImRlZmF1bHRcIl0sXG4gICAgICAgICAgICAgIHBhZ2VEYXRhOiBmdW5jdGlvbiBwYWdlRGF0YSgpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gZ2V0UGFnZURhdGEoaWQpO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcblxuICAgICAgICAgIGNhc2UgMzpcbiAgICAgICAgICAgIHJlc3VsdCA9IF9jb250ZXh0LnNlbnQ7XG5cbiAgICAgICAgICAgIGlmICghKGNvbG9yIHx8IHNpemUpKSB7XG4gICAgICAgICAgICAgIF9jb250ZXh0Lm5leHQgPSAxMztcbiAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIF9jb250ZXh0Lm5leHQgPSA3O1xuICAgICAgICAgICAgcmV0dXJuIGdldFBhZ2VEYXRhKGlkKTtcblxuICAgICAgICAgIGNhc2UgNzpcbiAgICAgICAgICAgIGRhdGEgPSBfY29udGV4dC5zZW50O1xuICAgICAgICAgICAgZGF0YS5jYXJvdXNlbCA9IHtcbiAgICAgICAgICAgICAgaW5kZXg6IDBcbiAgICAgICAgICAgIH07IC8vIEEgcHJpY2UgZm9yIHRoZSBmZXRjaGVkIHByb2R1Y3QgdmFyaWFudCB3b3VsZCBiZSBpbmNsdWRlZCBpblxuICAgICAgICAgICAgLy8gdGhlIHJlc3BvbnNlLCBidXQgZm9yIGRlbW8gcHVycG9zZXMgb25seSwgd2UgYXJlIHNldHRpbmcgdGhlXG4gICAgICAgICAgICAvLyBwcmljZSBiYXNlZCBvbiB0aGUgY29sb3IgbmFtZS5cblxuICAgICAgICAgICAgbW9ja1ByaWNlID0gKGFzY2lpU3VtKGNvbG9yKSArIGFzY2lpU3VtKHNpemUpKSAvIDEwMDtcbiAgICAgICAgICAgIGRhdGEucHJvZHVjdC5wcmljZSA9IG1vY2tQcmljZTtcbiAgICAgICAgICAgIGRhdGEucHJvZHVjdC5wcmljZVRleHQgPSBcIiRcIi5jb25jYXQobW9ja1ByaWNlLnRvRml4ZWQoMikpO1xuICAgICAgICAgICAgcmV0dXJuIF9jb250ZXh0LmFicnVwdChcInJldHVyblwiLCBkYXRhKTtcblxuICAgICAgICAgIGNhc2UgMTM6XG4gICAgICAgICAgICByZXR1cm4gX2NvbnRleHQuYWJydXB0KFwicmV0dXJuXCIsIHJlc3VsdCk7XG5cbiAgICAgICAgICBjYXNlIDE0OlxuICAgICAgICAgIGNhc2UgXCJlbmRcIjpcbiAgICAgICAgICAgIHJldHVybiBfY29udGV4dC5zdG9wKCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9LCBfY2FsbGVlKTtcbiAgfSkpO1xuICByZXR1cm4gX3Byb2R1Y3QuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcbn1cblxuZnVuY3Rpb24gZ2V0UGFnZURhdGEoX3g0KSB7XG4gIHJldHVybiBfZ2V0UGFnZURhdGEuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcbn1cblxuZnVuY3Rpb24gX2dldFBhZ2VEYXRhKCkge1xuICBfZ2V0UGFnZURhdGEgPSAoMCwgX2FzeW5jVG9HZW5lcmF0b3IyW1wiZGVmYXVsdFwiXSkoIC8qI19fUFVSRV9fKi9fcmVnZW5lcmF0b3JbXCJkZWZhdWx0XCJdLm1hcmsoZnVuY3Rpb24gX2NhbGxlZTIoaWQpIHtcbiAgICB2YXIgcmVzdWx0LCBtYWluUHJvZHVjdEltYWdlO1xuICAgIHJldHVybiBfcmVnZW5lcmF0b3JbXCJkZWZhdWx0XCJdLndyYXAoZnVuY3Rpb24gX2NhbGxlZTIkKF9jb250ZXh0Mikge1xuICAgICAgd2hpbGUgKDEpIHtcbiAgICAgICAgc3dpdGNoIChfY29udGV4dDIucHJldiA9IF9jb250ZXh0Mi5uZXh0KSB7XG4gICAgICAgICAgY2FzZSAwOlxuICAgICAgICAgICAgcmVzdWx0ID0ge1xuICAgICAgICAgICAgICB0aXRsZTogXCJQcm9kdWN0IFwiLmNvbmNhdChpZCksXG4gICAgICAgICAgICAgIHByb2R1Y3Q6ICgwLCBfY3JlYXRlUHJvZHVjdFtcImRlZmF1bHRcIl0pKGlkKSxcbiAgICAgICAgICAgICAgYnJlYWRjcnVtYnM6IFt7XG4gICAgICAgICAgICAgICAgdGV4dDogXCJIb21lXCIsXG4gICAgICAgICAgICAgICAgaHJlZjogJy8nXG4gICAgICAgICAgICAgIH0sIHtcbiAgICAgICAgICAgICAgICB0ZXh0OiBcIlN1YmNhdGVnb3J5IFwiLmNvbmNhdChpZCksXG4gICAgICAgICAgICAgICAgYXM6IFwiL3MvXCIuY29uY2F0KGlkKSxcbiAgICAgICAgICAgICAgICBocmVmOiAnL3MvW3N1YmNhdGVnb3J5SWRdJ1xuICAgICAgICAgICAgICB9XVxuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIG1haW5Qcm9kdWN0SW1hZ2UgPSByZXN1bHQucHJvZHVjdC5tZWRpYS5mdWxsWzBdO1xuICAgICAgICAgICAgX2NvbnRleHQyLm5leHQgPSA0O1xuICAgICAgICAgICAgcmV0dXJuICgwLCBfZ2V0QmFzZTY0Rm9ySW1hZ2VbXCJkZWZhdWx0XCJdKShtYWluUHJvZHVjdEltYWdlLnNyYyk7XG5cbiAgICAgICAgICBjYXNlIDQ6XG4gICAgICAgICAgICBtYWluUHJvZHVjdEltYWdlLnNyYyA9IF9jb250ZXh0Mi5zZW50O1xuICAgICAgICAgICAgcmV0dXJuIF9jb250ZXh0Mi5hYnJ1cHQoXCJyZXR1cm5cIiwgcmVzdWx0KTtcblxuICAgICAgICAgIGNhc2UgNjpcbiAgICAgICAgICBjYXNlIFwiZW5kXCI6XG4gICAgICAgICAgICByZXR1cm4gX2NvbnRleHQyLnN0b3AoKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0sIF9jYWxsZWUyKTtcbiAgfSkpO1xuICByZXR1cm4gX2dldFBhZ2VEYXRhLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG59XG4vLyMgc291cmNlTWFwcGluZ1VSTD1wcm9kdWN0LmpzLm1hcCIsIlwidXNlIHN0cmljdFwiO1xuXG52YXIgX2ludGVyb3BSZXF1aXJlRGVmYXVsdCA9IHJlcXVpcmUoXCJAYmFiZWwvcnVudGltZS9oZWxwZXJzL2ludGVyb3BSZXF1aXJlRGVmYXVsdFwiKTtcblxuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7XG4gIHZhbHVlOiB0cnVlXG59KTtcbmV4cG9ydHNbXCJkZWZhdWx0XCJdID0gcHJvZHVjdE1lZGlhO1xuXG52YXIgX3JlZ2VuZXJhdG9yID0gX2ludGVyb3BSZXF1aXJlRGVmYXVsdChyZXF1aXJlKFwiQGJhYmVsL3J1bnRpbWUvcmVnZW5lcmF0b3JcIikpO1xuXG52YXIgX2FzeW5jVG9HZW5lcmF0b3IyID0gX2ludGVyb3BSZXF1aXJlRGVmYXVsdChyZXF1aXJlKFwiQGJhYmVsL3J1bnRpbWUvaGVscGVycy9hc3luY1RvR2VuZXJhdG9yXCIpKTtcblxudmFyIF9jcmVhdGVNZWRpYSA9IF9pbnRlcm9wUmVxdWlyZURlZmF1bHQocmVxdWlyZShcIi4vdXRpbHMvY3JlYXRlTWVkaWFcIikpO1xuXG5mdW5jdGlvbiBwcm9kdWN0TWVkaWEoX3gsIF94MiwgX3gzKSB7XG4gIHJldHVybiBfcHJvZHVjdE1lZGlhLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG59XG5cbmZ1bmN0aW9uIF9wcm9kdWN0TWVkaWEoKSB7XG4gIF9wcm9kdWN0TWVkaWEgPSAoMCwgX2FzeW5jVG9HZW5lcmF0b3IyW1wiZGVmYXVsdFwiXSkoIC8qI19fUFVSRV9fKi9fcmVnZW5lcmF0b3JbXCJkZWZhdWx0XCJdLm1hcmsoZnVuY3Rpb24gX2NhbGxlZShfcmVmLCByZXEsIHJlcykge1xuICAgIHZhciBpZCwgY29sb3I7XG4gICAgcmV0dXJuIF9yZWdlbmVyYXRvcltcImRlZmF1bHRcIl0ud3JhcChmdW5jdGlvbiBfY2FsbGVlJChfY29udGV4dCkge1xuICAgICAgd2hpbGUgKDEpIHtcbiAgICAgICAgc3dpdGNoIChfY29udGV4dC5wcmV2ID0gX2NvbnRleHQubmV4dCkge1xuICAgICAgICAgIGNhc2UgMDpcbiAgICAgICAgICAgIGlkID0gX3JlZi5pZCwgY29sb3IgPSBfcmVmLmNvbG9yO1xuICAgICAgICAgICAgcmV0dXJuIF9jb250ZXh0LmFicnVwdChcInJldHVyblwiLCB7XG4gICAgICAgICAgICAgIG1lZGlhOiAoMCwgX2NyZWF0ZU1lZGlhW1wiZGVmYXVsdFwiXSkoaWQsIGNvbG9yKVxuICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICBjYXNlIDI6XG4gICAgICAgICAgY2FzZSBcImVuZFwiOlxuICAgICAgICAgICAgcmV0dXJuIF9jb250ZXh0LnN0b3AoKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0sIF9jYWxsZWUpO1xuICB9KSk7XG4gIHJldHVybiBfcHJvZHVjdE1lZGlhLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG59XG4vLyMgc291cmNlTWFwcGluZ1VSTD1wcm9kdWN0TWVkaWEuanMubWFwIiwiXCJ1c2Ugc3RyaWN0XCI7XG5cbnZhciBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0ID0gcmVxdWlyZShcIkBiYWJlbC9ydW50aW1lL2hlbHBlcnMvaW50ZXJvcFJlcXVpcmVEZWZhdWx0XCIpO1xuXG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHtcbiAgdmFsdWU6IHRydWVcbn0pO1xuZXhwb3J0c1tcImRlZmF1bHRcIl0gPSBwcm9kdWN0U3VnZ2VzdGlvbnM7XG5cbnZhciBfcmVnZW5lcmF0b3IgPSBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0KHJlcXVpcmUoXCJAYmFiZWwvcnVudGltZS9yZWdlbmVyYXRvclwiKSk7XG5cbnZhciBfYXN5bmNUb0dlbmVyYXRvcjIgPSBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0KHJlcXVpcmUoXCJAYmFiZWwvcnVudGltZS9oZWxwZXJzL2FzeW5jVG9HZW5lcmF0b3JcIikpO1xuXG52YXIgX2NyZWF0ZVByb2R1Y3QgPSBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0KHJlcXVpcmUoXCIuL3V0aWxzL2NyZWF0ZVByb2R1Y3RcIikpO1xuXG4vKipcbiAqIEFuIGV4YW1wbGUgZW5kcG9pbnQgdGhhdCByZXR1cm5zIG1vY2sgcHJvZHVjdCBzdWdnZXN0aW9ucyBmb3IgYSBQRFAuXG4gKiBAcGFyYW0geyp9IHJlcVxuICogQHBhcmFtIHsqfSByZXNcbiAqL1xuZnVuY3Rpb24gcHJvZHVjdFN1Z2dlc3Rpb25zKF94LCBfeDIpIHtcbiAgcmV0dXJuIF9wcm9kdWN0U3VnZ2VzdGlvbnMuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcbn1cblxuZnVuY3Rpb24gX3Byb2R1Y3RTdWdnZXN0aW9ucygpIHtcbiAgX3Byb2R1Y3RTdWdnZXN0aW9ucyA9ICgwLCBfYXN5bmNUb0dlbmVyYXRvcjJbXCJkZWZhdWx0XCJdKSggLyojX19QVVJFX18qL19yZWdlbmVyYXRvcltcImRlZmF1bHRcIl0ubWFyayhmdW5jdGlvbiBfY2FsbGVlKHJlcSwgcmVzKSB7XG4gICAgdmFyIHByb2R1Y3RzLCBpO1xuICAgIHJldHVybiBfcmVnZW5lcmF0b3JbXCJkZWZhdWx0XCJdLndyYXAoZnVuY3Rpb24gX2NhbGxlZSQoX2NvbnRleHQpIHtcbiAgICAgIHdoaWxlICgxKSB7XG4gICAgICAgIHN3aXRjaCAoX2NvbnRleHQucHJldiA9IF9jb250ZXh0Lm5leHQpIHtcbiAgICAgICAgICBjYXNlIDA6XG4gICAgICAgICAgICBwcm9kdWN0cyA9IFtdO1xuXG4gICAgICAgICAgICBmb3IgKGkgPSAxOyBpIDw9IDEwOyBpKyspIHtcbiAgICAgICAgICAgICAgcHJvZHVjdHMucHVzaCgoMCwgX2NyZWF0ZVByb2R1Y3RbXCJkZWZhdWx0XCJdKShpKSk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHJldHVybiBfY29udGV4dC5hYnJ1cHQoXCJyZXR1cm5cIiwgcHJvZHVjdHMpO1xuXG4gICAgICAgICAgY2FzZSAzOlxuICAgICAgICAgIGNhc2UgXCJlbmRcIjpcbiAgICAgICAgICAgIHJldHVybiBfY29udGV4dC5zdG9wKCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9LCBfY2FsbGVlKTtcbiAgfSkpO1xuICByZXR1cm4gX3Byb2R1Y3RTdWdnZXN0aW9ucy5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xufVxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cHJvZHVjdFN1Z2dlc3Rpb25zLmpzLm1hcCIsIlwidXNlIHN0cmljdFwiO1xuXG52YXIgX2ludGVyb3BSZXF1aXJlRGVmYXVsdCA9IHJlcXVpcmUoXCJAYmFiZWwvcnVudGltZS9oZWxwZXJzL2ludGVyb3BSZXF1aXJlRGVmYXVsdFwiKTtcblxuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7XG4gIHZhbHVlOiB0cnVlXG59KTtcbmV4cG9ydHNbXCJkZWZhdWx0XCJdID0gcmVtb3ZlQ2FydEl0ZW07XG5cbnZhciBfcmVnZW5lcmF0b3IgPSBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0KHJlcXVpcmUoXCJAYmFiZWwvcnVudGltZS9yZWdlbmVyYXRvclwiKSk7XG5cbnZhciBfYXN5bmNUb0dlbmVyYXRvcjIgPSBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0KHJlcXVpcmUoXCJAYmFiZWwvcnVudGltZS9oZWxwZXJzL2FzeW5jVG9HZW5lcmF0b3JcIikpO1xuXG52YXIgX2NhcnRTdG9yZSA9IHJlcXVpcmUoXCIuL3V0aWxzL2NhcnRTdG9yZVwiKTtcblxuZnVuY3Rpb24gcmVtb3ZlQ2FydEl0ZW0oX3gsIF94MiwgX3gzKSB7XG4gIHJldHVybiBfcmVtb3ZlQ2FydEl0ZW0uYXBwbHkodGhpcywgYXJndW1lbnRzKTtcbn1cblxuZnVuY3Rpb24gX3JlbW92ZUNhcnRJdGVtKCkge1xuICBfcmVtb3ZlQ2FydEl0ZW0gPSAoMCwgX2FzeW5jVG9HZW5lcmF0b3IyW1wiZGVmYXVsdFwiXSkoIC8qI19fUFVSRV9fKi9fcmVnZW5lcmF0b3JbXCJkZWZhdWx0XCJdLm1hcmsoZnVuY3Rpb24gX2NhbGxlZShpdGVtLCByZXEsIHJlcykge1xuICAgIHJldHVybiBfcmVnZW5lcmF0b3JbXCJkZWZhdWx0XCJdLndyYXAoZnVuY3Rpb24gX2NhbGxlZSQoX2NvbnRleHQpIHtcbiAgICAgIHdoaWxlICgxKSB7XG4gICAgICAgIHN3aXRjaCAoX2NvbnRleHQucHJldiA9IF9jb250ZXh0Lm5leHQpIHtcbiAgICAgICAgICBjYXNlIDA6XG4gICAgICAgICAgICByZXR1cm4gX2NvbnRleHQuYWJydXB0KFwicmV0dXJuXCIsIHtcbiAgICAgICAgICAgICAgY2FydDoge1xuICAgICAgICAgICAgICAgIGl0ZW1zOiAoMCwgX2NhcnRTdG9yZS5yZW1vdmVJdGVtKShpdGVtLmlkLCByZXEsIHJlcylcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICBjYXNlIDE6XG4gICAgICAgICAgY2FzZSBcImVuZFwiOlxuICAgICAgICAgICAgcmV0dXJuIF9jb250ZXh0LnN0b3AoKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0sIF9jYWxsZWUpO1xuICB9KSk7XG4gIHJldHVybiBfcmVtb3ZlQ2FydEl0ZW0uYXBwbHkodGhpcywgYXJndW1lbnRzKTtcbn1cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXJlbW92ZUNhcnRJdGVtLmpzLm1hcCIsIlwidXNlIHN0cmljdFwiO1xuXG52YXIgX2ludGVyb3BSZXF1aXJlRGVmYXVsdCA9IHJlcXVpcmUoXCJAYmFiZWwvcnVudGltZS9oZWxwZXJzL2ludGVyb3BSZXF1aXJlRGVmYXVsdFwiKTtcblxuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7XG4gIHZhbHVlOiB0cnVlXG59KTtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcImRlZmF1bHRcIiwge1xuICBlbnVtZXJhYmxlOiB0cnVlLFxuICBnZXQ6IGZ1bmN0aW9uIGdldCgpIHtcbiAgICByZXR1cm4gX3N1YmNhdGVnb3J5W1wiZGVmYXVsdFwiXTtcbiAgfVxufSk7XG5cbnZhciBfc3ViY2F0ZWdvcnkgPSBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0KHJlcXVpcmUoXCIuL3N1YmNhdGVnb3J5XCIpKTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXNlYXJjaC5qcy5tYXAiLCJcInVzZSBzdHJpY3RcIjtcblxudmFyIF9pbnRlcm9wUmVxdWlyZURlZmF1bHQgPSByZXF1aXJlKFwiQGJhYmVsL3J1bnRpbWUvaGVscGVycy9pbnRlcm9wUmVxdWlyZURlZmF1bHRcIik7XG5cbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwge1xuICB2YWx1ZTogdHJ1ZVxufSk7XG5leHBvcnRzW1wiZGVmYXVsdFwiXSA9IHNlYXJjaFN1Z2dlc3Rpb25zO1xuXG52YXIgX3JlZ2VuZXJhdG9yID0gX2ludGVyb3BSZXF1aXJlRGVmYXVsdChyZXF1aXJlKFwiQGJhYmVsL3J1bnRpbWUvcmVnZW5lcmF0b3JcIikpO1xuXG52YXIgX2FzeW5jVG9HZW5lcmF0b3IyID0gX2ludGVyb3BSZXF1aXJlRGVmYXVsdChyZXF1aXJlKFwiQGJhYmVsL3J1bnRpbWUvaGVscGVycy9hc3luY1RvR2VuZXJhdG9yXCIpKTtcblxuLyoqXG4gKiBBbiBleGFtcGxlIGltcGxlbWVudGF0aW9uIG9mIHRoZSBBUEkgZm9yIHRoZSBTZWFyY2hQb3B1cCBjb21wb25lbnQgdXNpbmcgcGxhY2Vob2xkZXIgZGF0YS5cbiAqIEBwYXJhbSB7T2JqZWN0fSBwYXJhbXNcbiAqIEBwYXJhbSB7U3RyaW5nfSBwYXJhbXMucSBUaGUgc2VhcmNoIHRleHRcbiAqIEByZXR1cm4ge09iamVjdH0gQW4gb2JqZWN0IHdob3NlIHNoYXBlIG1hdGNoZXMgQXBwTW9kZWxCYXNlXG4gKi9cbmZ1bmN0aW9uIHNlYXJjaFN1Z2dlc3Rpb25zKF94LCBfeDIsIF94Mykge1xuICByZXR1cm4gX3NlYXJjaFN1Z2dlc3Rpb25zLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG59XG5cbmZ1bmN0aW9uIF9zZWFyY2hTdWdnZXN0aW9ucygpIHtcbiAgX3NlYXJjaFN1Z2dlc3Rpb25zID0gKDAsIF9hc3luY1RvR2VuZXJhdG9yMltcImRlZmF1bHRcIl0pKCAvKiNfX1BVUkVfXyovX3JlZ2VuZXJhdG9yW1wiZGVmYXVsdFwiXS5tYXJrKGZ1bmN0aW9uIF9jYWxsZWUocSwgcmVxLCByZXMpIHtcbiAgICByZXR1cm4gX3JlZ2VuZXJhdG9yW1wiZGVmYXVsdFwiXS53cmFwKGZ1bmN0aW9uIF9jYWxsZWUkKF9jb250ZXh0KSB7XG4gICAgICB3aGlsZSAoMSkge1xuICAgICAgICBzd2l0Y2ggKF9jb250ZXh0LnByZXYgPSBfY29udGV4dC5uZXh0KSB7XG4gICAgICAgICAgY2FzZSAwOlxuICAgICAgICAgICAgcmV0dXJuIF9jb250ZXh0LmFicnVwdChcInJldHVyblwiLCB7XG4gICAgICAgICAgICAgIHRleHQ6IHEsXG4gICAgICAgICAgICAgIGdyb3VwczogW3tcbiAgICAgICAgICAgICAgICBjYXB0aW9uOiAnU3VnZ2VzdGVkIFNlYXJjaGVzJyxcbiAgICAgICAgICAgICAgICB1aTogJ2xpc3QnLFxuICAgICAgICAgICAgICAgIGxpbmtzOiBbXCJTbWFsbCBcIi5jb25jYXQocSksIFwiTGFyZ2UgXCIuY29uY2F0KHEpLCBcIlwiLmNvbmNhdChxLCBcIiB3aXRoIHJlZCBzdHJpcGVzXCIpXS5tYXAoZnVuY3Rpb24gKHRleHQpIHtcbiAgICAgICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgICAgIHRleHQ6IHRleHQsXG4gICAgICAgICAgICAgICAgICAgIGFzOiBcIi9zZWFyY2g/cT1cIi5jb25jYXQoZW5jb2RlVVJJQ29tcG9uZW50KHRleHQpKSxcbiAgICAgICAgICAgICAgICAgICAgaHJlZjogJy9zZWFyY2gnXG4gICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgIH0sIHtcbiAgICAgICAgICAgICAgICBjYXB0aW9uOiAnU3VnZ2VzdGVkIENhdGVnb3JpZXMnLFxuICAgICAgICAgICAgICAgIHVpOiAnbGlzdCcsXG4gICAgICAgICAgICAgICAgbGlua3M6IFt7XG4gICAgICAgICAgICAgICAgICB0ZXh0OiAnQ2F0ZWdvcnkgMScsXG4gICAgICAgICAgICAgICAgICBocmVmOiAnL3MvW3N1YmNhdGVnb3J5SWRdJyxcbiAgICAgICAgICAgICAgICAgIGFzOiAnL3MvMSdcbiAgICAgICAgICAgICAgICB9LCB7XG4gICAgICAgICAgICAgICAgICB0ZXh0OiAnQ2F0ZWdvcnkgMicsXG4gICAgICAgICAgICAgICAgICBocmVmOiAnL3MvW3N1YmNhdGVnb3J5SWRdJyxcbiAgICAgICAgICAgICAgICAgIGFzOiAnL3MvMidcbiAgICAgICAgICAgICAgICB9LCB7XG4gICAgICAgICAgICAgICAgICB0ZXh0OiAnQ2F0ZWdvcnkgMycsXG4gICAgICAgICAgICAgICAgICBocmVmOiAnL3MvW3N1YmNhdGVnb3J5SWRdJyxcbiAgICAgICAgICAgICAgICAgIGFzOiAnL3MvMydcbiAgICAgICAgICAgICAgICB9XVxuICAgICAgICAgICAgICB9LCB7XG4gICAgICAgICAgICAgICAgY2FwdGlvbjogJ1N1Z2dlc3RlZCBQcm9kdWN0cycsXG4gICAgICAgICAgICAgICAgdWk6ICd0aHVtYm5haWxzJyxcbiAgICAgICAgICAgICAgICBsaW5rczogW3tcbiAgICAgICAgICAgICAgICAgIHRleHQ6ICdQcm9kdWN0IDEnLFxuICAgICAgICAgICAgICAgICAgaHJlZjogJy9wL1twcm9kdWN0SWRdJyxcbiAgICAgICAgICAgICAgICAgIGFzOiAnL3AvMT9zPTEmYz0xJyxcbiAgICAgICAgICAgICAgICAgIHRodW1ibmFpbDoge1xuICAgICAgICAgICAgICAgICAgICBzcmM6ICdodHRwczovL2R1bW15aW1hZ2UuY29tLzEyMHgxMjAnLFxuICAgICAgICAgICAgICAgICAgICBhbHQ6ICdQcm9kdWN0IDEnXG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSwge1xuICAgICAgICAgICAgICAgICAgdGV4dDogJ1Byb2R1Y3QgMicsXG4gICAgICAgICAgICAgICAgICBocmVmOiAnL3AvW3Byb2R1Y3RJZF0nLFxuICAgICAgICAgICAgICAgICAgYXM6ICcvcC8yP3M9MSZjPTEnLFxuICAgICAgICAgICAgICAgICAgdGh1bWJuYWlsOiB7XG4gICAgICAgICAgICAgICAgICAgIHNyYzogJ2h0dHBzOi8vZHVtbXlpbWFnZS5jb20vMTIweDEyMCcsXG4gICAgICAgICAgICAgICAgICAgIGFsdDogJ1Byb2R1Y3QgMSdcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9LCB7XG4gICAgICAgICAgICAgICAgICB0ZXh0OiAnUHJvZHVjdCAzJyxcbiAgICAgICAgICAgICAgICAgIGhyZWY6ICcvcC9bcHJvZHVjdElkXScsXG4gICAgICAgICAgICAgICAgICBhczogJy9wLzM/cz0xJmM9MScsXG4gICAgICAgICAgICAgICAgICB0aHVtYm5haWw6IHtcbiAgICAgICAgICAgICAgICAgICAgc3JjOiAnaHR0cHM6Ly9kdW1teWltYWdlLmNvbS8xMjB4MTIwJyxcbiAgICAgICAgICAgICAgICAgICAgYWx0OiAnUHJvZHVjdCAxJ1xuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0sIHtcbiAgICAgICAgICAgICAgICAgIHRleHQ6ICdQcm9kdWN0IDQnLFxuICAgICAgICAgICAgICAgICAgaHJlZjogJy9wL1twcm9kdWN0SWRdJyxcbiAgICAgICAgICAgICAgICAgIGFzOiAnL3AvMz9zPTEmYz0xJyxcbiAgICAgICAgICAgICAgICAgIHRodW1ibmFpbDoge1xuICAgICAgICAgICAgICAgICAgICBzcmM6ICdodHRwczovL2R1bW15aW1hZ2UuY29tLzEyMHgxMjAnLFxuICAgICAgICAgICAgICAgICAgICBhbHQ6ICdQcm9kdWN0IDEnXG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSwge1xuICAgICAgICAgICAgICAgICAgdGV4dDogJ1Byb2R1Y3QgNScsXG4gICAgICAgICAgICAgICAgICBocmVmOiAnL3AvW3Byb2R1Y3RJZF0nLFxuICAgICAgICAgICAgICAgICAgYXM6ICcvcC81P3M9MSZjPTEnLFxuICAgICAgICAgICAgICAgICAgdGh1bWJuYWlsOiB7XG4gICAgICAgICAgICAgICAgICAgIHNyYzogJ2h0dHBzOi8vZHVtbXlpbWFnZS5jb20vMTIweDEyMCcsXG4gICAgICAgICAgICAgICAgICAgIGFsdDogJ1Byb2R1Y3QgMSdcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XVxuICAgICAgICAgICAgICB9XVxuICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICBjYXNlIDE6XG4gICAgICAgICAgY2FzZSBcImVuZFwiOlxuICAgICAgICAgICAgcmV0dXJuIF9jb250ZXh0LnN0b3AoKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0sIF9jYWxsZWUpO1xuICB9KSk7XG4gIHJldHVybiBfc2VhcmNoU3VnZ2VzdGlvbnMuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcbn1cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXNlYXJjaFN1Z2dlc3Rpb25zLmpzLm1hcCIsIlwidXNlIHN0cmljdFwiO1xuXG52YXIgX2ludGVyb3BSZXF1aXJlRGVmYXVsdCA9IHJlcXVpcmUoXCJAYmFiZWwvcnVudGltZS9oZWxwZXJzL2ludGVyb3BSZXF1aXJlRGVmYXVsdFwiKTtcblxuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7XG4gIHZhbHVlOiB0cnVlXG59KTtcbmV4cG9ydHNbXCJkZWZhdWx0XCJdID0gc2Vzc2lvbjtcblxudmFyIF9yZWdlbmVyYXRvciA9IF9pbnRlcm9wUmVxdWlyZURlZmF1bHQocmVxdWlyZShcIkBiYWJlbC9ydW50aW1lL3JlZ2VuZXJhdG9yXCIpKTtcblxudmFyIF9hc3luY1RvR2VuZXJhdG9yMiA9IF9pbnRlcm9wUmVxdWlyZURlZmF1bHQocmVxdWlyZShcIkBiYWJlbC9ydW50aW1lL2hlbHBlcnMvYXN5bmNUb0dlbmVyYXRvclwiKSk7XG5cbnZhciBfY2FydFN0b3JlID0gcmVxdWlyZShcIi4vdXRpbHMvY2FydFN0b3JlXCIpO1xuXG5mdW5jdGlvbiBzZXNzaW9uKF94LCBfeDIpIHtcbiAgcmV0dXJuIF9zZXNzaW9uLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG59XG5cbmZ1bmN0aW9uIF9zZXNzaW9uKCkge1xuICBfc2Vzc2lvbiA9ICgwLCBfYXN5bmNUb0dlbmVyYXRvcjJbXCJkZWZhdWx0XCJdKSggLyojX19QVVJFX18qL19yZWdlbmVyYXRvcltcImRlZmF1bHRcIl0ubWFyayhmdW5jdGlvbiBfY2FsbGVlKHJlcSwgcmVzKSB7XG4gICAgcmV0dXJuIF9yZWdlbmVyYXRvcltcImRlZmF1bHRcIl0ud3JhcChmdW5jdGlvbiBfY2FsbGVlJChfY29udGV4dCkge1xuICAgICAgd2hpbGUgKDEpIHtcbiAgICAgICAgc3dpdGNoIChfY29udGV4dC5wcmV2ID0gX2NvbnRleHQubmV4dCkge1xuICAgICAgICAgIGNhc2UgMDpcbiAgICAgICAgICAgIHJldHVybiBfY29udGV4dC5hYnJ1cHQoXCJyZXR1cm5cIiwge1xuICAgICAgICAgICAgICBuYW1lOiAnTWFyaycsXG4gICAgICAgICAgICAgIGVtYWlsOiAnbWFya0Bkb21haW4uY29tJyxcbiAgICAgICAgICAgICAgY2FydDoge1xuICAgICAgICAgICAgICAgIGl0ZW1zOiAoMCwgX2NhcnRTdG9yZS5nZXRQcm9kdWN0cykocmVxLCByZXMpXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIGN1cnJlbmN5OiAnVVNEJ1xuICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICBjYXNlIDE6XG4gICAgICAgICAgY2FzZSBcImVuZFwiOlxuICAgICAgICAgICAgcmV0dXJuIF9jb250ZXh0LnN0b3AoKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0sIF9jYWxsZWUpO1xuICB9KSk7XG4gIHJldHVybiBfc2Vzc2lvbi5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xufVxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9c2Vzc2lvbi5qcy5tYXAiLCJcInVzZSBzdHJpY3RcIjtcblxudmFyIF9pbnRlcm9wUmVxdWlyZVdpbGRjYXJkID0gcmVxdWlyZShcIkBiYWJlbC9ydW50aW1lL2hlbHBlcnMvaW50ZXJvcFJlcXVpcmVXaWxkY2FyZFwiKTtcblxudmFyIF9pbnRlcm9wUmVxdWlyZURlZmF1bHQgPSByZXF1aXJlKFwiQGJhYmVsL3J1bnRpbWUvaGVscGVycy9pbnRlcm9wUmVxdWlyZURlZmF1bHRcIik7XG5cbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwge1xuICB2YWx1ZTogdHJ1ZVxufSk7XG5leHBvcnRzW1wiZGVmYXVsdFwiXSA9IHN1YmNhdGVnb3J5O1xuXG52YXIgX3JlZ2VuZXJhdG9yID0gX2ludGVyb3BSZXF1aXJlRGVmYXVsdChyZXF1aXJlKFwiQGJhYmVsL3J1bnRpbWUvcmVnZW5lcmF0b3JcIikpO1xuXG52YXIgX3RvQ29uc3VtYWJsZUFycmF5MiA9IF9pbnRlcm9wUmVxdWlyZURlZmF1bHQocmVxdWlyZShcIkBiYWJlbC9ydW50aW1lL2hlbHBlcnMvdG9Db25zdW1hYmxlQXJyYXlcIikpO1xuXG52YXIgX2FzeW5jVG9HZW5lcmF0b3IyID0gX2ludGVyb3BSZXF1aXJlRGVmYXVsdChyZXF1aXJlKFwiQGJhYmVsL3J1bnRpbWUvaGVscGVycy9hc3luY1RvR2VuZXJhdG9yXCIpKTtcblxudmFyIF9jcmVhdGVGYWNldHMgPSBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0KHJlcXVpcmUoXCIuL3V0aWxzL2NyZWF0ZUZhY2V0c1wiKSk7XG5cbnZhciBfY3JlYXRlU29ydE9wdGlvbnMgPSBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0KHJlcXVpcmUoXCIuL3V0aWxzL2NyZWF0ZVNvcnRPcHRpb25zXCIpKTtcblxudmFyIF9jcmVhdGVQcm9kdWN0ID0gX2ludGVyb3BSZXF1aXJlRGVmYXVsdChyZXF1aXJlKFwiLi91dGlscy9jcmVhdGVQcm9kdWN0XCIpKTtcblxudmFyIF9jb2xvcnMgPSBfaW50ZXJvcFJlcXVpcmVXaWxkY2FyZChyZXF1aXJlKFwiLi91dGlscy9jb2xvcnNcIikpO1xuXG52YXIgX2Z1bGZpbGxBUElSZXF1ZXN0ID0gX2ludGVyb3BSZXF1aXJlRGVmYXVsdChyZXF1aXJlKFwicmVhY3Qtc3RvcmVmcm9udC9wcm9wcy9mdWxmaWxsQVBJUmVxdWVzdFwiKSk7XG5cbnZhciBfY3JlYXRlQXBwRGF0YSA9IF9pbnRlcm9wUmVxdWlyZURlZmF1bHQocmVxdWlyZShcIi4vdXRpbHMvY3JlYXRlQXBwRGF0YVwiKSk7XG5cbmZ1bmN0aW9uIF9jcmVhdGVGb3JPZkl0ZXJhdG9ySGVscGVyKG8sIGFsbG93QXJyYXlMaWtlKSB7IHZhciBpdDsgaWYgKHR5cGVvZiBTeW1ib2wgPT09IFwidW5kZWZpbmVkXCIgfHwgb1tTeW1ib2wuaXRlcmF0b3JdID09IG51bGwpIHsgaWYgKEFycmF5LmlzQXJyYXkobykgfHwgKGl0ID0gX3Vuc3VwcG9ydGVkSXRlcmFibGVUb0FycmF5KG8pKSB8fCBhbGxvd0FycmF5TGlrZSAmJiBvICYmIHR5cGVvZiBvLmxlbmd0aCA9PT0gXCJudW1iZXJcIikgeyBpZiAoaXQpIG8gPSBpdDsgdmFyIGkgPSAwOyB2YXIgRiA9IGZ1bmN0aW9uIEYoKSB7fTsgcmV0dXJuIHsgczogRiwgbjogZnVuY3Rpb24gbigpIHsgaWYgKGkgPj0gby5sZW5ndGgpIHJldHVybiB7IGRvbmU6IHRydWUgfTsgcmV0dXJuIHsgZG9uZTogZmFsc2UsIHZhbHVlOiBvW2krK10gfTsgfSwgZTogZnVuY3Rpb24gZShfZSkgeyB0aHJvdyBfZTsgfSwgZjogRiB9OyB9IHRocm93IG5ldyBUeXBlRXJyb3IoXCJJbnZhbGlkIGF0dGVtcHQgdG8gaXRlcmF0ZSBub24taXRlcmFibGUgaW5zdGFuY2UuXFxuSW4gb3JkZXIgdG8gYmUgaXRlcmFibGUsIG5vbi1hcnJheSBvYmplY3RzIG11c3QgaGF2ZSBhIFtTeW1ib2wuaXRlcmF0b3JdKCkgbWV0aG9kLlwiKTsgfSB2YXIgbm9ybWFsQ29tcGxldGlvbiA9IHRydWUsIGRpZEVyciA9IGZhbHNlLCBlcnI7IHJldHVybiB7IHM6IGZ1bmN0aW9uIHMoKSB7IGl0ID0gb1tTeW1ib2wuaXRlcmF0b3JdKCk7IH0sIG46IGZ1bmN0aW9uIG4oKSB7IHZhciBzdGVwID0gaXQubmV4dCgpOyBub3JtYWxDb21wbGV0aW9uID0gc3RlcC5kb25lOyByZXR1cm4gc3RlcDsgfSwgZTogZnVuY3Rpb24gZShfZTIpIHsgZGlkRXJyID0gdHJ1ZTsgZXJyID0gX2UyOyB9LCBmOiBmdW5jdGlvbiBmKCkgeyB0cnkgeyBpZiAoIW5vcm1hbENvbXBsZXRpb24gJiYgaXRbXCJyZXR1cm5cIl0gIT0gbnVsbCkgaXRbXCJyZXR1cm5cIl0oKTsgfSBmaW5hbGx5IHsgaWYgKGRpZEVycikgdGhyb3cgZXJyOyB9IH0gfTsgfVxuXG5mdW5jdGlvbiBfdW5zdXBwb3J0ZWRJdGVyYWJsZVRvQXJyYXkobywgbWluTGVuKSB7IGlmICghbykgcmV0dXJuOyBpZiAodHlwZW9mIG8gPT09IFwic3RyaW5nXCIpIHJldHVybiBfYXJyYXlMaWtlVG9BcnJheShvLCBtaW5MZW4pOyB2YXIgbiA9IE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmcuY2FsbChvKS5zbGljZSg4LCAtMSk7IGlmIChuID09PSBcIk9iamVjdFwiICYmIG8uY29uc3RydWN0b3IpIG4gPSBvLmNvbnN0cnVjdG9yLm5hbWU7IGlmIChuID09PSBcIk1hcFwiIHx8IG4gPT09IFwiU2V0XCIpIHJldHVybiBBcnJheS5mcm9tKG8pOyBpZiAobiA9PT0gXCJBcmd1bWVudHNcIiB8fCAvXig/OlVpfEkpbnQoPzo4fDE2fDMyKSg/OkNsYW1wZWQpP0FycmF5JC8udGVzdChuKSkgcmV0dXJuIF9hcnJheUxpa2VUb0FycmF5KG8sIG1pbkxlbik7IH1cblxuZnVuY3Rpb24gX2FycmF5TGlrZVRvQXJyYXkoYXJyLCBsZW4pIHsgaWYgKGxlbiA9PSBudWxsIHx8IGxlbiA+IGFyci5sZW5ndGgpIGxlbiA9IGFyci5sZW5ndGg7IGZvciAodmFyIGkgPSAwLCBhcnIyID0gbmV3IEFycmF5KGxlbik7IGkgPCBsZW47IGkrKykgeyBhcnIyW2ldID0gYXJyW2ldOyB9IHJldHVybiBhcnIyOyB9XG5cbmZ1bmN0aW9uIHN1YmNhdGVnb3J5KF94LCBfeDIsIF94Mykge1xuICByZXR1cm4gX3N1YmNhdGVnb3J5LmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG59XG5cbmZ1bmN0aW9uIF9zdWJjYXRlZ29yeSgpIHtcbiAgX3N1YmNhdGVnb3J5ID0gKDAsIF9hc3luY1RvR2VuZXJhdG9yMltcImRlZmF1bHRcIl0pKCAvKiNfX1BVUkVfXyovX3JlZ2VuZXJhdG9yW1wiZGVmYXVsdFwiXS5tYXJrKGZ1bmN0aW9uIF9jYWxsZWUocGFyYW1zLCByZXEsIHJlcykge1xuICAgIHZhciBxLCBfcGFyYW1zJHNsdWcsIHNsdWcsIF9wYXJhbXMkcGFnZSwgcGFnZSwgZmlsdGVycywgc29ydCwgX3BhcmFtcyRtb3JlLCBtb3JlO1xuXG4gICAgcmV0dXJuIF9yZWdlbmVyYXRvcltcImRlZmF1bHRcIl0ud3JhcChmdW5jdGlvbiBfY2FsbGVlJChfY29udGV4dCkge1xuICAgICAgd2hpbGUgKDEpIHtcbiAgICAgICAgc3dpdGNoIChfY29udGV4dC5wcmV2ID0gX2NvbnRleHQubmV4dCkge1xuICAgICAgICAgIGNhc2UgMDpcbiAgICAgICAgICAgIHEgPSBwYXJhbXMucSwgX3BhcmFtcyRzbHVnID0gcGFyYW1zLnNsdWcsIHNsdWcgPSBfcGFyYW1zJHNsdWcgPT09IHZvaWQgMCA/ICcxJyA6IF9wYXJhbXMkc2x1ZywgX3BhcmFtcyRwYWdlID0gcGFyYW1zLnBhZ2UsIHBhZ2UgPSBfcGFyYW1zJHBhZ2UgPT09IHZvaWQgMCA/IDAgOiBfcGFyYW1zJHBhZ2UsIGZpbHRlcnMgPSBwYXJhbXMuZmlsdGVycywgc29ydCA9IHBhcmFtcy5zb3J0LCBfcGFyYW1zJG1vcmUgPSBwYXJhbXMubW9yZSwgbW9yZSA9IF9wYXJhbXMkbW9yZSA9PT0gdm9pZCAwID8gZmFsc2UgOiBfcGFyYW1zJG1vcmU7XG5cbiAgICAgICAgICAgIGlmIChmaWx0ZXJzKSB7XG4gICAgICAgICAgICAgIGZpbHRlcnMgPSBKU09OLnBhcnNlKGZpbHRlcnMpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgZmlsdGVycyA9IFtdO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBfY29udGV4dC5uZXh0ID0gNDtcbiAgICAgICAgICAgIHJldHVybiAoMCwgX2Z1bGZpbGxBUElSZXF1ZXN0W1wiZGVmYXVsdFwiXSkocmVxLCB7XG4gICAgICAgICAgICAgIGFwcERhdGE6IF9jcmVhdGVBcHBEYXRhW1wiZGVmYXVsdFwiXSxcbiAgICAgICAgICAgICAgcGFnZURhdGE6IGZ1bmN0aW9uIHBhZ2VEYXRhKCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoe1xuICAgICAgICAgICAgICAgICAgaWQ6IHNsdWcsXG4gICAgICAgICAgICAgICAgICBuYW1lOiBxICE9IG51bGwgPyBcIlJlc3VsdHMgZm9yIFxcXCJcIi5jb25jYXQocSwgXCJcXFwiXCIpIDogXCJTdWJjYXRlZ29yeSBcIi5jb25jYXQoc2x1ZyksXG4gICAgICAgICAgICAgICAgICB0aXRsZTogcSAhPSBudWxsID8gXCJSZXN1bHRzIGZvciBcXFwiXCIuY29uY2F0KHEsIFwiXFxcIlwiKSA6IFwiU3ViY2F0ZWdvcnkgXCIuY29uY2F0KHNsdWcpLFxuICAgICAgICAgICAgICAgICAgdG90YWw6IDEwMCxcbiAgICAgICAgICAgICAgICAgIHBhZ2U6IHBhcnNlSW50KHBhZ2UpLFxuICAgICAgICAgICAgICAgICAgdG90YWxQYWdlczogNSxcbiAgICAgICAgICAgICAgICAgIGZpbHRlcnM6IGZpbHRlcnMsXG4gICAgICAgICAgICAgICAgICBzb3J0OiBzb3J0LFxuICAgICAgICAgICAgICAgICAgc29ydE9wdGlvbnM6ICgwLCBfY3JlYXRlU29ydE9wdGlvbnNbXCJkZWZhdWx0XCJdKSgpLFxuICAgICAgICAgICAgICAgICAgZmFjZXRzOiAoMCwgX2NyZWF0ZUZhY2V0c1tcImRlZmF1bHRcIl0pKCksXG4gICAgICAgICAgICAgICAgICBwcm9kdWN0czogZmlsdGVyUHJvZHVjdHMocGFnZSwgZmlsdGVycywgbW9yZSksXG4gICAgICAgICAgICAgICAgICBicmVhZGNydW1iczogW3tcbiAgICAgICAgICAgICAgICAgICAgdGV4dDogXCJIb21lXCIsXG4gICAgICAgICAgICAgICAgICAgIGhyZWY6ICcvJ1xuICAgICAgICAgICAgICAgICAgfV1cbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICBjYXNlIDQ6XG4gICAgICAgICAgICByZXR1cm4gX2NvbnRleHQuYWJydXB0KFwicmV0dXJuXCIsIF9jb250ZXh0LnNlbnQpO1xuXG4gICAgICAgICAgY2FzZSA1OlxuICAgICAgICAgIGNhc2UgXCJlbmRcIjpcbiAgICAgICAgICAgIHJldHVybiBfY29udGV4dC5zdG9wKCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9LCBfY2FsbGVlKTtcbiAgfSkpO1xuICByZXR1cm4gX3N1YmNhdGVnb3J5LmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG59XG5cbmZ1bmN0aW9uIGZpbHRlclByb2R1Y3RzKHBhZ2UsIGZpbHRlcnMsIG1vcmUpIHtcbiAgdmFyIHByb2R1Y3RzID0gW107XG4gIHZhciBmaWx0ZXJlZENvbG9ycyA9IGZpbHRlcnMgPyBmaWx0ZXJzLmZpbHRlcihmdW5jdGlvbiAoZikge1xuICAgIHJldHVybiBmLnN0YXJ0c1dpdGgoJ2NvbG9yJyk7XG4gIH0pLm1hcChmdW5jdGlvbiAoZikge1xuICAgIHJldHVybiBmLnJlcGxhY2UoL15jb2xvcjovLCAnJyk7XG4gIH0pIDogW107XG4gIHZhciBjb3VudCA9IG1vcmUgPyAyMCA6IDEwO1xuXG4gIHdoaWxlIChwcm9kdWN0cy5sZW5ndGggPCBjb3VudCkge1xuICAgIGlmIChmaWx0ZXJlZENvbG9ycyAmJiBmaWx0ZXJlZENvbG9ycy5sZW5ndGgpIHtcbiAgICAgIHZhciBfaXRlcmF0b3IgPSBfY3JlYXRlRm9yT2ZJdGVyYXRvckhlbHBlcihmaWx0ZXJlZENvbG9ycyksXG4gICAgICAgICAgX3N0ZXA7XG5cbiAgICAgIHRyeSB7XG4gICAgICAgIHZhciBfbG9vcCA9IGZ1bmN0aW9uIF9sb29wKCkge1xuICAgICAgICAgIHZhciBjb2xvciA9IF9zdGVwLnZhbHVlO1xuICAgICAgICAgIHZhciBpbmRleCA9ICgwLCBfY29sb3JzLmluZGV4Rm9yQ29sb3IpKGNvbG9yKTtcblxuICAgICAgICAgIHZhciBjb2xvckdhcCA9IGZ1bmN0aW9uIGNvbG9yR2FwKGkpIHtcbiAgICAgICAgICAgIHJldHVybiBNYXRoLmZsb29yKHBhZ2UgKiBjb3VudCAvIGZpbHRlcmVkQ29sb3JzLmxlbmd0aCkgKyBpO1xuICAgICAgICAgIH07XG5cbiAgICAgICAgICBwcm9kdWN0cy5wdXNoLmFwcGx5KHByb2R1Y3RzLCAoMCwgX3RvQ29uc3VtYWJsZUFycmF5MltcImRlZmF1bHRcIl0pKEFycmF5LmZyb20oe1xuICAgICAgICAgICAgbGVuZ3RoOiBjb3VudFxuICAgICAgICAgIH0sIGZ1bmN0aW9uICh2LCBpKSB7XG4gICAgICAgICAgICByZXR1cm4gY29sb3JHYXAoaSk7XG4gICAgICAgICAgfSkubWFwKGZ1bmN0aW9uIChpKSB7XG4gICAgICAgICAgICByZXR1cm4gKDAsIF9jcmVhdGVQcm9kdWN0W1wiZGVmYXVsdFwiXSkoJycgKyAoaSAqIE9iamVjdC5rZXlzKF9jb2xvcnNbXCJkZWZhdWx0XCJdKS5sZW5ndGggKyBpbmRleCkpO1xuICAgICAgICAgIH0pKSk7XG4gICAgICAgIH07XG5cbiAgICAgICAgZm9yIChfaXRlcmF0b3IucygpOyAhKF9zdGVwID0gX2l0ZXJhdG9yLm4oKSkuZG9uZTspIHtcbiAgICAgICAgICBfbG9vcCgpO1xuICAgICAgICB9XG4gICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgX2l0ZXJhdG9yLmUoZXJyKTtcbiAgICAgIH0gZmluYWxseSB7XG4gICAgICAgIF9pdGVyYXRvci5mKCk7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIHZhciBpZCA9IHBhZ2UgKiAxMCArIHByb2R1Y3RzLmxlbmd0aCArIDE7XG4gICAgICBwcm9kdWN0cy5wdXNoKCgwLCBfY3JlYXRlUHJvZHVjdFtcImRlZmF1bHRcIl0pKGlkICsgJycpKTtcbiAgICB9XG4gIH1cblxuICByZXR1cm4gcHJvZHVjdHMuc29ydChmdW5jdGlvbiAoYSwgYikge1xuICAgIHJldHVybiBhLmlkIC0gYi5pZDtcbiAgfSkuc2xpY2UoMCwgY291bnQpO1xufVxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9c3ViY2F0ZWdvcnkuanMubWFwIiwiXCJ1c2Ugc3RyaWN0XCI7XG5cbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwge1xuICB2YWx1ZTogdHJ1ZVxufSk7XG5leHBvcnRzW1wiZGVmYXVsdFwiXSA9IHVwZGF0ZUNhcnRJdGVtO1xuXG52YXIgX2NhcnRTdG9yZSA9IHJlcXVpcmUoXCIuL3V0aWxzL2NhcnRTdG9yZVwiKTtcblxuZnVuY3Rpb24gdXBkYXRlQ2FydEl0ZW0oaXRlbSwgcXVhbnRpdHksIHJlcSwgcmVzKSB7XG4gIHJldHVybiB7XG4gICAgY2FydDoge1xuICAgICAgaXRlbXM6ICgwLCBfY2FydFN0b3JlLnVwZGF0ZUl0ZW0pKGl0ZW0uaWQsIHF1YW50aXR5LCByZXEsIHJlcylcbiAgICB9XG4gIH07XG59XG4vLyMgc291cmNlTWFwcGluZ1VSTD11cGRhdGVDYXJ0SXRlbS5qcy5tYXAiLCJcInVzZSBzdHJpY3RcIjtcblxudmFyIF9pbnRlcm9wUmVxdWlyZURlZmF1bHQgPSByZXF1aXJlKFwiQGJhYmVsL3J1bnRpbWUvaGVscGVycy9pbnRlcm9wUmVxdWlyZURlZmF1bHRcIik7XG5cbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwge1xuICB2YWx1ZTogdHJ1ZVxufSk7XG5leHBvcnRzLmdldFByb2R1Y3RzID0gZ2V0UHJvZHVjdHM7XG5leHBvcnRzLnVwZGF0ZUl0ZW0gPSB1cGRhdGVJdGVtO1xuZXhwb3J0cy5yZW1vdmVJdGVtID0gcmVtb3ZlSXRlbTtcbmV4cG9ydHMuYWRkSXRlbSA9IGFkZEl0ZW07XG5cbnZhciBfdG9Db25zdW1hYmxlQXJyYXkyID0gX2ludGVyb3BSZXF1aXJlRGVmYXVsdChyZXF1aXJlKFwiQGJhYmVsL3J1bnRpbWUvaGVscGVycy90b0NvbnN1bWFibGVBcnJheVwiKSk7XG5cbnZhciBfZGVmaW5lUHJvcGVydHkyID0gX2ludGVyb3BSZXF1aXJlRGVmYXVsdChyZXF1aXJlKFwiQGJhYmVsL3J1bnRpbWUvaGVscGVycy9kZWZpbmVQcm9wZXJ0eVwiKSk7XG5cbnZhciBfY3JlYXRlUHJvZHVjdCA9IF9pbnRlcm9wUmVxdWlyZURlZmF1bHQocmVxdWlyZShcIi4vY3JlYXRlUHJvZHVjdFwiKSk7XG5cbmZ1bmN0aW9uIG93bktleXMob2JqZWN0LCBlbnVtZXJhYmxlT25seSkgeyB2YXIga2V5cyA9IE9iamVjdC5rZXlzKG9iamVjdCk7IGlmIChPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKSB7IHZhciBzeW1ib2xzID0gT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyhvYmplY3QpOyBpZiAoZW51bWVyYWJsZU9ubHkpIHN5bWJvbHMgPSBzeW1ib2xzLmZpbHRlcihmdW5jdGlvbiAoc3ltKSB7IHJldHVybiBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKG9iamVjdCwgc3ltKS5lbnVtZXJhYmxlOyB9KTsga2V5cy5wdXNoLmFwcGx5KGtleXMsIHN5bWJvbHMpOyB9IHJldHVybiBrZXlzOyB9XG5cbmZ1bmN0aW9uIF9vYmplY3RTcHJlYWQodGFyZ2V0KSB7IGZvciAodmFyIGkgPSAxOyBpIDwgYXJndW1lbnRzLmxlbmd0aDsgaSsrKSB7IHZhciBzb3VyY2UgPSBhcmd1bWVudHNbaV0gIT0gbnVsbCA/IGFyZ3VtZW50c1tpXSA6IHt9OyBpZiAoaSAlIDIpIHsgb3duS2V5cyhPYmplY3Qoc291cmNlKSwgdHJ1ZSkuZm9yRWFjaChmdW5jdGlvbiAoa2V5KSB7ICgwLCBfZGVmaW5lUHJvcGVydHkyW1wiZGVmYXVsdFwiXSkodGFyZ2V0LCBrZXksIHNvdXJjZVtrZXldKTsgfSk7IH0gZWxzZSBpZiAoT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcnMpIHsgT2JqZWN0LmRlZmluZVByb3BlcnRpZXModGFyZ2V0LCBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9ycyhzb3VyY2UpKTsgfSBlbHNlIHsgb3duS2V5cyhPYmplY3Qoc291cmNlKSkuZm9yRWFjaChmdW5jdGlvbiAoa2V5KSB7IE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0YXJnZXQsIGtleSwgT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcihzb3VyY2UsIGtleSkpOyB9KTsgfSB9IHJldHVybiB0YXJnZXQ7IH1cblxudmFyIENBUlRfQ09PS0lFID0gJ3JzZl9tb2NrX2NhcnQnO1xudmFyIGluaXRpYWxTdG9yZSA9IFt7XG4gIGlkOiAxLFxuICBxdWFudGl0eTogMVxufSwge1xuICBpZDogMixcbiAgcXVhbnRpdHk6IDFcbn1dO1xuXG5mdW5jdGlvbiBnZXRTdG9yZShyZXEsIHJlcykge1xuICBpZiAoIXJlcS5jb29raWVzW0NBUlRfQ09PS0lFXSkge1xuICAgIHJlcy5zZXRIZWFkZXIoJ1NldC1Db29raWUnLCBcIlwiLmNvbmNhdChDQVJUX0NPT0tJRSwgXCI9XCIpLmNvbmNhdChKU09OLnN0cmluZ2lmeShpbml0aWFsU3RvcmUpLCBcIjsgUGF0aD0vXCIpKTtcbiAgfVxuXG4gIHZhciBzdG9yZSA9IHJlcS5jb29raWVzW0NBUlRfQ09PS0lFXSB8fCBpbml0aWFsU3RvcmU7XG5cbiAgdHJ5IHtcbiAgICByZXR1cm4gSlNPTi5wYXJzZShzdG9yZSk7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGNvbnNvbGUubG9nKCdGYWlsZWQgcGFyc2luZyBzdG9yZSBmcm9tIGNvb2tpZScsIHJlcS5jb29raWVzW0NBUlRfQ09PS0lFXSk7XG4gICAgcmV0dXJuIFtdO1xuICB9XG59XG5cbmZ1bmN0aW9uIHRvUHJvZHVjdChfcmVmKSB7XG4gIHZhciBpZCA9IF9yZWYuaWQsXG4gICAgICBxdWFudGl0eSA9IF9yZWYucXVhbnRpdHk7XG4gIHJldHVybiBfb2JqZWN0U3ByZWFkKF9vYmplY3RTcHJlYWQoe30sICgwLCBfY3JlYXRlUHJvZHVjdFtcImRlZmF1bHRcIl0pKGlkKSksIHt9LCB7XG4gICAgcXVhbnRpdHk6IHF1YW50aXR5XG4gIH0pO1xufVxuXG5mdW5jdGlvbiBnZXRQcm9kdWN0cyhyZXEsIHJlcykge1xuICByZXR1cm4gZ2V0U3RvcmUocmVxLCByZXMpLm1hcCh0b1Byb2R1Y3QpO1xufVxuXG5mdW5jdGlvbiB1cGRhdGVJdGVtKGlkLCBxdWFudGl0eSwgcmVxLCByZXMpIHtcbiAgdmFyIG5ld1N0b3JlID0gKDAsIF90b0NvbnN1bWFibGVBcnJheTJbXCJkZWZhdWx0XCJdKShnZXRTdG9yZShyZXEsIHJlcykpO1xuICB2YXIgaXRlbSA9IG5ld1N0b3JlLmZpbmQoZnVuY3Rpb24gKGUpIHtcbiAgICByZXR1cm4gZS5pZCA9PT0gaWQ7XG4gIH0pO1xuICBpdGVtLnF1YW50aXR5ID0gcXVhbnRpdHk7XG4gIHJlcy5zZXRIZWFkZXIoJ1NldC1Db29raWUnLCBcIlwiLmNvbmNhdChDQVJUX0NPT0tJRSwgXCI9XCIpLmNvbmNhdChKU09OLnN0cmluZ2lmeShuZXdTdG9yZSksIFwiOyBQYXRoPS9cIikpO1xuICByZXR1cm4gbmV3U3RvcmUubWFwKHRvUHJvZHVjdCk7XG59XG5cbmZ1bmN0aW9uIHJlbW92ZUl0ZW0oaWQsIHJlcSwgcmVzKSB7XG4gIHZhciBuZXdTdG9yZSA9ICgwLCBfdG9Db25zdW1hYmxlQXJyYXkyW1wiZGVmYXVsdFwiXSkoZ2V0U3RvcmUocmVxLCByZXMpKS5maWx0ZXIoZnVuY3Rpb24gKGUpIHtcbiAgICByZXR1cm4gZS5pZCAhPT0gaWQ7XG4gIH0pO1xuICByZXMuc2V0SGVhZGVyKCdTZXQtQ29va2llJywgXCJcIi5jb25jYXQoQ0FSVF9DT09LSUUsIFwiPVwiKS5jb25jYXQoSlNPTi5zdHJpbmdpZnkobmV3U3RvcmUpLCBcIjsgUGF0aD0vXCIpKTtcbiAgcmV0dXJuIG5ld1N0b3JlLm1hcCh0b1Byb2R1Y3QpO1xufVxuXG5mdW5jdGlvbiBhZGRJdGVtKGlkLCBxdWFudGl0eSwgcmVxLCByZXMpIHtcbiAgdmFyIG5ld1N0b3JlID0gW3tcbiAgICBpZDogaWQsXG4gICAgcXVhbnRpdHk6IHF1YW50aXR5XG4gIH1dLmNvbmNhdCgoMCwgX3RvQ29uc3VtYWJsZUFycmF5MltcImRlZmF1bHRcIl0pKGdldFN0b3JlKHJlcSwgcmVzKSkpO1xuICByZXMuc2V0SGVhZGVyKCdTZXQtQ29va2llJywgXCJcIi5jb25jYXQoQ0FSVF9DT09LSUUsIFwiPVwiKS5jb25jYXQoSlNPTi5zdHJpbmdpZnkobmV3U3RvcmUpLCBcIjsgUGF0aD0vXCIpKTtcbiAgcmV0dXJuIG5ld1N0b3JlLm1hcCh0b1Byb2R1Y3QpO1xufVxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Y2FydFN0b3JlLmpzLm1hcCIsIlwidXNlIHN0cmljdFwiO1xuXG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHtcbiAgdmFsdWU6IHRydWVcbn0pO1xuZXhwb3J0cy5jb2xvckZvcklkID0gY29sb3JGb3JJZDtcbmV4cG9ydHMuaW5kZXhGb3JDb2xvciA9IGluZGV4Rm9yQ29sb3I7XG5leHBvcnRzW1wiZGVmYXVsdFwiXSA9IHZvaWQgMDtcblxudmFyIF9jb2xvcnMgPSByZXF1aXJlKFwiQG1hdGVyaWFsLXVpL2NvcmUvY29sb3JzXCIpO1xuXG52YXIgY29sb3IgPSBmdW5jdGlvbiBjb2xvcihjKSB7XG4gIHJldHVybiBjLnRvU3RyaW5nKCkucmVwbGFjZSgvXFwjLywgJycpO1xufTtcblxudmFyIGNvbG9ycyA9IHtcbiAgcmVkOiB7XG4gICAgYmFja2dyb3VuZDogY29sb3IoX2NvbG9ycy5yZWRbNTAwXSksXG4gICAgZm9yZWdyb3VuZDogJ2ZmZmZmZidcbiAgfSxcbiAgZ3JlZW46IHtcbiAgICBiYWNrZ3JvdW5kOiBjb2xvcihfY29sb3JzLmdyZWVuWzUwMF0pLFxuICAgIGZvcmVncm91bmQ6ICdmZmZmZmYnXG4gIH0sXG4gIGJsdWU6IHtcbiAgICBiYWNrZ3JvdW5kOiBjb2xvcihfY29sb3JzLmJsdWVbNTAwXSksXG4gICAgZm9yZWdyb3VuZDogJ2ZmZmZmZidcbiAgfSxcbiAgZ3JleToge1xuICAgIGJhY2tncm91bmQ6IGNvbG9yKF9jb2xvcnMuZ3JleVszMDBdKSxcbiAgICBmb3JlZ3JvdW5kOiBjb2xvcihfY29sb3JzLmdyZXlbNjAwXSlcbiAgfSxcbiAgdGVhbDoge1xuICAgIGJhY2tncm91bmQ6IGNvbG9yKF9jb2xvcnMudGVhbFs1MDBdKSxcbiAgICBmb3JlZ3JvdW5kOiAnZmZmZmZmJ1xuICB9LFxuICBvcmFuZ2U6IHtcbiAgICBiYWNrZ3JvdW5kOiBjb2xvcihfY29sb3JzLm9yYW5nZVs1MDBdKSxcbiAgICBmb3JlZ3JvdW5kOiAnZmZmZmZmJ1xuICB9LFxuICBwdXJwbGU6IHtcbiAgICBiYWNrZ3JvdW5kOiBjb2xvcihfY29sb3JzLnB1cnBsZVs1MDBdKSxcbiAgICBmb3JlZ3JvdW5kOiAnZmZmZmZmJ1xuICB9LFxuICBibGFjazoge1xuICAgIGJhY2tncm91bmQ6IGNvbG9yKF9jb2xvcnMuZ3JleVs4MDBdKSxcbiAgICBmb3JlZ3JvdW5kOiAnZmZmZmZmJ1xuICB9XG59O1xudmFyIF9kZWZhdWx0ID0gY29sb3JzO1xuZXhwb3J0c1tcImRlZmF1bHRcIl0gPSBfZGVmYXVsdDtcblxuZnVuY3Rpb24gY29sb3JGb3JJZChpZCkge1xuICB2YXIga2V5cyA9IE9iamVjdC5rZXlzKGNvbG9ycyk7XG4gIHZhciBpbmRleCA9IGlkICUga2V5cy5sZW5ndGg7XG4gIHJldHVybiBrZXlzW2luZGV4XTtcbn1cblxuZnVuY3Rpb24gaW5kZXhGb3JDb2xvcihjb2xvcikge1xuICByZXR1cm4gT2JqZWN0LmtleXMoY29sb3JzKS5pbmRleE9mKGNvbG9yKTtcbn1cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWNvbG9ycy5qcy5tYXAiLCJcInVzZSBzdHJpY3RcIjtcblxudmFyIF9pbnRlcm9wUmVxdWlyZURlZmF1bHQgPSByZXF1aXJlKFwiQGJhYmVsL3J1bnRpbWUvaGVscGVycy9pbnRlcm9wUmVxdWlyZURlZmF1bHRcIik7XG5cbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwge1xuICB2YWx1ZTogdHJ1ZVxufSk7XG5leHBvcnRzW1wiZGVmYXVsdFwiXSA9IGNyZWF0ZUFwcERhdGE7XG5cbnZhciBfY3JlYXRlTWVudSA9IF9pbnRlcm9wUmVxdWlyZURlZmF1bHQocmVxdWlyZShcIi4vY3JlYXRlTWVudVwiKSk7XG5cbnZhciBfY3JlYXRlVGFicyA9IF9pbnRlcm9wUmVxdWlyZURlZmF1bHQocmVxdWlyZShcIi4vY3JlYXRlVGFic1wiKSk7XG5cbmZ1bmN0aW9uIGNyZWF0ZUFwcERhdGEoKSB7XG4gIHJldHVybiBQcm9taXNlLnJlc29sdmUoe1xuICAgIG1lbnU6ICgwLCBfY3JlYXRlTWVudVtcImRlZmF1bHRcIl0pKCksXG4gICAgdGFiczogKDAsIF9jcmVhdGVUYWJzW1wiZGVmYXVsdFwiXSkoKVxuICB9KTtcbn1cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWNyZWF0ZUFwcERhdGEuanMubWFwIiwiXCJ1c2Ugc3RyaWN0XCI7XG5cbnZhciBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0ID0gcmVxdWlyZShcIkBiYWJlbC9ydW50aW1lL2hlbHBlcnMvaW50ZXJvcFJlcXVpcmVEZWZhdWx0XCIpO1xuXG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHtcbiAgdmFsdWU6IHRydWVcbn0pO1xuZXhwb3J0c1tcImRlZmF1bHRcIl0gPSBjcmVhdGVGYWNldHM7XG5cbnZhciBfY29sb3JzID0gX2ludGVyb3BSZXF1aXJlRGVmYXVsdChyZXF1aXJlKFwiLi9jb2xvcnNcIikpO1xuXG52YXIgX2NhcGl0YWxpemUgPSBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0KHJlcXVpcmUoXCJsb2Rhc2gvY2FwaXRhbGl6ZVwiKSk7XG5cbmZ1bmN0aW9uIGNyZWF0ZUZhY2V0cygpIHtcbiAgcmV0dXJuIFt7XG4gICAgbmFtZTogJ0NvbG9yJyxcbiAgICB1aTogJ2J1dHRvbnMnLFxuICAgIG9wdGlvbnM6IE9iamVjdC5rZXlzKF9jb2xvcnNbXCJkZWZhdWx0XCJdKS5tYXAoZnVuY3Rpb24gKG5hbWUpIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIG5hbWU6ICgwLCBfY2FwaXRhbGl6ZVtcImRlZmF1bHRcIl0pKG5hbWUpLFxuICAgICAgICBjb2RlOiBcImNvbG9yOlwiLmNvbmNhdChuYW1lKSxcbiAgICAgICAgaW1hZ2U6IHtcbiAgICAgICAgICBzcmM6IFwiaHR0cHM6Ly9kdW1teWltYWdlLmNvbS80OHg0OC9cIi5jb25jYXQoX2NvbG9yc1tcImRlZmF1bHRcIl1bbmFtZV0uYmFja2dyb3VuZCwgXCI/dGV4dD1cIikuY29uY2F0KGVuY29kZVVSSUNvbXBvbmVudCgnICcpKSxcbiAgICAgICAgICBhbHQ6IG5hbWVcbiAgICAgICAgfVxuICAgICAgfTtcbiAgICB9KVxuICB9LCB7XG4gICAgbmFtZTogJ1NpemUnLFxuICAgIHVpOiAnYnV0dG9ucycsXG4gICAgb3B0aW9uczogW3tcbiAgICAgIG5hbWU6ICdTTScsXG4gICAgICBjb2RlOiAnc2l6ZTpzbSdcbiAgICB9LCB7XG4gICAgICBuYW1lOiAnTUQnLFxuICAgICAgY29kZTogJ3NpemU6bWQnXG4gICAgfSwge1xuICAgICAgbmFtZTogJ0xHJyxcbiAgICAgIGNvZGU6ICdzaXplOmxnJ1xuICAgIH0sIHtcbiAgICAgIG5hbWU6ICdYTCcsXG4gICAgICBjb2RlOiAnc2l6ZTp4bCdcbiAgICB9LCB7XG4gICAgICBuYW1lOiAnWFhMJyxcbiAgICAgIGNvZGU6ICdzaXplOnh4bCdcbiAgICB9XVxuICB9LCB7XG4gICAgbmFtZTogJ1R5cGUnLFxuICAgIHVpOiAnY2hlY2tib3hlcycsXG4gICAgb3B0aW9uczogW3tcbiAgICAgIG5hbWU6ICdOZXcnLFxuICAgICAgY29kZTogJ3R5cGU6bmV3JyxcbiAgICAgIG1hdGNoZXM6IDEwMFxuICAgIH0sIHtcbiAgICAgIG5hbWU6ICdVc2VkJyxcbiAgICAgIGNvZGU6ICd0eXBlOnVzZWQnLFxuICAgICAgbWF0Y2hlczogMjBcbiAgICB9XVxuICB9XTtcbn1cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWNyZWF0ZUZhY2V0cy5qcy5tYXAiLCJcInVzZSBzdHJpY3RcIjtcblxudmFyIF9pbnRlcm9wUmVxdWlyZURlZmF1bHQgPSByZXF1aXJlKFwiQGJhYmVsL3J1bnRpbWUvaGVscGVycy9pbnRlcm9wUmVxdWlyZURlZmF1bHRcIik7XG5cbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwge1xuICB2YWx1ZTogdHJ1ZVxufSk7XG5leHBvcnRzW1wiZGVmYXVsdFwiXSA9IGNyZWF0ZU1lZGlhO1xuXG52YXIgX2NvbG9ycyA9IF9pbnRlcm9wUmVxdWlyZURlZmF1bHQocmVxdWlyZShcIi4vY29sb3JzXCIpKTtcblxuZnVuY3Rpb24gY3JlYXRlTWVkaWEoaWQsIGNvbG9yKSB7XG4gIHJldHVybiB7XG4gICAgZnVsbDogW2NvbG9yXS5tYXAoZnVuY3Rpb24gKGtleSwgaSkge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgc3JjOiBcImh0dHBzOi8vZHVtbXlpbWFnZS5jb20vXCIuY29uY2F0KGkgPT09IDIgPyA0MDAgOiA2MDAsIFwieFwiKS5jb25jYXQoaSA9PT0gMSA/IDQwMCA6IDYwMCwgXCIvXCIpLmNvbmNhdChfY29sb3JzW1wiZGVmYXVsdFwiXVtrZXldLmJhY2tncm91bmQsIFwiL1wiKS5jb25jYXQoX2NvbG9yc1tcImRlZmF1bHRcIl1ba2V5XS5mb3JlZ3JvdW5kLCBcIj90ZXh0PVwiKS5jb25jYXQoZW5jb2RlVVJJQ29tcG9uZW50KCdQcm9kdWN0ICcgKyBpZCkpLFxuICAgICAgICBhbHQ6IFwiUHJvZHVjdCBcIi5jb25jYXQoaWQpLFxuICAgICAgICBtYWduaWZ5OiB7XG4gICAgICAgICAgaGVpZ2h0OiBpID09PSAxID8gODAwIDogMTIwMCxcbiAgICAgICAgICB3aWR0aDogaSA9PT0gMiA/IDgwMCA6IDEyMDAsXG4gICAgICAgICAgc3JjOiBcImh0dHBzOi8vZHVtbXlpbWFnZS5jb20vXCIuY29uY2F0KGkgPT09IDIgPyA4MDAgOiAxMjAwLCBcInhcIikuY29uY2F0KGkgPT09IDEgPyA4MDAgOiAxMjAwLCBcIi9cIikuY29uY2F0KF9jb2xvcnNbXCJkZWZhdWx0XCJdW2tleV0uYmFja2dyb3VuZCwgXCIvXCIpLmNvbmNhdChfY29sb3JzW1wiZGVmYXVsdFwiXVtrZXldLmZvcmVncm91bmQsIFwiP3RleHQ9XCIpLmNvbmNhdChlbmNvZGVVUklDb21wb25lbnQoJ1Byb2R1Y3QgJyArIGlkKSlcbiAgICAgICAgfVxuICAgICAgfTtcbiAgICB9KSxcbiAgICB0aHVtYm5haWxzOiBbY29sb3JdLm1hcChmdW5jdGlvbiAoa2V5LCBpKSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICBzcmM6IFwiaHR0cHM6Ly9kdW1teWltYWdlLmNvbS9cIi5jb25jYXQoaSA9PT0gMiA/IDMwMCA6IDQwMCwgXCJ4XCIpLmNvbmNhdChpID09PSAxID8gMzAwIDogNDAwLCBcIi9cIikuY29uY2F0KF9jb2xvcnNbXCJkZWZhdWx0XCJdW2tleV0uYmFja2dyb3VuZCwgXCI/dGV4dD1cIikuY29uY2F0KGVuY29kZVVSSUNvbXBvbmVudChcIlByb2R1Y3QgXCIuY29uY2F0KGlkKSkpLFxuICAgICAgICBhbHQ6IGtleVxuICAgICAgfTtcbiAgICB9KVxuICB9O1xufVxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Y3JlYXRlTWVkaWEuanMubWFwIiwiXCJ1c2Ugc3RyaWN0XCI7XG5cbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwge1xuICB2YWx1ZTogdHJ1ZVxufSk7XG5leHBvcnRzW1wiZGVmYXVsdFwiXSA9IGNyZWF0ZU1lbnU7XG5cbmZ1bmN0aW9uIGNyZWF0ZU1lbnUoKSB7XG4gIHZhciBpdGVtcyA9IFtdO1xuXG4gIGZvciAodmFyIGkgPSAxOyBpIDw9IDU7IGkrKykge1xuICAgIGl0ZW1zLnB1c2goY3JlYXRlQ2F0ZWdvcnlJdGVtKGkpKTtcbiAgfVxuXG4gIHJldHVybiB7XG4gICAgaXRlbXM6IGl0ZW1zLFxuICAgIGhlYWRlcjogJ2hlYWRlcicsXG4gICAgZm9vdGVyOiAnZm9vdGVyJ1xuICB9O1xufVxuXG5mdW5jdGlvbiBjcmVhdGVDYXRlZ29yeUl0ZW0oaSkge1xuICB2YXIgaXRlbXMgPSBbXTtcblxuICBmb3IgKHZhciBqID0gMTsgaiA8PSA1OyBqKyspIHtcbiAgICBpdGVtcy5wdXNoKGNyZWF0ZVN1YmNhdGVnb3J5SXRlbShqKSk7XG4gIH1cblxuICByZXR1cm4ge1xuICAgIHRleHQ6IFwiQ2F0ZWdvcnkgXCIuY29uY2F0KGkpLFxuICAgIGl0ZW1zOiBpdGVtc1xuICB9O1xufVxuXG5mdW5jdGlvbiBjcmVhdGVTdWJjYXRlZ29yeUl0ZW0oaSkge1xuICB2YXIgaXRlbXMgPSBbXTtcblxuICBmb3IgKHZhciBqID0gMTsgaiA8PSA1OyBqKyspIHtcbiAgICBpdGVtcy5wdXNoKGNyZWF0ZVByb2R1Y3RJdGVtKGopKTtcbiAgfVxuXG4gIHJldHVybiB7XG4gICAgdGV4dDogXCJTdWJjYXRlZ29yeSBcIi5jb25jYXQoaSksXG4gICAgaHJlZjogXCIvcy9bLi4uY2F0ZWdvcnlTbHVnXVwiLFxuICAgIGFzOiBcIi9zL1wiLmNvbmNhdChpKSxcbiAgICBleHBhbmRlZDogaSA9PT0gMSxcbiAgICBpdGVtczogaXRlbXNcbiAgfTtcbn1cblxuZnVuY3Rpb24gY3JlYXRlUHJvZHVjdEl0ZW0oaSkge1xuICByZXR1cm4ge1xuICAgIHRleHQ6IFwiUHJvZHVjdCBcIi5jb25jYXQoaSksXG4gICAgaHJlZjogXCIvcC9bcHJvZHVjdElkXVwiLFxuICAgIGFzOiBcIi9wL1wiLmNvbmNhdChpKVxuICB9O1xufVxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Y3JlYXRlTWVudS5qcy5tYXAiLCJcInVzZSBzdHJpY3RcIjtcblxudmFyIF9pbnRlcm9wUmVxdWlyZURlZmF1bHQgPSByZXF1aXJlKFwiQGJhYmVsL3J1bnRpbWUvaGVscGVycy9pbnRlcm9wUmVxdWlyZURlZmF1bHRcIik7XG5cbnZhciBfaW50ZXJvcFJlcXVpcmVXaWxkY2FyZCA9IHJlcXVpcmUoXCJAYmFiZWwvcnVudGltZS9oZWxwZXJzL2ludGVyb3BSZXF1aXJlV2lsZGNhcmRcIik7XG5cbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwge1xuICB2YWx1ZTogdHJ1ZVxufSk7XG5leHBvcnRzW1wiZGVmYXVsdFwiXSA9IGNyZWF0ZVByb2R1Y3Q7XG5cbnZhciBfY29sb3JzID0gX2ludGVyb3BSZXF1aXJlV2lsZGNhcmQocmVxdWlyZShcIi4vY29sb3JzXCIpKTtcblxudmFyIF9jYXBpdGFsaXplID0gX2ludGVyb3BSZXF1aXJlRGVmYXVsdChyZXF1aXJlKFwibG9kYXNoL2NhcGl0YWxpemVcIikpO1xuXG52YXIgX2xvcmVtSXBzdW0gPSByZXF1aXJlKFwibG9yZW0taXBzdW1cIik7XG5cbmZ1bmN0aW9uIGNyZWF0ZVByb2R1Y3QoaWQpIHtcbiAgdmFyIG51bUNvbG9ycyA9IGFyZ3VtZW50cy5sZW5ndGggPiAxICYmIGFyZ3VtZW50c1sxXSAhPT0gdW5kZWZpbmVkID8gYXJndW1lbnRzWzFdIDogNDtcbiAgdmFyIGNvbG9yID0gKDAsIF9jb2xvcnMuY29sb3JGb3JJZCkoaWQpO1xuICB2YXIgdmFyaWFudHMgPSBbY29sb3IsICdyZWQnLCAnYmx1ZSddO1xuICB2YXIgcHJpY2UgPSBpZCAlIDEwICogMTAgKyAwLjk5O1xuICByZXR1cm4ge1xuICAgIGlkOiBpZCxcbiAgICB1cmw6IFwiL3AvXCIuY29uY2F0KGlkKSxcbiAgICBuYW1lOiBcIlByb2R1Y3QgXCIuY29uY2F0KGlkKSxcbiAgICBwcmljZTogcHJpY2UsXG4gICAgcHJpY2VUZXh0OiBcIiRcIi5jb25jYXQocHJpY2UpLFxuICAgIHJhdGluZzogKDEwIC0gaWQgJSAxMCkgLyAyLjAsXG4gICAgdGh1bWJuYWlsOiB7XG4gICAgICBzcmM6IFwiaHR0cHM6Ly9kdW1teWltYWdlLmNvbS80MDB4NDAwL1wiLmNvbmNhdChfY29sb3JzW1wiZGVmYXVsdFwiXVtjb2xvcl0uYmFja2dyb3VuZCwgXCIvXCIpLmNvbmNhdChfY29sb3JzW1wiZGVmYXVsdFwiXVtjb2xvcl0uZm9yZWdyb3VuZCwgXCI/dGV4dD1cIikuY29uY2F0KGVuY29kZVVSSUNvbXBvbmVudCgnUHJvZHVjdCAnICsgaWQpKSxcbiAgICAgIGFsdDogXCJQcm9kdWN0IFwiLmNvbmNhdChpZClcbiAgICB9LFxuICAgIG1lZGlhOiB7XG4gICAgICBmdWxsOiB2YXJpYW50cy5tYXAoZnVuY3Rpb24gKGtleSwgaSkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIHNyYzogXCJodHRwczovL2R1bW15aW1hZ2UuY29tL1wiLmNvbmNhdChpID09PSAyID8gNDAwIDogNjAwLCBcInhcIikuY29uY2F0KGkgPT09IDEgPyA0MDAgOiA2MDAsIFwiL1wiKS5jb25jYXQoX2NvbG9yc1tcImRlZmF1bHRcIl1ba2V5XS5iYWNrZ3JvdW5kLCBcIi9cIikuY29uY2F0KF9jb2xvcnNbXCJkZWZhdWx0XCJdW2tleV0uZm9yZWdyb3VuZCwgXCI/dGV4dD1cIikuY29uY2F0KGVuY29kZVVSSUNvbXBvbmVudCgnUHJvZHVjdCAnICsgaWQpKSxcbiAgICAgICAgICBhbHQ6IFwiUHJvZHVjdCBcIi5jb25jYXQoaWQpLFxuICAgICAgICAgIG1hZ25pZnk6IHtcbiAgICAgICAgICAgIGhlaWdodDogaSA9PT0gMSA/IDgwMCA6IDEyMDAsXG4gICAgICAgICAgICB3aWR0aDogaSA9PT0gMiA/IDgwMCA6IDEyMDAsXG4gICAgICAgICAgICBzcmM6IFwiaHR0cHM6Ly9kdW1teWltYWdlLmNvbS9cIi5jb25jYXQoaSA9PT0gMiA/IDgwMCA6IDEyMDAsIFwieFwiKS5jb25jYXQoaSA9PT0gMSA/IDgwMCA6IDEyMDAsIFwiL1wiKS5jb25jYXQoX2NvbG9yc1tcImRlZmF1bHRcIl1ba2V5XS5iYWNrZ3JvdW5kLCBcIi9cIikuY29uY2F0KF9jb2xvcnNbXCJkZWZhdWx0XCJdW2tleV0uZm9yZWdyb3VuZCwgXCI/dGV4dD1cIikuY29uY2F0KGVuY29kZVVSSUNvbXBvbmVudCgnUHJvZHVjdCAnICsgaWQpKVxuICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICAgIH0pLFxuICAgICAgdGh1bWJuYWlsczogdmFyaWFudHMubWFwKGZ1bmN0aW9uIChrZXksIGkpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBzcmM6IFwiaHR0cHM6Ly9kdW1teWltYWdlLmNvbS9cIi5jb25jYXQoaSA9PT0gMiA/IDIzMyA6IDMwMCwgXCJ4XCIpLmNvbmNhdChpID09PSAxID8gMjMzIDogMzAwLCBcIi9cIikuY29uY2F0KF9jb2xvcnNbXCJkZWZhdWx0XCJdW2tleV0uYmFja2dyb3VuZCwgXCIvXCIpLmNvbmNhdChfY29sb3JzW1wiZGVmYXVsdFwiXVtrZXldLmZvcmVncm91bmQsIFwiP3RleHQ9XCIpLmNvbmNhdChlbmNvZGVVUklDb21wb25lbnQoJ1Byb2R1Y3QgJyArIGlkKSksXG4gICAgICAgICAgYWx0OiBcIlByb2R1Y3QgXCIuY29uY2F0KGlkKVxuICAgICAgICB9O1xuICAgICAgfSlcbiAgICB9LFxuICAgIHNpemVzOiBbe1xuICAgICAgaWQ6ICdzbScsXG4gICAgICB0ZXh0OiAnU00nXG4gICAgfSwge1xuICAgICAgaWQ6ICdtZCcsXG4gICAgICB0ZXh0OiAnTUQnXG4gICAgfSwge1xuICAgICAgaWQ6ICdsZycsXG4gICAgICB0ZXh0OiAnTEcnXG4gICAgfSwge1xuICAgICAgaWQ6ICd4bCcsXG4gICAgICB0ZXh0OiAnWEwnLFxuICAgICAgZGlzYWJsZWQ6IHRydWVcbiAgICB9LCB7XG4gICAgICBpZDogJ3h4bCcsXG4gICAgICB0ZXh0OiAnWFhMJ1xuICAgIH1dLFxuICAgIGRlc2NyaXB0aW9uOiAoMCwgX2xvcmVtSXBzdW0ubG9yZW1JcHN1bSkoe1xuICAgICAgY291bnQ6IDEwXG4gICAgfSksXG4gICAgc3BlY3M6ICgwLCBfbG9yZW1JcHN1bS5sb3JlbUlwc3VtKSh7XG4gICAgICBjb3VudDogMTBcbiAgICB9KSxcbiAgICBjb2xvcnM6IE9iamVjdC5rZXlzKF9jb2xvcnNbXCJkZWZhdWx0XCJdKS5zbGljZSgwLCBudW1Db2xvcnMpLm1hcChmdW5jdGlvbiAobmFtZSwgaWR4KSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICB0ZXh0OiAoMCwgX2NhcGl0YWxpemVbXCJkZWZhdWx0XCJdKShuYW1lKSxcbiAgICAgICAgaWQ6IG5hbWUsXG4gICAgICAgIGRpc2FibGVkOiBpZHggPT09IDIsXG4gICAgICAgIGltYWdlOiB7XG4gICAgICAgICAgc3JjOiBcImh0dHBzOi8vZHVtbXlpbWFnZS5jb20vNDh4NDgvXCIuY29uY2F0KF9jb2xvcnNbXCJkZWZhdWx0XCJdW25hbWVdLmJhY2tncm91bmQsIFwiP3RleHQ9XCIpLmNvbmNhdChlbmNvZGVVUklDb21wb25lbnQoJyAnKSksXG4gICAgICAgICAgYWx0OiBuYW1lXG4gICAgICAgIH0sXG4gICAgICAgIG1lZGlhOiB7XG4gICAgICAgICAgZnVsbDogW25hbWUsIG5hbWUsIG5hbWVdLm1hcChmdW5jdGlvbiAoa2V5LCBpKSB7XG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICBzcmM6IFwiaHR0cHM6Ly9kdW1teWltYWdlLmNvbS9cIi5jb25jYXQoaSA9PT0gMiA/IDQwMCA6IDYwMCwgXCJ4XCIpLmNvbmNhdChpID09PSAxID8gNDAwIDogNjAwLCBcIi9cIikuY29uY2F0KF9jb2xvcnNbXCJkZWZhdWx0XCJdW2tleV0uYmFja2dyb3VuZCwgXCIvXCIpLmNvbmNhdChfY29sb3JzW1wiZGVmYXVsdFwiXVtrZXldLmZvcmVncm91bmQsIFwiP3RleHQ9XCIpLmNvbmNhdChlbmNvZGVVUklDb21wb25lbnQoJ1Byb2R1Y3QgJyArIGlkKSksXG4gICAgICAgICAgICAgIGFsdDogXCJQcm9kdWN0IFwiLmNvbmNhdChpZCksXG4gICAgICAgICAgICAgIG1hZ25pZnk6IHtcbiAgICAgICAgICAgICAgICBoZWlnaHQ6IGkgPT09IDEgPyA4MDAgOiAxMjAwLFxuICAgICAgICAgICAgICAgIHdpZHRoOiBpID09PSAyID8gODAwIDogMTIwMCxcbiAgICAgICAgICAgICAgICBzcmM6IFwiaHR0cHM6Ly9kdW1teWltYWdlLmNvbS9cIi5jb25jYXQoaSA9PT0gMiA/IDgwMCA6IDEyMDAsIFwieFwiKS5jb25jYXQoaSA9PT0gMSA/IDgwMCA6IDEyMDAsIFwiL1wiKS5jb25jYXQoX2NvbG9yc1tcImRlZmF1bHRcIl1ba2V5XS5iYWNrZ3JvdW5kLCBcIi9cIikuY29uY2F0KF9jb2xvcnNbXCJkZWZhdWx0XCJdW2tleV0uZm9yZWdyb3VuZCwgXCI/dGV4dD1cIikuY29uY2F0KGVuY29kZVVSSUNvbXBvbmVudCgnUHJvZHVjdCAnICsgaWQpKVxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9O1xuICAgICAgICAgIH0pLFxuICAgICAgICAgIHRodW1ibmFpbHM6IFtuYW1lLCBuYW1lLCBuYW1lXS5tYXAoZnVuY3Rpb24gKGtleSwgaSkge1xuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgc3JjOiBcImh0dHBzOi8vZHVtbXlpbWFnZS5jb20vXCIuY29uY2F0KGkgPT09IDIgPyAzMDAgOiA0MDAsIFwieFwiKS5jb25jYXQoaSA9PT0gMSA/IDMwMCA6IDQwMCwgXCIvXCIpLmNvbmNhdChfY29sb3JzW1wiZGVmYXVsdFwiXVtrZXldLmJhY2tncm91bmQsIFwiL1wiKS5jb25jYXQoX2NvbG9yc1tcImRlZmF1bHRcIl1ba2V5XS5mb3JlZ3JvdW5kLCBcIj90ZXh0PVwiKS5jb25jYXQoZW5jb2RlVVJJQ29tcG9uZW50KFwiUHJvZHVjdCBcIi5jb25jYXQoaWQpKSksXG4gICAgICAgICAgICAgIGFsdDoga2V5XG4gICAgICAgICAgICB9O1xuICAgICAgICAgIH0pLFxuICAgICAgICAgIHRodW1ibmFpbDogW25hbWVdLm1hcChmdW5jdGlvbiAoa2V5KSB7XG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICBzcmM6IFwiaHR0cHM6Ly9kdW1teWltYWdlLmNvbS80MDB4NDAwL1wiLmNvbmNhdChfY29sb3JzW1wiZGVmYXVsdFwiXVtrZXldLmJhY2tncm91bmQsIFwiL1wiKS5jb25jYXQoX2NvbG9yc1tcImRlZmF1bHRcIl1ba2V5XS5mb3JlZ3JvdW5kLCBcIj90ZXh0PVwiKS5jb25jYXQoZW5jb2RlVVJJQ29tcG9uZW50KCdQcm9kdWN0ICcgKyBpZCkpLFxuICAgICAgICAgICAgICBhbHQ6IFwiUHJvZHVjdCBcIi5jb25jYXQoaWQpXG4gICAgICAgICAgICB9O1xuICAgICAgICAgIH0pWzBdXG4gICAgICAgIH1cbiAgICAgIH07XG4gICAgfSlcbiAgfTtcbn1cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWNyZWF0ZVByb2R1Y3QuanMubWFwIiwiXCJ1c2Ugc3RyaWN0XCI7XG5cbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwge1xuICB2YWx1ZTogdHJ1ZVxufSk7XG5leHBvcnRzW1wiZGVmYXVsdFwiXSA9IGNyZWF0ZVNvcnRPcHRpb25zO1xuXG5mdW5jdGlvbiBjcmVhdGVTb3J0T3B0aW9ucygpIHtcbiAgcmV0dXJuIFt7XG4gICAgbmFtZTogJ1ByaWNlIC0gTG93ZXN0JyxcbiAgICBjb2RlOiAncHJpY2VfYXNjJ1xuICB9LCB7XG4gICAgbmFtZTogJ1ByaWNlIC0gSGlnaGVzdCcsXG4gICAgY29kZTogJ3ByaWNlX2Rlc2MnXG4gIH0sIHtcbiAgICBuYW1lOiAnTW9zdCBQb3B1bGFyJyxcbiAgICBjb2RlOiAncG9wJ1xuICB9LCB7XG4gICAgbmFtZTogJ0hpZ2hlc3QgUmF0ZWQnLFxuICAgIGNvZGU6ICdyYXRpbmcnXG4gIH1dO1xufVxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Y3JlYXRlU29ydE9wdGlvbnMuanMubWFwIiwiXCJ1c2Ugc3RyaWN0XCI7XG5cbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwge1xuICB2YWx1ZTogdHJ1ZVxufSk7XG5leHBvcnRzW1wiZGVmYXVsdFwiXSA9IGNyZWF0ZVRhYnM7XG5cbmZ1bmN0aW9uIGNyZWF0ZVRhYnMoKSB7XG4gIHZhciB0YWJzID0gW107XG4gIHZhciBzdWJjYXRlZ29yaWVzID0gW107XG5cbiAgZm9yICh2YXIgaSA9IDE7IGkgPD0gMzsgaSsrKSB7XG4gICAgc3ViY2F0ZWdvcmllcy5wdXNoKHtcbiAgICAgIGFzOiBcIi9zL1wiLmNvbmNhdChpKSxcbiAgICAgIGhyZWY6ICcvcy9bLi4uY2F0ZWdvcnlTbHVnXScsXG4gICAgICB0ZXh0OiBcIlN1YmNhdGVnb3J5IFwiLmNvbmNhdChpKVxuICAgIH0pO1xuICB9XG5cbiAgZm9yICh2YXIgX2kgPSAxOyBfaSA8PSAxMDsgX2krKykge1xuICAgIHRhYnMucHVzaCh7XG4gICAgICBhczogXCIvcy9cIi5jb25jYXQoX2kpLFxuICAgICAgaHJlZjogJy9zL1suLi5jYXRlZ29yeVNsdWddJyxcbiAgICAgIHRleHQ6IFwiQ2F0ZWdvcnkgXCIuY29uY2F0KF9pKSxcbiAgICAgIGl0ZW1zOiBzdWJjYXRlZ29yaWVzXG4gICAgfSk7XG4gIH1cblxuICByZXR1cm4gdGFicztcbn1cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWNyZWF0ZVRhYnMuanMubWFwIiwiXCJ1c2Ugc3RyaWN0XCI7XG5cbnZhciBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0ID0gcmVxdWlyZShcIkBiYWJlbC9ydW50aW1lL2hlbHBlcnMvaW50ZXJvcFJlcXVpcmVEZWZhdWx0XCIpO1xuXG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHtcbiAgdmFsdWU6IHRydWVcbn0pO1xuZXhwb3J0c1tcImRlZmF1bHRcIl0gPSBmdWxmaWxsQVBJUmVxdWVzdDtcblxudmFyIF9yZWdlbmVyYXRvciA9IF9pbnRlcm9wUmVxdWlyZURlZmF1bHQocmVxdWlyZShcIkBiYWJlbC9ydW50aW1lL3JlZ2VuZXJhdG9yXCIpKTtcblxudmFyIF9hc3luY1RvR2VuZXJhdG9yMiA9IF9pbnRlcm9wUmVxdWlyZURlZmF1bHQocmVxdWlyZShcIkBiYWJlbC9ydW50aW1lL2hlbHBlcnMvYXN5bmNUb0dlbmVyYXRvclwiKSk7XG5cbmZ1bmN0aW9uIF9jcmVhdGVGb3JPZkl0ZXJhdG9ySGVscGVyKG8sIGFsbG93QXJyYXlMaWtlKSB7IHZhciBpdDsgaWYgKHR5cGVvZiBTeW1ib2wgPT09IFwidW5kZWZpbmVkXCIgfHwgb1tTeW1ib2wuaXRlcmF0b3JdID09IG51bGwpIHsgaWYgKEFycmF5LmlzQXJyYXkobykgfHwgKGl0ID0gX3Vuc3VwcG9ydGVkSXRlcmFibGVUb0FycmF5KG8pKSB8fCBhbGxvd0FycmF5TGlrZSAmJiBvICYmIHR5cGVvZiBvLmxlbmd0aCA9PT0gXCJudW1iZXJcIikgeyBpZiAoaXQpIG8gPSBpdDsgdmFyIGkgPSAwOyB2YXIgRiA9IGZ1bmN0aW9uIEYoKSB7fTsgcmV0dXJuIHsgczogRiwgbjogZnVuY3Rpb24gbigpIHsgaWYgKGkgPj0gby5sZW5ndGgpIHJldHVybiB7IGRvbmU6IHRydWUgfTsgcmV0dXJuIHsgZG9uZTogZmFsc2UsIHZhbHVlOiBvW2krK10gfTsgfSwgZTogZnVuY3Rpb24gZShfZSkgeyB0aHJvdyBfZTsgfSwgZjogRiB9OyB9IHRocm93IG5ldyBUeXBlRXJyb3IoXCJJbnZhbGlkIGF0dGVtcHQgdG8gaXRlcmF0ZSBub24taXRlcmFibGUgaW5zdGFuY2UuXFxuSW4gb3JkZXIgdG8gYmUgaXRlcmFibGUsIG5vbi1hcnJheSBvYmplY3RzIG11c3QgaGF2ZSBhIFtTeW1ib2wuaXRlcmF0b3JdKCkgbWV0aG9kLlwiKTsgfSB2YXIgbm9ybWFsQ29tcGxldGlvbiA9IHRydWUsIGRpZEVyciA9IGZhbHNlLCBlcnI7IHJldHVybiB7IHM6IGZ1bmN0aW9uIHMoKSB7IGl0ID0gb1tTeW1ib2wuaXRlcmF0b3JdKCk7IH0sIG46IGZ1bmN0aW9uIG4oKSB7IHZhciBzdGVwID0gaXQubmV4dCgpOyBub3JtYWxDb21wbGV0aW9uID0gc3RlcC5kb25lOyByZXR1cm4gc3RlcDsgfSwgZTogZnVuY3Rpb24gZShfZTIpIHsgZGlkRXJyID0gdHJ1ZTsgZXJyID0gX2UyOyB9LCBmOiBmdW5jdGlvbiBmKCkgeyB0cnkgeyBpZiAoIW5vcm1hbENvbXBsZXRpb24gJiYgaXRbXCJyZXR1cm5cIl0gIT0gbnVsbCkgaXRbXCJyZXR1cm5cIl0oKTsgfSBmaW5hbGx5IHsgaWYgKGRpZEVycikgdGhyb3cgZXJyOyB9IH0gfTsgfVxuXG5mdW5jdGlvbiBfdW5zdXBwb3J0ZWRJdGVyYWJsZVRvQXJyYXkobywgbWluTGVuKSB7IGlmICghbykgcmV0dXJuOyBpZiAodHlwZW9mIG8gPT09IFwic3RyaW5nXCIpIHJldHVybiBfYXJyYXlMaWtlVG9BcnJheShvLCBtaW5MZW4pOyB2YXIgbiA9IE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmcuY2FsbChvKS5zbGljZSg4LCAtMSk7IGlmIChuID09PSBcIk9iamVjdFwiICYmIG8uY29uc3RydWN0b3IpIG4gPSBvLmNvbnN0cnVjdG9yLm5hbWU7IGlmIChuID09PSBcIk1hcFwiIHx8IG4gPT09IFwiU2V0XCIpIHJldHVybiBBcnJheS5mcm9tKG8pOyBpZiAobiA9PT0gXCJBcmd1bWVudHNcIiB8fCAvXig/OlVpfEkpbnQoPzo4fDE2fDMyKSg/OkNsYW1wZWQpP0FycmF5JC8udGVzdChuKSkgcmV0dXJuIF9hcnJheUxpa2VUb0FycmF5KG8sIG1pbkxlbik7IH1cblxuZnVuY3Rpb24gX2FycmF5TGlrZVRvQXJyYXkoYXJyLCBsZW4pIHsgaWYgKGxlbiA9PSBudWxsIHx8IGxlbiA+IGFyci5sZW5ndGgpIGxlbiA9IGFyci5sZW5ndGg7IGZvciAodmFyIGkgPSAwLCBhcnIyID0gbmV3IEFycmF5KGxlbik7IGkgPCBsZW47IGkrKykgeyBhcnIyW2ldID0gYXJyW2ldOyB9IHJldHVybiBhcnIyOyB9XG5cbi8qKlxuICogQ3JlYXRlcyBhbiBBUEkgcmVzcG9uc2UgdGhhdCBjb250YWlucyBhcHAgbGV2ZWwgZGF0YSBvbmx5IHdoZW4gYD9faW5jbHVkZUFwcERhdGE9MWAgaXMgcHJlc2VudCBpblxuICogdGhlIHF1ZXJ5IHN0cmluZy4gT3RoZXJ3aXNlLCB0aGUgYGFwcERhdGFgIHByb21pc2UgcHJvdmlkZWQgd2lsbCBub3QgYmUgcmVzb2x2ZWQuXG4gKlxuICogQHBhcmFtIHtSZXF1ZXN0fSByZXEgVGhlIHJlcXVlc3QgYmVpbmcgc2VydmVkXG4gKiBAcGFyYW0ge09iamVjdH0gb3B0aW9uc1xuICogQHBhcmFtIHtGdW5jdGlvbn0gb3B0aW9ucy5hcHBEYXRhIEFuIGFzeW5jIGZ1bmN0aW9uIHRoYXQgcmV0dXJucyBhIGRhdGEgZm9yIHNoYXJlZCBjb21wb25lbnQgaW5cbiAqIHRoZSBhcHAgc3VjaCBhcyBtZW51LCBuYXYsIGFuZCBmb290ZXJcbiAqIEBwYXJhbSB7RnVuY3Rpb259IG9wdGlvbnMucGFnZURhdGEgQW4gYXN5bmMgZnVuY3Rpb24gdGhhdCByZXR1cm4gZGF0YSBmb3IgdGhlIHBhZ2UgY29tcG9uZW50XG4gKiBAcmV0dXJuIHtPYmplY3R9IHRoZSByZXN1bHQgb2YgYGFwcERhdGFgIGFuZCBgcGFnZURhdGFgIG1lcmdlZCBpbnRvIGEgc2luZ2xlIG9iamVjdC5cbiAqL1xuZnVuY3Rpb24gZnVsZmlsbEFQSVJlcXVlc3QoX3gsIF94Mikge1xuICByZXR1cm4gX2Z1bGZpbGxBUElSZXF1ZXN0LmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG59XG5cbmZ1bmN0aW9uIF9mdWxmaWxsQVBJUmVxdWVzdCgpIHtcbiAgX2Z1bGZpbGxBUElSZXF1ZXN0ID0gKDAsIF9hc3luY1RvR2VuZXJhdG9yMltcImRlZmF1bHRcIl0pKCAvKiNfX1BVUkVfXyovX3JlZ2VuZXJhdG9yW1wiZGVmYXVsdFwiXS5tYXJrKGZ1bmN0aW9uIF9jYWxsZWUocmVxLCBfcmVmKSB7XG4gICAgdmFyIGFwcERhdGEsIHBhZ2VEYXRhLCBwcm9taXNlcywgcmVzdWx0cywgZGF0YSwgX2l0ZXJhdG9yLCBfc3RlcCwgcmVzdWx0O1xuXG4gICAgcmV0dXJuIF9yZWdlbmVyYXRvcltcImRlZmF1bHRcIl0ud3JhcChmdW5jdGlvbiBfY2FsbGVlJChfY29udGV4dCkge1xuICAgICAgd2hpbGUgKDEpIHtcbiAgICAgICAgc3dpdGNoIChfY29udGV4dC5wcmV2ID0gX2NvbnRleHQubmV4dCkge1xuICAgICAgICAgIGNhc2UgMDpcbiAgICAgICAgICAgIGFwcERhdGEgPSBfcmVmLmFwcERhdGEsIHBhZ2VEYXRhID0gX3JlZi5wYWdlRGF0YTtcbiAgICAgICAgICAgIHByb21pc2VzID0gW3BhZ2VEYXRhKHJlcSkudGhlbihmdW5jdGlvbiAocGFnZURhdGEpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICBwYWdlRGF0YTogcGFnZURhdGFcbiAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIH0pXTtcblxuICAgICAgICAgICAgaWYgKHJlcS5xdWVyeS5faW5jbHVkZUFwcERhdGEgPT09ICcxJykge1xuICAgICAgICAgICAgICBwcm9taXNlcy5wdXNoKGFwcERhdGEocmVxKS50aGVuKGZ1bmN0aW9uIChhcHBEYXRhKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgIGFwcERhdGE6IGFwcERhdGFcbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICB9KSk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIF9jb250ZXh0Lm5leHQgPSA1O1xuICAgICAgICAgICAgcmV0dXJuIFByb21pc2UuYWxsKHByb21pc2VzKTtcblxuICAgICAgICAgIGNhc2UgNTpcbiAgICAgICAgICAgIHJlc3VsdHMgPSBfY29udGV4dC5zZW50O1xuICAgICAgICAgICAgZGF0YSA9IHt9O1xuICAgICAgICAgICAgX2l0ZXJhdG9yID0gX2NyZWF0ZUZvck9mSXRlcmF0b3JIZWxwZXIocmVzdWx0cyk7XG5cbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgIGZvciAoX2l0ZXJhdG9yLnMoKTsgIShfc3RlcCA9IF9pdGVyYXRvci5uKCkpLmRvbmU7KSB7XG4gICAgICAgICAgICAgICAgcmVzdWx0ID0gX3N0ZXAudmFsdWU7XG4gICAgICAgICAgICAgICAgT2JqZWN0LmFzc2lnbihkYXRhLCByZXN1bHQpO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgICAgX2l0ZXJhdG9yLmUoZXJyKTtcbiAgICAgICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICAgIF9pdGVyYXRvci5mKCk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHJldHVybiBfY29udGV4dC5hYnJ1cHQoXCJyZXR1cm5cIiwgZGF0YSk7XG5cbiAgICAgICAgICBjYXNlIDEwOlxuICAgICAgICAgIGNhc2UgXCJlbmRcIjpcbiAgICAgICAgICAgIHJldHVybiBfY29udGV4dC5zdG9wKCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9LCBfY2FsbGVlKTtcbiAgfSkpO1xuICByZXR1cm4gX2Z1bGZpbGxBUElSZXF1ZXN0LmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG59XG4vLyMgc291cmNlTWFwcGluZ1VSTD1mdWxmaWxsQVBJUmVxdWVzdC5qcy5tYXAiLCJpbXBvcnQgeyBob21lIH0gZnJvbSAncmVhY3Qtc3RvcmVmcm9udC1jb25uZWN0b3InXG5cbmV4cG9ydCBkZWZhdWx0IGFzeW5jIGZ1bmN0aW9uKHJlcSwgcmVzKSB7XG4gIHJlcy5qc29uKGF3YWl0IGhvbWUocmVxLCByZXMpKVxufVxuIiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQG1hdGVyaWFsLXVpL2NvcmUvY29sb3JzXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcImxvZGFzaC9jYXBpdGFsaXplXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcImxvcmVtLWlwc3VtXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlYWN0LXN0b3JlZnJvbnQvcHJvcHMvZnVsZmlsbEFQSVJlcXVlc3RcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicmVhY3Qtc3RvcmVmcm9udC91dGlscy9nZXRCYXNlNjRGb3JJbWFnZVwiKTsiXSwic291cmNlUm9vdCI6IiJ9