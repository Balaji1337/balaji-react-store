export default function Skeleton({ children }) {
  return children
}

export const SkeletonTheme = Skeleton
