export default function reportError({ error }) {
  console.log('[reportError]', error)
}
