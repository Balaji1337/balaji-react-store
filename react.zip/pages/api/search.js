export { search as default } from 'react-storefront-connector'
